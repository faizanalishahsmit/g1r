export type AnimationState = 'IDLE' | 'WALK' | 'RUN' | 'JUMP';

export interface ColliderBox {
  id: string;
  minX: number;
  maxX: number;
  minY: number;
  maxY: number;
  minZ: number;
  maxZ: number;
  blocksCamera?: boolean;
}

export interface ColliderCylinder {
  id: string;
  x: number;
  z: number;
  radius: number;
  minY: number;
  maxY: number;
}

export interface WalkableSurface {
  id: string;
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  getHeight: (x: number, z: number) => number;
}

export interface BuildingEntry {
  id: string;
  code: string;
  name: string;
  category: 'Monumental Gate' | 'Ruined Architecture' | 'Collapsed Interior' | 'Infrastructure' | 'Exit Sanctum';
  position: [number, number, number];
  lookAt: [number, number, number];
  stories: number;
  condition: string;
  architecturalNotes: string;
  visualReferenceTie: string;
}

export interface ResearchReference {
  game: string;
  studio: string;
  studiedZones: string;
  keyFindings: string[];
  appliedInPyQuest: string;
}

export interface PlayerTelemetry {
  x: number;
  y: number;
  z: number;
  speed: number;
  headingDeg: number;
  state: AnimationState;
  isGrounded: boolean;
  nearestLandmark: BuildingEntry | null;
  distanceToExitGate: number;
  canActivateExitGate: boolean;
  discoveredLandmarks: string[];
  fps: number;
}

export interface VirtualInputState {
  moveX: number;
  moveY: number;
  isRunning: boolean;
  jumpRequested: boolean;
  interactRequested: boolean;
  lookDeltaX: number;
  lookDeltaY: number;
}
