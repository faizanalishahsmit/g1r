import { BuildingEntry, ResearchReference } from '../types/world';

export const AAA_VISUAL_RESEARCH: ResearchReference[] = [
  {
    game: 'Wuthering Waves',
    studio: 'Kuro Games',
    studiedZones: 'Port City of Guixu, Sea of Flames, Donglu Research Station & Collapsed Overpass',
    keyFindings: [
      'Monumental Brutalist concrete ruins sheared diagonally with exposed twisted rebar cages and tilted highway viaduct decks.',
      'Exposed multi-story building cross-sections where exterior curtain walls have collapsed, revealing interior floor slabs, support columns, and office/lab remnants.',
      'Golden-hour amber atmospheric scattering contrasting against cool slate-blue shadows and localized burning wreckage with rising embers.'
    ],
    appliedInPyQuest:
      'Applied in the fractured South Quarantine Entrance Arch, the collapsed mid-town highway viaduct, and the walkable exposed 2-story interior of the Helion Bio-Acoustic Research Annex (B3).'
  },
  {
    game: 'Genshin Impact',
    studio: 'HoYoverse',
    studiedZones: 'Stormterror’s Lair, Enkanomiya & Ochkanatlan Interconnected Ruin Corridors',
    keyFindings: [
      'S-curve primary sightline composition that frames the distant terminal landmark (the Exit Gate) from the opening plaza while inviting lateral exploration.',
      'Multi-layered organic vegetation where gnarled surface roots grip cracked masonry and asymmetrical tree canopies soften harsh architectural silhouettes.',
      'Natural elevation progression transitioning from sunken roadbeds to sidewalk terraces, walkable rubble ramps, and a monumental sanctuary staircase.'
    ],
    appliedInPyQuest:
      'Applied in the 230-meter S-curve urban canyon layout, organic multi-branched trees with exposed roots breaking through asphalt, and the elevated Northern Astral Exit Gate vista.'
  },
  {
    game: 'Granblue Fantasy: Relink',
    studio: 'Cygames',
    studiedZones: 'Folca Skyfarer Port, Tempeal Ruins & Seedhollow Architecture',
    keyFindings: [
      'Hand-crafted anime material readability combining crisp cel-toned shadow ramps on characters with tactile weathered stone, metal, and foliage surfaces.',
      'Warm sunlit directional rim highlights paired with rich azure-violet skylight fill so shadows never turn muddy grey-black.',
      'Layered leaf clump silhouettes with warm chartreuse-to-olive tonal variation and gentle wind oscillation.'
    ],
    appliedInPyQuest:
      'Applied in custom procedural anime toon gradient ramps on Kaelen (the rigged protagonist), golden-hour directional lighting with cool indigo hemisphere fill, and layered wind-swaying foliage canopies.'
  },
  {
    game: 'Zenless Zone Zero & Scarlet Nexus',
    studio: 'HoYoverse / Bandai Namco Studios',
    studiedZones: 'Sixth Street, Lumina Square, Kikuchiba Construction Site & Mizuhagawa District',
    keyFindings: [
      'Dense Neo-East-Asian street-level urban storytelling with ceramic-tile mid-rise blocks, corrugated rollup shop shutters, striped awnings, noodle bars, and glowing vending machines.',
      'Rich urban infrastructure silhouettes defined by cantilevered traffic signal gantries, pedestrian zebra crosswalks, leaning utility poles, and sagging catenary overhead power cables.',
      'Clean, high-contrast tactical telemetry UI that reinforces the anime sci-fi world without cluttering environmental sightlines.'
    ],
    appliedInPyQuest:
      'Applied in the Vermillion Arcade ground-floor ramen/cyber-optics shopfronts, Kurokawa Hab-Block convenience store & vending machines, mid-block urban street infill, traffic signal gantries, and 38+ sagging catenary cables.'
  }
];

export const LEVEL1_BUILDINGS: BuildingEntry[] = [
  {
    id: 'entrance-arch',
    code: 'GATE-00',
    name: 'Kyoraku Outer Quarantine Entrance Arch',
    category: 'Monumental Gate',
    position: [0, 0, 86],
    lookAt: [0, 8, 86],
    stories: 6,
    condition: 'Fractured Central Lintel // Standing Twin Pylons',
    architecturalNotes:
      'Monumental 22-meter fortified concrete twin pylons flanking the southern highway entrance. Features a sheared steel-truss overhead skybridge, dangling high-tension cables, blast barriers, and ruined checkpoint booths.',
    visualReferenceTie: 'Wuthering Waves (Guixu Perimeter Gate) + Scarlet Nexus (Kunad Highway Quarantine)'
  },
  {
    id: 'b1-transit-terminal',
    code: 'BLDG-01',
    name: 'Aegis Transit Authority Terminal',
    category: 'Collapsed Interior',
    position: [-26, 0, 58],
    lookAt: [-26, 6, 58],
    stories: 3,
    condition: 'Cantilever Canopy Intact // Shattered Curtain Glazing',
    architecturalNotes:
      'Curved steel-ribbed commuter rail terminal with cantilevered boarding canopy, recessed ticket concourse visible through shattered turquoise glass mullions, interior pillars, and fallen departure boards.',
    visualReferenceTie: 'Scarlet Nexus (Mizuhagawa Station) + Wuthering Waves'
  },
  {
    id: 'b2-kurokawa-hab',
    code: 'BLDG-02',
    name: 'Kurokawa Brutalist Hab-Block Tower',
    category: 'Ruined Architecture',
    position: [27, 0, 54],
    lookAt: [27, 9, 54],
    stories: 5,
    condition: 'Upper Corner Sheared // Wrap-Around Balconies Intact',
    architecturalNotes:
      'Five-story modular residential complex with staggered wrap-around concrete balconies, rusted iron railings, exterior AC condenser cages, recessed window frames with jagged broken glass panes, and rooftop water cisterns.',
    visualReferenceTie: 'Wuthering Waves (Guixu Residential Sector) + Scarlet Nexus (Kikuchiba)'
  },
  {
    id: 'b3-helion-annex',
    code: 'BLDG-03',
    name: 'Helion Bio-Acoustic Research Annex',
    category: 'Collapsed Interior',
    position: [-28, 0, 18],
    lookAt: [-24, 5.5, 18],
    stories: 4,
    condition: 'East Facade Collapsed // Walkable Exposed 2-Story Interior',
    architecturalNotes:
      'A collapsed laboratory complex whose eastern wall sheared away during the Calamity. A sloped concrete floor slab forms a walkable ramp directly into the exposed ground-floor interior featuring columns, lab consoles, server racks, stairwell, and hanging ceiling baffles.',
    visualReferenceTie: 'Wuthering Waves (Donglu Research Station Exposed Ruin)'
  },
  {
    id: 'b4-vermillion-arcade',
    code: 'BLDG-04',
    name: 'Vermillion Commercial Arcade & Skybridge',
    category: 'Ruined Architecture',
    position: [28, 0, 14],
    lookAt: [26, 8, 14],
    stories: 5,
    condition: 'Severed Pedestrian Skybridge // Rooftop Billboard Frame',
    architecturalNotes:
      'Multi-tiered commercial atrium with ground-floor shopfront colonnades, vertical district sign brackets, exterior steel zigzag fire-escape stairs, a rooftop skeletal billboard frame, and a severed glass skybridge jutting toward the central boulevard.',
    visualReferenceTie: 'Scarlet Nexus (Mizuhagawa Commercial Strip)'
  },
  {
    id: 'overpass-viaduct',
    code: 'INFRA-01',
    name: 'Collapsed Cross-Sector Highway Viaduct',
    category: 'Infrastructure',
    position: [0, 0, -14],
    lookAt: [0, 5, -14],
    stories: 2,
    condition: 'Central Span Buckled // Walkable Tilted Deck Ramp',
    architecturalNotes:
      'Elevated concrete box-girder highway overpass that buckled across the main boulevard. One sheared span tilts down to the street with exposed twisted rebar cages, Jersey barriers, and a localized burning transit bus below.',
    visualReferenceTie: 'Wuthering Waves (Port City of Guixu Collapsed Overpass)'
  },
  {
    id: 'b5-sentinel-spire',
    code: 'BLDG-05',
    name: 'Old Sentinel Broadcast & Relay Spire',
    category: 'Ruined Architecture',
    position: [31, 0, -34],
    lookAt: [31, 12, -34],
    stories: 7,
    condition: '7° Structural Tilt // Intact Cantilever Catwalks',
    architecturalNotes:
      'Octagonal stepped concrete-and-steel relay tower leaning 7 degrees westward, wrapped in heavy external conduit pipes, cantilevered steel maintenance decks, fractured microwave dish arrays, and pulsing amber hazard beacons.',
    visualReferenceTie: 'Scarlet Nexus (Arahabaki / Togetsu Relay Architecture)'
  },
  {
    id: 'b6-civic-archives',
    code: 'BLDG-06',
    name: 'Sunken Civic Archives & Colonnade Hall',
    category: 'Collapsed Interior',
    position: [-29, 0, -42],
    lookAt: [-27, 6, -42],
    stories: 3,
    condition: 'Roof Vault Breached // Exposed Archive Monolith Hall',
    architecturalNotes:
      'Neo-brutalist civic hall fronted by tall fluted rectangular piers and a fractured triangular pediment. The breached roof and missing side wall expose the interior archive hall, monolithic data shelves, and overgrown tree roots.',
    visualReferenceTie: 'Genshin Impact (Ruined Sanctuary Composition) + Granblue Fantasy: Relink'
  },
  {
    id: 'b7-tachibana-depot',
    code: 'BLDG-07',
    name: 'Tachibana Power Substation & Logistics Depot',
    category: 'Ruined Architecture',
    position: [26, 0, -72],
    lookAt: [26, 5, -72],
    stories: 3,
    condition: 'Transformer Yard Intact // Torn Rolling Shutter',
    architecturalNotes:
      'Industrial reinforced-concrete and corrugated-steel power depot featuring ceramic high-voltage insulator banks, cooling radiator fins, an overhead steel gantry crane, and heavy power cables feeding toward the northern gate.',
    visualReferenceTie: 'Scarlet Nexus (Kikuchiba Industrial Substation)'
  },
  {
    id: 'b8-meridian-tower',
    code: 'BLDG-08',
    name: 'Leaning Twin-Core Meridian Skyscraper Ruin',
    category: 'Collapsed Interior',
    position: [-30, 0, -76],
    lookAt: [-30, 14, -76],
    stories: 8,
    condition: 'Upper Floors Cleaved Diagonally // Exposed Elevator Core',
    architecturalNotes:
      'Monumental eight-story twin-core corporate tower cleaved diagonally at the 6th floor. Exposes the reinforced concrete elevator shaft, cantilevered I-beam skeletons, hanging floor decks, and shattered curtain-wall bands.',
    visualReferenceTie: 'Wuthering Waves (Sea of Flames Skyscraper Ruins)'
  },
  {
    id: 'b9-gatekeeper-bastion',
    code: 'BLDG-09',
    name: 'Gatekeeper Bastion & Quarantine Pavilion',
    category: 'Ruined Architecture',
    position: [21, 2.2, -104],
    lookAt: [21, 6, -104],
    stories: 3,
    condition: 'Fortified Terrace Bunker // Connected to Exit Gate',
    architecturalNotes:
      'Stepped bunker-style command pavilion integrated into the northern sanctuary retaining wall, featuring armoured observation slits, cantilevered sensor array deck, and heavy containment cables anchored to the Exit Gate.',
    visualReferenceTie: 'Granblue Fantasy: Relink + Wuthering Waves'
  },
  {
    id: 'exit-gate',
    code: 'EXIT-L1',
    name: 'Astral Resonance Sanctum — Level 1 Exit Gate',
    category: 'Exit Sanctum',
    position: [0, 3.2, -118],
    lookAt: [0, 11, -118],
    stories: 8,
    condition: 'Active Resonance Threshold // Reach & Interact to Complete Level 1',
    architecturalNotes:
      'The monumental architectural climax of Level 1. Twin 28-meter carved obsidian-and-concrete monolith pylons inlaid with luminous gold-cyan resonance conduits frame a counter-rotating fractured astrolabe halo above a grand ceremonial staircase.',
    visualReferenceTie: 'Genshin Impact + Granblue Fantasy: Relink + Wuthering Waves'
  }
];

export const EXIT_GATE_POSITION: [number, number, number] = [0, 3.2, -118];
export const PLAYER_SPAWN_POSITION: [number, number, number] = [0, 0, 96];
