import React, { useRef, useState } from 'react';
import { VirtualInputState } from '../types/world';
import { ArrowUp, Sparkles, Zap } from 'lucide-react';

interface TouchControlsHUDProps {
  virtualInputRef: React.MutableRefObject<VirtualInputState>;
  canActivateExitGate: boolean;
  onActivateExitGate: () => void;
}

export const TouchControlsHUD: React.FC<TouchControlsHUDProps> = ({
  virtualInputRef,
  canActivateExitGate,
  onActivateExitGate
}) => {
  const joyContainerRef = useRef<HTMLDivElement | null>(null);
  const [knobOffset, setKnobOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isRunToggled, setIsRunToggled] = useState<boolean>(true);
  const joyPointerId = useRef<number | null>(null);
  const lookPointerId = useRef<number | null>(null);
  const lastLookPos = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  // Sync run toggle to virtualInputRef
  virtualInputRef.current.isRunning = isRunToggled;

  const updateJoystickFromEvent = (clientX: number, clientY: number) => {
    const el = joyContainerRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width * 0.5;
    const cy = rect.top + rect.height * 0.5;
    const maxRadius = rect.width * 0.42;

    const dx = clientX - cx;
    const dy = clientY - cy;
    const dist = Math.hypot(dx, dy);
    const clamped = Math.min(dist, maxRadius);
    const angle = Math.atan2(dy, dx);

    const nx = dist > 0.001 ? (Math.cos(angle) * clamped) / maxRadius : 0;
    const ny = dist > 0.001 ? (Math.sin(angle) * clamped) / maxRadius : 0;

    setKnobOffset({
      x: Math.cos(angle) * clamped,
      y: Math.sin(angle) * clamped
    });

    virtualInputRef.current.moveX = nx;
    virtualInputRef.current.moveY = ny;
  };

  const resetJoystick = () => {
    joyPointerId.current = null;
    setKnobOffset({ x: 0, y: 0 });
    virtualInputRef.current.moveX = 0;
    virtualInputRef.current.moveY = 0;
  };

  return (
    <div className="pointer-events-none fixed inset-0 z-20 select-none">
      {/* Right-Side Touch Camera Rotation Pad */}
      <div
        className="pointer-events-auto absolute right-0 top-16 bottom-36 w-1/2 touch-none"
        onPointerDown={(e) => {
          if (lookPointerId.current === null) {
            lookPointerId.current = e.pointerId;
            lastLookPos.current = { x: e.clientX, y: e.clientY };
            e.currentTarget.setPointerCapture(e.pointerId);
          }
        }}
        onPointerMove={(e) => {
          if (lookPointerId.current === e.pointerId) {
            const dx = e.clientX - lastLookPos.current.x;
            const dy = e.clientY - lastLookPos.current.y;
            lastLookPos.current = { x: e.clientX, y: e.clientY };
            virtualInputRef.current.lookDeltaX += dx;
            virtualInputRef.current.lookDeltaY += dy;
          }
        }}
        onPointerUp={(e) => {
          if (lookPointerId.current === e.pointerId) {
            lookPointerId.current = null;
          }
        }}
        onPointerCancel={() => {
          lookPointerId.current = null;
        }}
      />

      {/* Bottom-Left Virtual Analog Thumbstick */}
      <div
        ref={joyContainerRef}
        className="pointer-events-auto absolute bottom-7 left-7 h-32 w-32 rounded-full border border-amber-300/35 bg-slate-950/65 backdrop-blur-md shadow-2xl flex items-center justify-center touch-none"
        onPointerDown={(e) => {
          joyPointerId.current = e.pointerId;
          e.currentTarget.setPointerCapture(e.pointerId);
          updateJoystickFromEvent(e.clientX, e.clientY);
        }}
        onPointerMove={(e) => {
          if (joyPointerId.current === e.pointerId) {
            updateJoystickFromEvent(e.clientX, e.clientY);
          }
        }}
        onPointerUp={(e) => {
          if (joyPointerId.current === e.pointerId) {
            resetJoystick();
          }
        }}
        onPointerCancel={resetJoystick}
      >
        <div className="h-20 w-20 rounded-full border border-white/10 flex items-center justify-center">
          <div className="text-[10px] font-mono-tech uppercase tracking-widest text-amber-200/40">
            MOVE
          </div>
        </div>
        <div
          style={{
            transform: `translate3d(${knobOffset.x}px, ${knobOffset.y}px, 0)`
          }}
          className="absolute h-12 w-12 rounded-full bg-gradient-to-br from-amber-400 to-orange-600 border-2 border-amber-100 shadow-lg shadow-orange-500/40"
        />
      </div>

      {/* Bottom-Right Android Action Cluster: RUN, JUMP & GATE INTERACT */}
      <div className="pointer-events-auto absolute bottom-7 right-7 flex items-end gap-3.5">
        {canActivateExitGate && (
          <button
            type="button"
            onClick={() => {
              onActivateExitGate();
            }}
            className="animate-pulse-glow flex h-16 px-5 items-center gap-2 rounded-full bg-gradient-to-r from-cyan-400 to-amber-400 text-slate-950 font-display font-bold text-sm uppercase tracking-wider shadow-xl shadow-cyan-400/30 border-2 border-white"
          >
            <Sparkles className="w-5 h-5" />
            Activate Gate
          </button>
        )}

        <button
          type="button"
          onClick={() => setIsRunToggled((prev) => !prev)}
          className={`flex flex-col items-center justify-center h-14 w-14 rounded-full border transition-all ${
            isRunToggled
              ? 'bg-amber-500/85 border-amber-200 text-slate-950 shadow-lg shadow-amber-500/30'
              : 'bg-slate-900/75 border-white/20 text-slate-200'
          }`}
          title="Toggle Run / Walk"
        >
          <Zap className="w-4 h-4" />
          <span className="text-[10px] font-mono-tech font-bold mt-0.5">
            {isRunToggled ? 'RUN' : 'WALK'}
          </span>
        </button>

        <button
          type="button"
          onPointerDown={() => {
            virtualInputRef.current.jumpRequested = true;
          }}
          className="flex flex-col items-center justify-center h-16 w-16 rounded-full bg-slate-900/80 border-2 border-amber-400/70 text-amber-100 active:scale-95 active:bg-amber-500 active:text-slate-950 shadow-xl transition-transform"
          title="Jump"
        >
          <ArrowUp className="w-5 h-5" />
          <span className="text-[10px] font-mono-tech font-bold mt-0.5">JUMP</span>
        </button>
      </div>
    </div>
  );
};
