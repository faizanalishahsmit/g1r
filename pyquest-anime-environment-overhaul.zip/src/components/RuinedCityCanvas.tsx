import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { createMaterialLibrary } from '../engine/TextureFactory';
import { PhysicsWorld } from '../engine/PhysicsWorld';
import { createRiggedAnimeCharacter } from '../engine/CharacterBuilder';
import { buildLevel1Architecture } from '../engine/ArchitectureBuilder';
import { buildLevelVegetation } from '../engine/VegetationBuilder';
import { buildVehiclesAndInfrastructureProps } from '../engine/VehicleAndPropsBuilder';
import { setupEnvironmentalEffects } from '../engine/EffectsManager';
import {
  EXIT_GATE_POSITION,
  LEVEL1_BUILDINGS,
  PLAYER_SPAWN_POSITION
} from '../data/level1Data';
import {
  AnimationState,
  BuildingEntry,
  PlayerTelemetry,
  VirtualInputState
} from '../types/world';

export type CameraPresetMode = 'STANDARD' | 'CLOSE_SHOULDER' | 'WIDE_VISTA' | 'HIGH_SURVEY';

interface RuinedCityCanvasProps {
  virtualInputRef: React.MutableRefObject<VirtualInputState>;
  cameraPreset: CameraPresetMode;
  teleportTarget: { id: string; timestamp: number } | null;
  gateCompleted: boolean;
  onTelemetryUpdate: (telemetry: PlayerTelemetry) => void;
  onActivateExitGate: () => void;
  onPointerLockChange?: (locked: boolean) => void;
}

export const RuinedCityCanvas: React.FC<RuinedCityCanvasProps> = ({
  virtualInputRef,
  cameraPreset,
  teleportTarget,
  gateCompleted,
  onTelemetryUpdate,
  onActivateExitGate,
  onPointerLockChange
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const cameraPresetRef = useRef<CameraPresetMode>(cameraPreset);
  const gateCompletedRef = useRef<boolean>(gateCompleted);
  const onActivateGateRef = useRef(onActivateExitGate);
  const onTelemetryRef = useRef(onTelemetryUpdate);

  useEffect(() => {
    cameraPresetRef.current = cameraPreset;
  }, [cameraPreset]);

  useEffect(() => {
    gateCompletedRef.current = gateCompleted;
  }, [gateCompleted]);

  useEffect(() => {
    onActivateGateRef.current = onActivateExitGate;
  }, [onActivateExitGate]);

  useEffect(() => {
    onTelemetryRef.current = onTelemetryUpdate;
  }, [onTelemetryUpdate]);

  // Store teleport handler ref so external UI can jump to any landmark vantage point
  const teleportHandlerRef = useRef<((landmarkId: string) => void) | null>(null);

  useEffect(() => {
    if (teleportTarget && teleportHandlerRef.current) {
      teleportHandlerRef.current(teleportTarget.id);
    }
  }, [teleportTarget]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // ==========================================================================
    // 1. SCENE, RENDERER, LIGHTING, SHADOWS & ATMOSPHERIC FOG
    // ==========================================================================
    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#21283b');
    scene.fog = new THREE.FogExp2('#353142', 0.0052);

    const camera = new THREE.PerspectiveCamera(
      58,
      container.clientWidth / Math.max(1, container.clientHeight),
      0.25,
      420
    );

    const isMobileDevice =
      typeof window !== 'undefined' &&
      ('ontouchstart' in window || navigator.maxTouchPoints > 0 || window.innerWidth < 860);

    const renderer = new THREE.WebGLRenderer({
      antialias: !isMobileDevice,
      powerPreference: 'high-performance'
    });
    renderer.setSize(container.clientWidth, container.clientHeight);
    const maxDpr = isMobileDevice ? 1.5 : 2.0;
    let currentDpr = Math.min(window.devicePixelRatio || 1, maxDpr);
    renderer.setPixelRatio(currentDpr);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.16;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // Golden-Hour Anime Directional Sunlight + Cool Indigo Sky Hemisphere Fill
    const hemiLight = new THREE.HemisphereLight('#859ed9', '#453832', 1.02);
    hemiLight.position.set(0, 60, 0);
    scene.add(hemiLight);

    const sunLight = new THREE.DirectionalLight('#ffc48c', 2.55);
    sunLight.position.set(58, 76, 44);
    sunLight.castShadow = true;
    const shadowRes = isMobileDevice ? 1024 : 2048;
    sunLight.shadow.mapSize.width = shadowRes;
    sunLight.shadow.mapSize.height = shadowRes;
    sunLight.shadow.camera.near = 10;
    sunLight.shadow.camera.far = 260;
    const d = 95;
    sunLight.shadow.camera.left = -d;
    sunLight.shadow.camera.right = d;
    sunLight.shadow.camera.top = d;
    sunLight.shadow.camera.bottom = -d;
    sunLight.shadow.bias = -0.0004;
    scene.add(sunLight);

    // Subtle warm sunset bounce light from the northern horizon
    const rimDirLight = new THREE.DirectionalLight('#ff7b47', 0.65);
    rimDirLight.position.set(-40, 28, -95);
    scene.add(rimDirLight);

    // ==========================================================================
    // 2. BUILD MODULAR WORLD, MATERIALS, PHYSICS, VEGETATION, VEHICLES & CHARACTER
    // ==========================================================================
    const mats = createMaterialLibrary();
    const physics = new PhysicsWorld();

    const exitGateRefs = buildLevel1Architecture(scene, mats, physics);
    const swayingFoliage = buildLevelVegetation(scene, mats, physics);
    const { fireSites, swayingCables } = buildVehiclesAndInfrastructureProps(scene, mats, physics);
    const fxController = setupEnvironmentalEffects(
      scene,
      fireSites,
      swayingFoliage,
      swayingCables,
      exitGateRefs
    );

    const character = createRiggedAnimeCharacter(mats.toonGradient);
    scene.add(character.root);

    // ==========================================================================
    // 3. PLAYER STATE & THIRD-PERSON CAMERA RIG
    // ==========================================================================
    const playerPos = new THREE.Vector3(...PLAYER_SPAWN_POSITION);
    let playerHeading = Math.PI; // Facing North (-Z) toward the Ruined City Entrance Arch & Exit Gate
    let verticalVel = 0;
    let isGrounded = true;
    let currentSpeed = 0;

    // Camera orbital angles (yaw = 0 looks North along -Z)
    let camYaw = 0;
    let camPitch = 0.24;
    let camZoomDist = 4.6;
    const smoothPivot = new THREE.Vector3(playerPos.x, playerPos.y + 1.55, playerPos.z);
    const smoothCamPos = new THREE.Vector3(playerPos.x, playerPos.y + 3.0, playerPos.z + 4.8);

    const discoveredSet = new Set<string>(['entrance-arch']);

    // Allow teleporting to curated third-person inspection vantage points for every building/landmark
    teleportHandlerRef.current = (landmarkId: string) => {
      const vantageMap: Record<string, { pos: [number, number, number]; yaw: number; pitch: number }> = {
        'entrance-arch': { pos: [0, 0, 98], yaw: 0, pitch: 0.16 },
        'b1-transit-terminal': { pos: [-12.5, 0.24, 58], yaw: Math.PI * 0.45, pitch: 0.18 },
        'b2-kurokawa-hab': { pos: [12.5, 0.24, 54], yaw: -Math.PI * 0.45, pitch: 0.15 },
        'b3-helion-annex': { pos: [-15.2, 0.24, 18], yaw: Math.PI * 0.48, pitch: 0.2 },
        'b4-vermillion-arcade': { pos: [12.0, 0.24, 16], yaw: -Math.PI * 0.44, pitch: 0.15 },
        'overpass-viaduct': { pos: [2.2, 0, -3.5], yaw: 0.18, pitch: 0.22 },
        'b5-sentinel-spire': { pos: [12.8, 0.24, -32], yaw: -Math.PI * 0.42, pitch: 0.12 },
        'b6-civic-archives': { pos: [-13.5, 0.24, -42], yaw: Math.PI * 0.46, pitch: 0.18 },
        'b7-tachibana-depot': { pos: [11.5, 0.24, -71], yaw: -Math.PI * 0.45, pitch: 0.2 },
        'b8-meridian-tower': { pos: [-11.5, 0.24, -72], yaw: Math.PI * 0.42, pitch: 0.1 },
        'b9-gatekeeper-bastion': { pos: [7.5, 3.2, -108], yaw: -Math.PI * 0.38, pitch: 0.18 },
        'exit-gate': { pos: [0, 3.2, -111.5], yaw: 0, pitch: 0.14 }
      };

      const target = vantageMap[landmarkId];
      if (target) {
        playerPos.set(...target.pos);
        verticalVel = 0;
        isGrounded = true;
        camYaw = target.yaw;
        camPitch = target.pitch;
        playerHeading = Math.PI + target.yaw;
        discoveredSet.add(landmarkId);
      }
    };

    // ==========================================================================
    // 4. DESKTOP KEYBOARD & MOUSE INPUT LISTENERS
    // ==========================================================================
    const keys: Record<string, boolean> = {};
    let isPointerDragging = false;
    let lastMouseX = 0;
    let lastMouseY = 0;

    const tryActivateExitGate = () => {
      if (gateCompletedRef.current) return;
      const dx = playerPos.x - EXIT_GATE_POSITION[0];
      const dz = playerPos.z - EXIT_GATE_POSITION[2];
      const dist = Math.hypot(dx, dz);
      if (dist < 9.5 && playerPos.y >= 1.8) {
        onActivateGateRef.current();
      }
    };

    const onKeyDown = (e: KeyboardEvent) => {
      const code = e.code;
      keys[code] = true;

      if (code === 'Space' && isGrounded && !e.repeat) {
        verticalVel = 7.6;
        isGrounded = false;
      }

      if ((code === 'KeyE' || code === 'KeyF' || code === 'Enter') && !e.repeat) {
        tryActivateExitGate();
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      keys[e.code] = false;
    };

    const onMouseDown = (e: MouseEvent) => {
      if (e.button === 0) {
        isPointerDragging = true;
        lastMouseX = e.clientX;
        lastMouseY = e.clientY;
      }
    };

    const onMouseUp = () => {
      isPointerDragging = false;
    };

    const onMouseMove = (e: MouseEvent) => {
      if (document.pointerLockElement === renderer.domElement) {
        camYaw -= e.movementX * 0.0026;
        camPitch = THREE.MathUtils.clamp(camPitch + e.movementY * 0.0022, -0.22, 1.15);
      } else if (isPointerDragging) {
        const dx = e.clientX - lastMouseX;
        const dy = e.clientY - lastMouseY;
        lastMouseX = e.clientX;
        lastMouseY = e.clientY;
        camYaw -= dx * 0.0045;
        camPitch = THREE.MathUtils.clamp(camPitch + dy * 0.0038, -0.22, 1.15);
      }
    };

    const onWheel = (e: WheelEvent) => {
      camZoomDist = THREE.MathUtils.clamp(camZoomDist + e.deltaY * 0.0035, 2.5, 9.5);
    };

    const onCanvasDoubleClick = () => {
      if (document.pointerLockElement !== renderer.domElement) {
        renderer.domElement.requestPointerLock?.();
      } else {
        document.exitPointerLock?.();
      }
    };

    const onPointerLockChangeInternal = () => {
      onPointerLockChange?.(document.pointerLockElement === renderer.domElement);
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    renderer.domElement.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mouseup', onMouseUp);
    window.addEventListener('mousemove', onMouseMove);
    renderer.domElement.addEventListener('wheel', onWheel, { passive: true });
    renderer.domElement.addEventListener('dblclick', onCanvasDoubleClick);
    document.addEventListener('pointerlockchange', onPointerLockChangeInternal);

    const onResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / Math.max(1, container.clientHeight);
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', onResize);

    // ==========================================================================
    // 5. MAIN GAME & RENDER LOOP
    // ==========================================================================
    let rafId = 0;
    let lastTime = performance.now();
    let elapsedTime = 0;
    let frameCounter = 0;
    let fpsTimer = 0;
    let measuredFps = 60;
    let telemetryTimer = 0;

    const animate = (now: number) => {
      rafId = requestAnimationFrame(animate);
      const dt = Math.min(0.05, Math.max(0.001, (now - lastTime) / 1000));
      lastTime = now;
      elapsedTime += dt;

      frameCounter++;
      fpsTimer += dt;
      if (fpsTimer >= 0.5) {
        measuredFps = Math.round(frameCounter / fpsTimer);
        frameCounter = 0;
        fpsTimer = 0;
      }

      // 1) Read Virtual Touch / Android Input
      const vInput = virtualInputRef.current;
      if (Math.abs(vInput.lookDeltaX) > 0.0001 || Math.abs(vInput.lookDeltaY) > 0.0001) {
        camYaw -= vInput.lookDeltaX * 0.0055;
        camPitch = THREE.MathUtils.clamp(camPitch + vInput.lookDeltaY * 0.0045, -0.22, 1.15);
        vInput.lookDeltaX = 0;
        vInput.lookDeltaY = 0;
      }

      if (vInput.jumpRequested) {
        vInput.jumpRequested = false;
        if (isGrounded) {
          verticalVel = 7.6;
          isGrounded = false;
        }
      }

      if (vInput.interactRequested) {
        vInput.interactRequested = false;
        tryActivateExitGate();
      }

      // Keyboard camera rotation assist (Left / Right arrows if user prefers keyboard look)
      if (keys['ArrowLeft']) camYaw += dt * 1.8;
      if (keys['ArrowRight']) camYaw -= dt * 1.8;

      // 2) Compute Movement Vector in Camera Space (separate Keyboard vs Virtual Joystick)
      let kbForward = 0;
      let kbRight = 0;

      if (keys['KeyW'] || keys['ArrowUp']) kbForward += 1;
      if (keys['KeyS'] || keys['ArrowDown']) kbForward -= 1;
      if (keys['KeyD']) kbRight += 1;
      if (keys['KeyA']) kbRight -= 1;

      const touchMag = Math.hypot(vInput.moveX, vInput.moveY);
      const moveForward = kbForward - vInput.moveY;
      const moveRight = kbRight + vInput.moveX;

      const inputMag = Math.min(1, Math.hypot(moveForward, moveRight));
      // Desktop keyboard sprints ONLY when Shift is held; virtual thumbstick uses its RUN/WALK toggle
      const isKeyboardSprint = Boolean(keys['ShiftLeft'] || keys['ShiftRight']);
      const isTouchSprint = touchMag > 0.05 && vInput.isRunning;
      const isSprint = isKeyboardSprint || isTouchSprint;

      const targetMaxSpeed = inputMag > 0.05 ? (isSprint ? 9.2 : 4.6) * inputMag : 0;
      currentSpeed = THREE.MathUtils.lerp(currentSpeed, targetMaxSpeed, Math.min(1, dt * 10));

      let turnDelta = 0;

      if (inputMag > 0.05) {
        const inputAngle = Math.atan2(moveRight, moveForward);
        // Forward camera direction is (-sin(camYaw), -cos(camYaw))
        const desiredMoveAngle = camYaw - inputAngle;
        const moveDirX = -Math.sin(desiredMoveAngle);
        const moveDirZ = -Math.cos(desiredMoveAngle);

        playerPos.x += moveDirX * currentSpeed * dt;
        playerPos.z += moveDirZ * currentSpeed * dt;

        // Character mesh faces local +Z, so heading angle is atan2(moveDirX, moveDirZ)
        const targetHeading = Math.atan2(moveDirX, moveDirZ);
        let diff = targetHeading - playerHeading;
        while (diff > Math.PI) diff -= Math.PI * 2;
        while (diff < -Math.PI) diff += Math.PI * 2;

        turnDelta = diff / Math.max(0.016, dt);
        playerHeading += diff * Math.min(1, dt * 12);
      }

      // 3) Resolve Horizontal Collisions & Sample Multi-Elevation Ground Height
      physics.resolveHorizontalMovement(playerPos, 0.52, 1.85);

      const groundY = physics.getGroundHeight(playerPos.x, playerPos.z, playerPos.y);
      // Allow downward step-stickiness (0.34m) when grounded so running down stairs/ramps stays grounded
      const stepDownTolerance = isGrounded && verticalVel <= 0 ? 0.34 : 0.06;

      if (!isGrounded || playerPos.y > groundY + stepDownTolerance) {
        isGrounded = false;
        verticalVel -= 19.6 * dt; // Gravity
        playerPos.y += verticalVel * dt;
        if (playerPos.y <= groundY) {
          playerPos.y = groundY;
          verticalVel = 0;
          isGrounded = true;
        }
      } else {
        // Smoothly follow ramps and stairs
        playerPos.y = THREE.MathUtils.lerp(playerPos.y, groundY, Math.min(1, dt * 24));
        verticalVel = 0;
        isGrounded = true;
      }

      // Compute ground slope pitch beneath character's feet for foot placement alignment
      const forwardX = Math.sin(playerHeading) * 0.35;
      const forwardZ = Math.cos(playerHeading) * 0.35;
      const hAhead = physics.getGroundHeight(
        playerPos.x + forwardX,
        playerPos.z + forwardZ,
        playerPos.y
      );
      const groundSlopePitch = THREE.MathUtils.clamp((groundY - hAhead) * 0.85, -0.35, 0.35);

      // 4) Update Character Transform & Procedural Skeletal Animation
      character.root.position.copy(playerPos);
      character.root.rotation.y = playerHeading;

      let animState: AnimationState = 'IDLE';
      if (!isGrounded) {
        animState = 'JUMP';
      } else if (currentSpeed > 6.2) {
        animState = 'RUN';
      } else if (currentSpeed > 0.35) {
        animState = 'WALK';
      }

      character.updateAnimation(
        dt,
        elapsedTime,
        animState,
        currentSpeed,
        turnDelta,
        verticalVel,
        groundSlopePitch
      );

      // 5) Update Third-Person Orbital Camera with Anti-Clipping Ray Resolution
      const preset = cameraPresetRef.current;
      let presetDist = camZoomDist;
      let presetHeightOffset = 1.58;
      let shoulderRightOffset = 0.0;

      if (preset === 'CLOSE_SHOULDER') {
        presetDist = 2.95;
        presetHeightOffset = 1.62;
        shoulderRightOffset = 0.42;
      } else if (preset === 'WIDE_VISTA') {
        presetDist = 7.2;
        presetHeightOffset = 2.05;
      } else if (preset === 'HIGH_SURVEY') {
        presetDist = 8.8;
        presetHeightOffset = 2.6;
      }

      const rightVec = new THREE.Vector3(Math.cos(camYaw), 0, -Math.sin(camYaw));
      const targetPivot = new THREE.Vector3(
        playerPos.x + rightVec.x * shoulderRightOffset,
        playerPos.y + presetHeightOffset,
        playerPos.z + rightVec.z * shoulderRightOffset
      );
      smoothPivot.lerp(targetPivot, Math.min(1, dt * 15));

      const horizDist = presetDist * Math.cos(camPitch);
      const vertDist = presetDist * Math.sin(camPitch);

      const desiredCamPos = new THREE.Vector3(
        smoothPivot.x + Math.sin(camYaw) * horizDist,
        smoothPivot.y + vertDist,
        smoothPivot.z + Math.cos(camYaw) * horizDist
      );

      // Resolve camera wall/building collision with fast pull-in and smooth recovery
      const safeCamPos = physics.resolveCameraCollision(smoothPivot, desiredCamPos, 0.45);
      const isPullingIn =
        safeCamPos.distanceToSquared(smoothPivot) < smoothCamPos.distanceToSquared(smoothPivot);
      smoothCamPos.lerp(safeCamPos, Math.min(1, dt * (isPullingIn ? 28 : 14)));

      camera.position.copy(smoothCamPos);
      camera.lookAt(
        smoothPivot.x,
        smoothPivot.y + (preset === 'WIDE_VISTA' ? 0.35 : 0.12),
        smoothPivot.z
      );

      // 6) Update Real-Time Environmental Effects (Flames, Smoke, Embers, Dust, Wind Sway, Exit Gate)
      fxController.update(dt, elapsedTime, gateCompletedRef.current);

      // 7) Render Scene
      renderer.render(scene, camera);

      // 8) Emit Player Telemetry & Landmark Discovery to HUD (at ~15Hz to keep React UI snappy)
      telemetryTimer += dt;
      if (telemetryTimer >= 0.065) {
        telemetryTimer = 0;

        // Adaptive DPR scaling for weaker hardware if FPS drops below 42
        if (measuredFps < 42 && currentDpr > 1.0) {
          currentDpr = Math.max(1.0, currentDpr - 0.25);
          renderer.setPixelRatio(currentDpr);
        }

        let nearest: BuildingEntry | null = null;
        let nearestDist = Infinity;

        for (let i = 0; i < LEVEL1_BUILDINGS.length; i++) {
          const b = LEVEL1_BUILDINGS[i];
          const d = Math.hypot(playerPos.x - b.position[0], playerPos.z - b.position[2]);
          if (d < 26) {
            discoveredSet.add(b.id);
          }
          if (d < nearestDist) {
            nearestDist = d;
            nearest = b;
          }
        }

        const exitDist = Math.hypot(
          playerPos.x - EXIT_GATE_POSITION[0],
          playerPos.z - EXIT_GATE_POSITION[2]
        );

        onTelemetryRef.current({
          x: playerPos.x,
          y: playerPos.y,
          z: playerPos.z,
          speed: currentSpeed,
          headingDeg: Math.round(((camYaw * 180) / Math.PI + 360) % 360),
          state: animState,
          isGrounded,
          nearestLandmark: nearestDist < 32 ? nearest : null,
          distanceToExitGate: Math.round(exitDist),
          canActivateExitGate: exitDist < 9.5 && playerPos.y >= 1.8 && !gateCompletedRef.current,
          discoveredLandmarks: Array.from(discoveredSet),
          fps: measuredFps
        });
      }
    };

    rafId = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(rafId);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      renderer.domElement.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mouseup', onMouseUp);
      window.removeEventListener('mousemove', onMouseMove);
      renderer.domElement.removeEventListener('wheel', onWheel);
      renderer.domElement.removeEventListener('dblclick', onCanvasDoubleClick);
      document.removeEventListener('pointerlockchange', onPointerLockChangeInternal);
      window.removeEventListener('resize', onResize);

      // Complete Three.js Resource Disposal (Geometries, Materials, Textures, Render Targets)
      fxController.dispose();

      const disposedGeometries = new Set<THREE.BufferGeometry>();
      const disposedMaterials = new Set<THREE.Material>();
      const disposedTextures = new Set<THREE.Texture>();

      const disposeMaterial = (mat: THREE.Material) => {
        if (disposedMaterials.has(mat)) return;
        disposedMaterials.add(mat);
        const std = mat as THREE.MeshStandardMaterial & { gradientMap?: THREE.Texture };
        [
          std.map,
          std.emissiveMap,
          std.bumpMap,
          std.roughnessMap,
          std.metalnessMap,
          std.alphaMap,
          std.normalMap,
          std.gradientMap
        ].forEach((tex) => {
          if (tex && !disposedTextures.has(tex)) {
            disposedTextures.add(tex);
            tex.dispose();
          }
        });
        mat.dispose();
      };

      scene.traverse((obj) => {
        const mesh = obj as THREE.Mesh;
        if (mesh.geometry && !disposedGeometries.has(mesh.geometry)) {
          disposedGeometries.add(mesh.geometry);
          mesh.geometry.dispose();
        }
        if (mesh.material) {
          if (Array.isArray(mesh.material)) {
            mesh.material.forEach(disposeMaterial);
          } else {
            disposeMaterial(mesh.material);
          }
        }
      });

      scene.clear();
      renderer.renderLists.dispose();
      renderer.dispose();
      if (renderer.domElement && renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [virtualInputRef, onPointerLockChange]);

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full overflow-hidden cursor-grab active:cursor-grabbing touch-none"
      aria-label="PyQuest Rebirth Level 1 3D Viewport"
    />
  );
};
