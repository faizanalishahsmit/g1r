import React, { useState } from 'react';
import { AAA_VISUAL_RESEARCH, LEVEL1_BUILDINGS } from '../data/level1Data';
import { Building2, CheckCircle2, Compass, Eye, Layers, Sparkles, X } from 'lucide-react';

interface ArchitecturalCodexModalProps {
  isOpen: boolean;
  discoveredIds: string[];
  onClose: () => void;
  onTeleportToBuilding: (buildingId: string) => void;
}

export const ArchitecturalCodexModal: React.FC<ArchitecturalCodexModalProps> = ({
  isOpen,
  discoveredIds,
  onClose,
  onTeleportToBuilding
}) => {
  const [activeTab, setActiveTab] = useState<'ARCHITECTURE' | 'RESEARCH'>('ARCHITECTURE');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4">
      <div className="hud-panel hud-clip relative w-full max-w-5xl max-h-[88vh] flex flex-col overflow-hidden rounded-lg border border-amber-300/30">
        {/* Header Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 bg-slate-900/90 px-6 py-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono-tech uppercase tracking-widest text-amber-400">
              <Sparkles className="w-3.5 h-3.5" />
              PYQUEST REBIRTH // LEVEL 1 ENVIRONMENTAL ART & ARCHITECTURAL CODEX
            </div>
            <h2 className="font-display text-2xl font-bold uppercase tracking-wider text-amber-50 mt-0.5">
              Kyoraku Outer Sector — Ruined City Entrance
            </h2>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setActiveTab('ARCHITECTURE')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded text-xs font-mono-tech uppercase tracking-wider transition-all ${
                activeTab === 'ARCHITECTURE'
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-lg shadow-amber-500/25'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Building2 className="w-4 h-4" />
              12 Landmarks & Buildings ({discoveredIds.length}/{LEVEL1_BUILDINGS.length})
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('RESEARCH')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded text-xs font-mono-tech uppercase tracking-wider transition-all ${
                activeTab === 'RESEARCH'
                  ? 'bg-cyan-400 text-slate-950 font-bold shadow-lg shadow-cyan-400/25'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Layers className="w-4 h-4" />
              AAA Visual Research (4 Games)
            </button>
            <button
              type="button"
              onClick={onClose}
              className="ml-2 p-2 rounded bg-slate-800 text-slate-300 hover:bg-red-500/20 hover:text-red-300 transition-colors"
              aria-label="Close Architectural Codex"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {activeTab === 'ARCHITECTURE' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {LEVEL1_BUILDINGS.map((b) => {
                const isDiscovered = discoveredIds.includes(b.id);
                return (
                  <div
                    key={b.id}
                    className={`rounded-lg border p-4 transition-all flex flex-col justify-between ${
                      b.category === 'Exit Sanctum'
                        ? 'border-cyan-400/45 bg-cyan-950/25'
                        : isDiscovered
                        ? 'border-amber-400/30 bg-slate-900/75'
                        : 'border-white/10 bg-slate-900/45'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2">
                        <span className="px-2 py-0.5 rounded bg-amber-500/20 border border-amber-400/40 text-amber-300 font-mono-tech text-[11px]">
                          {b.code} // {b.category.toUpperCase()}
                        </span>
                        <span className="flex items-center gap-1 text-[11px] font-mono-tech text-emerald-300">
                          {isDiscovered && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                          {b.stories} Stories
                        </span>
                      </div>

                      <h3 className="font-display text-lg font-bold text-amber-50 mt-2">
                        {b.name}
                      </h3>
                      <div className="text-xs font-mono-tech text-amber-300/90 mt-0.5">
                        {b.condition}
                      </div>
                      <p className="text-xs text-slate-300 leading-relaxed mt-2">
                        {b.architecturalNotes}
                      </p>
                    </div>

                    <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between gap-2">
                      <span className="text-[11px] font-mono-tech text-cyan-300/85 truncate">
                        Ref: {b.visualReferenceTie}
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          onTeleportToBuilding(b.id);
                          onClose();
                        }}
                        className="shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded bg-amber-500/20 hover:bg-amber-500 hover:text-slate-950 text-amber-200 border border-amber-400/40 text-xs font-mono-tech uppercase tracking-wider transition-all"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        Inspect in 3D
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {AAA_VISUAL_RESEARCH.map((ref) => (
                <div
                  key={ref.game}
                  className="rounded-lg border border-cyan-400/25 bg-slate-900/75 p-5 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-mono-tech uppercase tracking-widest text-cyan-400">
                        {ref.studio}
                      </span>
                      <Compass className="w-4 h-4 text-amber-400" />
                    </div>
                    <h3 className="font-display text-xl font-bold text-white mt-1">
                      {ref.game}
                    </h3>
                    <div className="text-xs font-mono-tech text-amber-300 mt-1">
                      Studied In-Game Environments: {ref.studiedZones}
                    </div>

                    <ul className="mt-3 space-y-2 text-xs text-slate-200">
                      {ref.keyFindings.map((finding, idx) => (
                        <li key={idx} className="flex items-start gap-2 leading-relaxed">
                          <span className="text-amber-400 font-bold mt-0.5">▸</span>
                          <span>{finding}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="mt-4 pt-3 border-t border-white/10 bg-slate-950/60 rounded p-3">
                    <div className="text-[11px] font-mono-tech uppercase text-cyan-300 font-bold">
                      PyQuest Rebirth Level 1 Implementation:
                    </div>
                    <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                      {ref.appliedInPyQuest}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
