import React from 'react';
import { LEVEL1_BUILDINGS } from '../data/level1Data';
import { PlayerTelemetry } from '../types/world';

interface SectorMinimapProps {
  telemetry: PlayerTelemetry;
  onSelectLandmark: (id: string) => void;
}

export const SectorMinimap: React.FC<SectorMinimapProps> = ({
  telemetry,
  onSelectLandmark
}) => {
  // Map world X (-46..46) -> 0..100%, world Z (-132..108) -> 0..100%
  const toMapX = (wx: number) => ((wx + 48) / 96) * 100;
  const toMapY = (wz: number) => ((wz + 132) / 242) * 100;

  const px = toMapX(telemetry.x);
  const py = toMapY(telemetry.z);

  return (
    <div className="hud-panel hud-clip p-2.5 w-44 sm:w-52 select-none">
      <div className="flex items-center justify-between text-[10px] font-mono-tech uppercase tracking-wider text-amber-300/90 mb-1.5">
        <span>SECTOR 01 RADAR</span>
        <span className="text-cyan-300">EXIT {telemetry.distanceToExitGate}M</span>
      </div>

      <div className="relative w-full h-48 rounded bg-slate-950/90 border border-white/10 overflow-hidden">
        {/* Central Ruined Boulevard Corridor */}
        <div
          className="absolute top-0 bottom-0 bg-slate-800/65 border-x border-amber-400/20"
          style={{ left: '39%', width: '22%' }}
        />

        {/* Collapsed Overpass Line */}
        <div
          className="absolute left-2 right-2 h-2 bg-orange-500/35 border-y border-orange-400/50"
          style={{ top: `${toMapY(-14)}%` }}
        />

        {/* Northern Sanctuary Terrace Zone */}
        <div
          className="absolute left-3 right-3 h-7 bg-cyan-500/15 border border-cyan-400/35 rounded-t"
          style={{ top: `${toMapY(-130)}%` }}
        />

        {/* Building & Landmark Nodes */}
        {LEVEL1_BUILDINGS.map((b) => {
          const bx = toMapX(b.position[0]);
          const by = toMapY(b.position[2]);
          const isExit = b.id === 'exit-gate';
          const isEntrance = b.id === 'entrance-arch';
          const isDiscovered = telemetry.discoveredLandmarks.includes(b.id);

          return (
            <button
              key={b.id}
              type="button"
              onClick={() => onSelectLandmark(b.id)}
              style={{ left: `${bx}%`, top: `${by}%` }}
              title={`${b.code}: ${b.name} (Click to inspect)`}
              className={`-translate-x-1/2 -translate-y-1/2 absolute rounded-sm transition-transform hover:scale-150 ${
                isExit
                  ? 'w-3.5 h-3.5 bg-cyan-400 border border-white rotate-45 shadow-md shadow-cyan-400'
                  : isEntrance
                  ? 'w-3 h-2 bg-amber-400 border border-white'
                  : isDiscovered
                  ? 'w-2.5 h-2.5 bg-amber-400/90 border border-slate-950'
                  : 'w-2 h-2 bg-slate-500/80 border border-slate-900'
              }`}
            />
          );
        })}

        {/* Player Position Marker & Camera Heading Arrow */}
        <div
          style={{
            left: `${Math.max(4, Math.min(96, px))}%`,
            top: `${Math.max(4, Math.min(96, py))}%`,
            transform: `translate(-50%, -50%) rotate(${-telemetry.headingDeg}deg)`
          }}
          className="absolute w-4 h-4 flex items-center justify-center pointer-events-none"
        >
          <div className="w-0 h-0 border-l-[5px] border-l-transparent border-r-[5px] border-r-transparent border-b-[10px] border-b-emerald-400 drop-shadow" />
        </div>

        {/* North / South Labels */}
        <span className="absolute top-1 left-1.5 text-[9px] font-mono-tech text-cyan-300/80">
          N // EXIT GATE
        </span>
        <span className="absolute bottom-1 left-1.5 text-[9px] font-mono-tech text-amber-300/70">
          S // ENTRANCE
        </span>
      </div>

      <div className="mt-1.5 flex items-center justify-between text-[10px] font-mono-tech text-slate-400">
        <span>
          POS: {telemetry.x.toFixed(0)}, {telemetry.z.toFixed(0)}
        </span>
        <span>ELEV: {telemetry.y.toFixed(1)}m</span>
      </div>
    </div>
  );
};
