import * as THREE from 'three';
import { FireSiteConfig, SwayingCableNode } from './VehicleAndPropsBuilder';
import { SwayingFoliageNode } from './VegetationBuilder';
import { ExitGateAnimatedRefs } from './ArchitectureBuilder';

interface FlameClusterInstance {
  position: THREE.Vector3;
  radius: number;
  light: THREE.PointLight;
  baseIntensity: number;
  flameCones: THREE.Mesh[];
  smokePuffs: Array<{
    mesh: THREE.Mesh;
    offsetY: number;
    speed: number;
    driftX: number;
    driftZ: number;
  }>;
  emberPoints: THREE.Points;
  emberPositions: Float32Array;
}

export interface EnvironmentalEffectsController {
  update: (dt: number, elapsedTime: number, gateActivated: boolean) => void;
  dispose: () => void;
}

export function setupEnvironmentalEffects(
  scene: THREE.Scene,
  fireSites: FireSiteConfig[],
  swayingFoliage: SwayingFoliageNode[],
  swayingCables: SwayingCableNode[],
  exitGateRefs: ExitGateAnimatedRefs
): EnvironmentalEffectsController {
  const fxGroup = new THREE.Group();
  fxGroup.name = 'EnvironmentalEffectsGroup';
  scene.add(fxGroup);

  // ============================================================================
  // 1. STYLIZED ANIME GOLDEN-HOUR TWILIGHT SKY DOME (1024x512 Volumetric Cloudscape)
  // ============================================================================
  const buildAnimeSkyDome = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 512;
    const ctx = canvas.getContext('2d')!;

    const grad = ctx.createLinearGradient(0, 0, 0, 512);
    grad.addColorStop(0.0, '#0f1629'); // Deep twilight zenith
    grad.addColorStop(0.28, '#1f2c4c'); // Rich anime cobalt-indigo upper sky
    grad.addColorStop(0.52, '#4c3e5b'); // Violet-dusk transition
    grad.addColorStop(0.72, '#9e5456'); // Warm crimson-rose sunset layer
    grad.addColorStop(0.88, '#e3844b'); // Luminous golden-vermilion horizon band
    grad.addColorStop(1.0, '#ffd494'); // Radiant amber-gold mist
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 1024, 512);

    // Subtle zenith stars in upper twilight sky
    for (let s = 0; s < 70; s++) {
      const sx = (s * 149) % 1024;
      const sy = (s * 43) % 145;
      const alpha = 0.25 + (s % 5) * 0.12;
      ctx.fillStyle = `rgba(235, 244, 255, ${alpha})`;
      ctx.fillRect(sx, sy, s % 4 === 0 ? 2 : 1.5, s % 4 === 0 ? 2 : 1.5);
    }

    // Directional golden-hour solar bloom halo
    const sunGrad = ctx.createRadialGradient(280, 345, 8, 280, 345, 220);
    sunGrad.addColorStop(0.0, 'rgba(255, 248, 215, 0.92)');
    sunGrad.addColorStop(0.22, 'rgba(255, 198, 118, 0.55)');
    sunGrad.addColorStop(0.58, 'rgba(236, 118, 68, 0.22)');
    sunGrad.addColorStop(1.0, 'rgba(236, 118, 68, 0.0)');
    ctx.fillStyle = sunGrad;
    ctx.fillRect(40, 110, 480, 400);

    // Multi-layered anime cumulus & stratocumulus cloud banks (shadow base + sunlit gold rim)
    for (let i = 0; i < 36; i++) {
      const cx = (i * 113) % 1024;
      const cy = 215 + (i % 7) * 26;
      const cw = 95 + (i % 5) * 42;
      const ch = 15 + (i % 4) * 7;

      // Sunlit golden-apricot upper cloud rim
      ctx.fillStyle = 'rgba(255, 218, 152, 0.26)';
      ctx.beginPath();
      ctx.ellipse(cx, cy - 4, cw * 0.96, ch * 0.92, 0, 0, Math.PI * 2);
      ctx.fill();

      // Cool dusty-violet cloud belly for anime tonal depth
      ctx.fillStyle = 'rgba(58, 46, 72, 0.24)';
      ctx.beginPath();
      ctx.ellipse(cx + 8, cy + 4, cw, ch * 0.85, 0, 0, Math.PI * 2);
      ctx.fill();
    }

    const skyTex = new THREE.CanvasTexture(canvas);
    skyTex.colorSpace = THREE.SRGBColorSpace;

    const skyDome = new THREE.Mesh(
      new THREE.SphereGeometry(320, 32, 24),
      new THREE.MeshBasicMaterial({
        map: skyTex,
        side: THREE.BackSide,
        depthWrite: false
      })
    );
    fxGroup.add(skyDome);
  };

  buildAnimeSkyDome();

  // ============================================================================
  // 2. ANIMATED FLAMES, RISING SMOKE PLUMES & GLOWING EMBERS AT BURNING VEHICLES
  // ============================================================================
  const flameInnerMat = new THREE.MeshBasicMaterial({
    color: new THREE.Color('#fff29c'),
    transparent: true,
    opacity: 0.92,
    depthWrite: false
  });

  const flameMidMat = new THREE.MeshBasicMaterial({
    color: new THREE.Color('#ff7b24'),
    transparent: true,
    opacity: 0.82,
    depthWrite: false
  });

  const flameOuterMat = new THREE.MeshBasicMaterial({
    color: new THREE.Color('#d9381e'),
    transparent: true,
    opacity: 0.65,
    depthWrite: false
  });

  const flameClusters: FlameClusterInstance[] = [];

  fireSites.forEach((site, idx) => {
    const siteGroup = new THREE.Group();
    siteGroup.position.copy(site.position);
    fxGroup.add(siteGroup);

    // Dynamic flickering orange fire light
    const light = new THREE.PointLight('#ff7728', site.intensity * 3.2, 18, 1.6);
    light.position.set(0, 1.2, 0);
    siteGroup.add(light);

    // Multi-layered sculpted flame tongues
    const flameCones: THREE.Mesh[] = [];
    const tongueCount = 7;
    for (let t = 0; t < tongueCount; t++) {
      const r = (0.28 + (t % 3) * 0.14) * site.radius;
      const h = (1.15 + (t % 3) * 0.45) * site.radius;
      const mat = t === 0 ? flameInnerMat : t < 4 ? flameMidMat : flameOuterMat;

      const cone = new THREE.Mesh(new THREE.ConeGeometry(r, h, 6), mat);
      const ang = (t / tongueCount) * Math.PI * 2;
      const dist = t === 0 ? 0 : 0.25 * site.radius;
      cone.position.set(Math.cos(ang) * dist, h * 0.42, Math.sin(ang) * dist);
      siteGroup.add(cone);
      flameCones.push(cone);
    }

    // Rising Dark Smoke Plume Puffs
    const smokePuffs: FlameClusterInstance['smokePuffs'] = [];
    for (let s = 0; s < 9; s++) {
      const smokeMat = new THREE.MeshBasicMaterial({
        color: new THREE.Color(s < 3 ? '#2c2729' : '#1d1b1e'),
        transparent: true,
        opacity: 0.36,
        depthWrite: false
      });
      const puff = new THREE.Mesh(new THREE.DodecahedronGeometry(0.48 * site.radius, 1), smokeMat);
      const offsetY = (s / 9) * 7.5;
      puff.position.set(0, offsetY + 1.0, 0);
      siteGroup.add(puff);

      smokePuffs.push({
        mesh: puff,
        offsetY,
        speed: 1.35 + (s % 3) * 0.25,
        driftX: ((s % 3) - 1) * 0.32,
        driftZ: (((s + 1) % 3) - 1) * 0.28
      });
    }

    // Spiraling Upward Glowing Embers
    const emberCount = 28;
    const emberPositions = new Float32Array(emberCount * 3);
    for (let e = 0; e < emberCount; e++) {
      emberPositions[e * 3] = (Math.random() - 0.5) * 1.6 * site.radius;
      emberPositions[e * 3 + 1] = Math.random() * 6.5;
      emberPositions[e * 3 + 2] = (Math.random() - 0.5) * 1.6 * site.radius;
    }

    const emberGeo = new THREE.BufferGeometry();
    emberGeo.setAttribute('position', new THREE.BufferAttribute(emberPositions, 3));
    const emberMat = new THREE.PointsMaterial({
      color: new THREE.Color(idx % 2 === 0 ? '#ffae42' : '#ff682b'),
      size: 0.14,
      transparent: true,
      opacity: 0.92,
      depthWrite: false
    });
    const emberPoints = new THREE.Points(emberGeo, emberMat);
    siteGroup.add(emberPoints);

    flameClusters.push({
      position: site.position,
      radius: site.radius,
      light,
      baseIntensity: site.intensity * 3.2,
      flameCones,
      smokePuffs,
      emberPoints,
      emberPositions
    });
  });

  // ============================================================================
  // 3. FLOATING ATMOSPHERIC DUST & GOLDEN RESONANCE MOTES ACROSS LEVEL 1
  // ============================================================================
  const dustCount = 380;
  const dustPositions = new Float32Array(dustCount * 3);
  for (let i = 0; i < dustCount; i++) {
    dustPositions[i * 3] = (Math.random() - 0.5) * 84;
    dustPositions[i * 3 + 1] = 0.5 + Math.random() * 16;
    dustPositions[i * 3 + 2] = -126 + Math.random() * 232;
  }

  const dustGeo = new THREE.BufferGeometry();
  dustGeo.setAttribute('position', new THREE.BufferAttribute(dustPositions, 3));
  const dustMat = new THREE.PointsMaterial({
    color: new THREE.Color('#ffe2b0'),
    size: 0.16,
    transparent: true,
    opacity: 0.58,
    depthWrite: false
  });
  const atmosphericDust = new THREE.Points(dustGeo, dustMat);
  fxGroup.add(atmosphericDust);

  // ============================================================================
  // 4. REAL-TIME FRAME UPDATE LOOP WITH PARTICLE RECYCLING
  // ============================================================================
  const update = (dt: number, elapsedTime: number, gateActivated: boolean) => {
    // 1) Update Animated Flames, Smoke & Embers with Full Origin Recycling
    for (let i = 0; i < flameClusters.length; i++) {
      const fc = flameClusters[i];

      // Flickering point light
      fc.light.intensity =
        fc.baseIntensity +
        Math.sin(elapsedTime * 15 + i * 3) * 0.65 +
        Math.cos(elapsedTime * 23 + i) * 0.45;

      // Animate flame tongues
      for (let t = 0; t < fc.flameCones.length; t++) {
        const cone = fc.flameCones[t];
        const wave = Math.sin(elapsedTime * 11 + t * 1.7 + i);
        cone.scale.y = 0.85 + Math.abs(wave) * 0.42;
        cone.scale.x = 0.9 + Math.cos(elapsedTime * 9 + t) * 0.16;
        cone.scale.z = 0.9 + Math.sin(elapsedTime * 8 + t) * 0.16;
        cone.rotation.z = wave * 0.18;
        cone.rotation.x = Math.cos(elapsedTime * 10 + t) * 0.14;
      }

      // Animate rising smoke plumes
      for (let s = 0; s < fc.smokePuffs.length; s++) {
        const sp = fc.smokePuffs[s];
        sp.offsetY += dt * sp.speed;
        if (sp.offsetY > 7.5) {
          sp.offsetY = 0.35;
        }
        const progress = sp.offsetY / 7.5;
        sp.mesh.position.y = 1.0 + sp.offsetY;
        sp.mesh.position.x = Math.sin(elapsedTime * 1.8 + s) * 0.35 + sp.driftX * progress * 2.2;
        sp.mesh.position.z = Math.cos(elapsedTime * 1.5 + s) * 0.35 + sp.driftZ * progress * 2.2;

        const scale = 0.65 + progress * 1.85;
        sp.mesh.scale.set(scale, scale * 0.85, scale);
        const mat = sp.mesh.material as THREE.MeshBasicMaterial;
        mat.opacity = Math.sin(progress * Math.PI) * 0.36;
      }

      // Animate upward-spiraling embers & recycle X/Y/Z cleanly to fire emitter base
      const posAttr = fc.emberPoints.geometry.getAttribute('position') as THREE.BufferAttribute;
      const count = fc.emberPositions.length / 3;
      const maxRadius = 1.15 * fc.radius;
      for (let e = 0; e < count; e++) {
        const idx3 = e * 3;
        let ex = fc.emberPositions[idx3] + Math.sin(elapsedTime * 3.5 + e) * dt * 0.35;
        let ey = fc.emberPositions[idx3 + 1] + dt * (1.8 + (e % 4) * 0.45);
        let ez = fc.emberPositions[idx3 + 2] + Math.cos(elapsedTime * 3.1 + e) * dt * 0.35;

        if (ey > 6.8 || ex * ex + ez * ez > maxRadius * maxRadius * 3.2) {
          const spawnAngle = elapsedTime * 2.1 + e * 1.618;
          const spawnR = ((e % 7) / 7) * 0.68 * fc.radius;
          ex = Math.cos(spawnAngle) * spawnR;
          ey = 0.22 + (e % 5) * 0.09;
          ez = Math.sin(spawnAngle) * spawnR;
        }

        fc.emberPositions[idx3] = ex;
        fc.emberPositions[idx3 + 1] = ey;
        fc.emberPositions[idx3 + 2] = ez;
      }
      posAttr.needsUpdate = true;
    }

    // 2) Update Floating Atmospheric Dust Motes with Sector Boundary Recycling
    const dustAttr = atmosphericDust.geometry.getAttribute('position') as THREE.BufferAttribute;
    for (let i = 0; i < dustCount; i++) {
      const idx3 = i * 3;
      let dx = dustPositions[idx3] + Math.sin(elapsedTime * 0.4 + i) * dt * 0.14;
      let dy = dustPositions[idx3 + 1] + (0.04 + (i % 3) * 0.02) * dt;
      let dz = dustPositions[idx3 + 2] + Math.cos(elapsedTime * 0.35 + i * 0.7) * dt * 0.1;

      if (dy > 16.5) dy = 0.5;
      if (dx > 42) dx = -42;
      else if (dx < -42) dx = 42;
      if (dz > 106) dz = -126;
      else if (dz < -126) dz = 106;

      dustPositions[idx3] = dx;
      dustPositions[idx3 + 1] = dy;
      dustPositions[idx3 + 2] = dz;
    }
    dustAttr.needsUpdate = true;

    // 3) Update Organic Tree & Foliage Wind Sway
    for (let i = 0; i < swayingFoliage.length; i++) {
      const node = swayingFoliage[i];
      const w = Math.sin(elapsedTime * 1.85 + node.phase) * node.amplitude;
      node.object.rotation.z = node.baseRotZ + w;
      node.object.rotation.x = node.baseRotX + w * 0.6;
    }

    // 4) Subtle Wind Oscillation on Hanging Catenary Power Cables
    for (let i = 0; i < swayingCables.length; i++) {
      const c = swayingCables[i];
      c.mesh.rotation.z = Math.sin(elapsedTime * 1.6 + c.phase) * 0.008;
    }

    // 5) Animate Monumental Level 1 Astral Exit Gate
    const speedMult = gateActivated ? 3.8 : 1.0;
    exitGateRefs.outerRing.rotation.z += dt * 0.32 * speedMult;
    exitGateRefs.innerRing.rotation.z -= dt * 0.54 * speedMult;
    exitGateRefs.innerRing.rotation.y = Math.sin(elapsedTime * 0.9) * 0.28;

    exitGateRefs.coreCrystal.rotation.y += dt * 1.1 * speedMult;
    exitGateRefs.coreCrystal.rotation.x += dt * 0.65 * speedMult;
    exitGateRefs.coreCrystal.position.y = 12.2 + Math.sin(elapsedTime * 2.2) * 0.38;

    const portalMat = exitGateRefs.portalField.material as THREE.MeshBasicMaterial;
    portalMat.opacity = gateActivated
      ? 0.48 + Math.sin(elapsedTime * 6.0) * 0.14
      : 0.15 + Math.sin(elapsedTime * 2.4) * 0.05;

    exitGateRefs.beaconLight.intensity = gateActivated
      ? 7.5 + Math.sin(elapsedTime * 8.0) * 1.5
      : 3.5 + Math.sin(elapsedTime * 2.5) * 0.6;
  };

  const dispose = () => {
    fxGroup.traverse((obj) => {
      if ((obj as THREE.Mesh).geometry) {
        (obj as THREE.Mesh).geometry.dispose();
      }
      const mat = (obj as THREE.Mesh).material;
      if (Array.isArray(mat)) {
        mat.forEach((m) => {
          if ((m as THREE.MeshBasicMaterial).map) {
            (m as THREE.MeshBasicMaterial).map?.dispose();
          }
          m.dispose();
        });
      } else if (mat) {
        if ((mat as THREE.MeshBasicMaterial).map) {
          (mat as THREE.MeshBasicMaterial).map?.dispose();
        }
        mat.dispose();
      }
    });
  };

  return { update, dispose };
}
