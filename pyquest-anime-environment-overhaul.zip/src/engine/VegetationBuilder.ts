import * as THREE from 'three';
import { MaterialLibrary } from './TextureFactory';
import { PhysicsWorld } from './PhysicsWorld';

export interface SwayingFoliageNode {
  object: THREE.Object3D;
  baseRotZ: number;
  baseRotX: number;
  phase: number;
  amplitude: number;
}

export function buildLevelVegetation(
  scene: THREE.Scene,
  mats: MaterialLibrary,
  physics: PhysicsWorld
): SwayingFoliageNode[] {
  const foliageRoot = new THREE.Group();
  foliageRoot.name = 'OrganicVegetationGroup';
  scene.add(foliageRoot);

  const swayingNodes: SwayingFoliageNode[] = [];

  const sharedUnitLeafPlane = new THREE.PlaneGeometry(1, 1);

  // Helper to create a layered anime leaf card cluster (crossed planes at multiple angles, never spheres!)
  const createLeafBoughCluster = (
    radius: number,
    matPrimary: THREE.Material,
    matHighlight: THREE.Material,
    seed: number
  ): THREE.Group => {
    const cluster = new THREE.Group();

    const planeCount = 5;
    for (let i = 0; i < planeCount; i++) {
      const w = radius * (1.22 + ((i * 17 + seed) % 5) * 0.12);
      const h = radius * (1.02 + ((i * 13 + seed) % 4) * 0.1);
      const mat = i >= 3 ? matHighlight : matPrimary;
      const card = new THREE.Mesh(sharedUnitLeafPlane, mat);
      card.scale.set(w, h, 1);

      const angle = (i / planeCount) * Math.PI * 2 + seed * 0.4;
      const radialOffset = radius * 0.2;
      card.position.set(
        Math.cos(angle) * radialOffset,
        ((i % 3) - 1) * radius * 0.15,
        Math.sin(angle) * radialOffset
      );

      // Pitch leaf cards slightly like layered umbrella boughs
      card.rotation.order = 'YXZ';
      card.rotation.y = angle + Math.PI * 0.5;
      card.rotation.x = 0.35 + (i % 3) * 0.22;
      card.rotation.z = ((i % 2) * 2 - 1) * 0.18;

      card.castShadow = i < 3;
      card.receiveShadow = false;
      cluster.add(card);
    }

    return cluster;
  };

  // Builds a natural asymmetrical tree with surface roots, 3-stage curving trunk, forked primary/secondary limbs, and layered leaf canopies
  const createOrganicTree = (
    x: number,
    y: number,
    z: number,
    scale: number,
    seed: number,
    isAutumnAccent = false
  ) => {
    const treeGroup = new THREE.Group();
    treeGroup.position.set(x, y, z);
    foliageRoot.add(treeGroup);

    // Register trunk collision
    physics.addCylinder(`tree_${seed}_${x.toFixed(0)}`, x, z, 0.55 * scale, y, y + 6 * scale);

    // Cracked soil/concrete root mound & sidewalk tree-pit curb surround at base
    const mound = new THREE.Mesh(
      new THREE.CylinderGeometry(0.95 * scale, 1.45 * scale, 0.26 * scale, 9),
      mats.treeBark
    );
    mound.position.y = 0.11 * scale;
    mound.receiveShadow = true;
    treeGroup.add(mound);

    const pitCurb = new THREE.Mesh(
      new THREE.BoxGeometry(2.65 * scale, 0.18 * scale, 2.65 * scale),
      mats.concreteDark
    );
    pitCurb.position.y = 0.08 * scale;
    pitCurb.receiveShadow = true;
    treeGroup.add(pitCurb);

    // 1. Gnarled Surface Roots gripping pavement
    const rootCount = 5;
    for (let r = 0; r < rootCount; r++) {
      const rAngle = (r / rootCount) * Math.PI * 2 + (seed % 7) * 0.25;
      const rootPivot = new THREE.Group();
      rootPivot.rotation.y = rAngle;
      treeGroup.add(rootPivot);

      const rootSeg1 = new THREE.Mesh(
        new THREE.CylinderGeometry(0.14 * scale, 0.22 * scale, 1.05 * scale, 7),
        mats.treeBark
      );
      rootSeg1.position.set(0.42 * scale, 0.28 * scale, 0);
      rootSeg1.rotation.z = 1.08;
      rootSeg1.castShadow = true;
      rootSeg1.receiveShadow = true;
      rootPivot.add(rootSeg1);

      const rootTip = new THREE.Mesh(
        new THREE.CylinderGeometry(0.05 * scale, 0.13 * scale, 0.85 * scale, 6),
        mats.treeBark
      );
      rootTip.position.set(1.05 * scale, 0.08 * scale, 0.08 * scale);
      rootTip.rotation.z = 1.42;
      rootTip.castShadow = true;
      rootPivot.add(rootTip);
    }

    // 2. Multi-stage curving trunk
    const leanX = ((seed % 5) - 2) * 0.06;
    const leanZ = (((seed * 3) % 5) - 2) * 0.06;

    const lowerTrunk = new THREE.Mesh(
      new THREE.CylinderGeometry(0.34 * scale, 0.48 * scale, 1.9 * scale, 9),
      mats.treeBark
    );
    lowerTrunk.position.set(0, 0.92 * scale, 0);
    lowerTrunk.rotation.set(leanX, seed * 0.5, leanZ);
    lowerTrunk.castShadow = true;
    lowerTrunk.receiveShadow = true;
    treeGroup.add(lowerTrunk);

    const midTrunk = new THREE.Group();
    midTrunk.position.set(leanZ * -1.4 * scale, 1.78 * scale, leanX * 1.4 * scale);
    midTrunk.rotation.set(leanX * 1.4, 0, -leanZ * 1.2);
    treeGroup.add(midTrunk);

    const midTrunkMesh = new THREE.Mesh(
      new THREE.CylinderGeometry(0.24 * scale, 0.34 * scale, 1.85 * scale, 8),
      mats.treeBark
    );
    midTrunkMesh.position.y = 0.88 * scale;
    midTrunkMesh.castShadow = true;
    midTrunkMesh.receiveShadow = true;
    midTrunk.add(midTrunkMesh);

    const crownPivot = new THREE.Group();
    crownPivot.position.set(0, 1.72 * scale, 0);
    midTrunk.add(crownPivot);

    // 3. Forked Primary & Secondary Branches + Canopy Boughs
    const primaryCount = 4 + (seed % 2);
    const primaryMat = isAutumnAccent ? mats.foliageAutumn : mats.foliageCanopy;
    const highlightMat = isAutumnAccent ? mats.foliageAutumn : mats.foliageSunlit;

    for (let b = 0; b < primaryCount; b++) {
      const bAngle = (b / primaryCount) * Math.PI * 2 + seed * 0.6;
      const pitch = 0.52 + ((b + seed) % 3) * 0.14;
      const branchLen = (2.1 + ((b * 7 + seed) % 4) * 0.35) * scale;

      const branchPivot = new THREE.Group();
      branchPivot.rotation.y = bAngle;
      branchPivot.rotation.z = pitch;
      crownPivot.add(branchPivot);

      const branchMesh = new THREE.Mesh(
        new THREE.CylinderGeometry(0.09 * scale, 0.19 * scale, branchLen, 7),
        mats.treeBark
      );
      branchMesh.position.y = branchLen * 0.48;
      branchMesh.castShadow = true;
      branchMesh.receiveShadow = true;
      branchPivot.add(branchMesh);

      // Sub-branch fork
      const subPivot = new THREE.Group();
      subPivot.position.set(0, branchLen * 0.68, 0);
      subPivot.rotation.z = -0.48;
      subPivot.rotation.x = 0.35;
      branchPivot.add(subPivot);

      const subLen = branchLen * 0.62;
      const subMesh = new THREE.Mesh(
        new THREE.CylinderGeometry(0.045 * scale, 0.095 * scale, subLen, 6),
        mats.treeBark
      );
      subMesh.position.y = subLen * 0.48;
      subMesh.castShadow = true;
      subPivot.add(subMesh);

      // Main bough leaf canopy at primary branch tip
      const tipCanopy = createLeafBoughCluster(1.85 * scale, primaryMat, highlightMat, seed + b * 11);
      tipCanopy.position.set(0, branchLen * 0.96, 0);
      // Counter-rotate so leaf umbrella stays mostly horizontal in world space
      tipCanopy.rotation.z = -pitch * 0.85;
      branchPivot.add(tipCanopy);

      swayingNodes.push({
        object: tipCanopy,
        baseRotZ: tipCanopy.rotation.z,
        baseRotX: tipCanopy.rotation.x,
        phase: seed + b * 1.3,
        amplitude: 0.055
      });

      // Secondary bough leaf canopy at sub-branch tip
      const subCanopy = createLeafBoughCluster(1.38 * scale, primaryMat, highlightMat, seed + b * 23);
      subCanopy.position.set(0, subLen * 0.95, 0);
      subPivot.add(subCanopy);

      swayingNodes.push({
        object: subCanopy,
        baseRotZ: subCanopy.rotation.z,
        baseRotX: subCanopy.rotation.x,
        phase: seed + b * 2.1,
        amplitude: 0.07
      });
    }

    // Upper central crown bough
    const topSpire = new THREE.Mesh(
      new THREE.CylinderGeometry(0.06 * scale, 0.15 * scale, 1.6 * scale, 7),
      mats.treeBark
    );
    topSpire.position.y = 0.78 * scale;
    topSpire.rotation.z = 0.14;
    topSpire.castShadow = true;
    crownPivot.add(topSpire);

    const crownCanopy = createLeafBoughCluster(2.15 * scale, primaryMat, highlightMat, seed + 99);
    crownCanopy.position.set(0, 1.65 * scale, 0);
    crownPivot.add(crownCanopy);

    swayingNodes.push({
      object: crownCanopy,
      baseRotZ: 0,
      baseRotX: 0,
      phase: seed * 0.7,
      amplitude: 0.045
    });
  };

  // Curated, art-directed placement of 22 organic trees framing the ruined boulevard, plazas, and collapsed buildings
  const treePlacements: Array<[number, number, number, number, number, boolean]> = [
    // South Entrance Plaza flanks
    [-16.5, 0.24, 94, 1.15, 1, false],
    [17.5, 0.24, 92, 1.25, 2, true],
    [-14.2, 0.24, 72, 1.05, 3, false],
    [15.0, 0.24, 68, 1.18, 4, false],

    // Mid-South Boulevard & Aegis Terminal / Kurokawa Hab-Block sidewalks
    [-13.8, 0.24, 44, 1.22, 5, true],
    [14.2, 0.24, 38, 1.08, 6, false],
    [-36.0, 0, 36, 1.35, 7, false],
    [37.0, 0, 32, 1.3, 8, true],

    // Around Helion Research Annex (B3) & Vermillion Arcade (B4)
    [-13.2, 0.24, 4, 1.12, 9, false],
    [13.6, 0.24, 2, 1.28, 10, false],
    [-38.0, 0, -2, 1.4, 11, true],

    // North of Collapsed Overpass & Sunken Civic Archives (B6)
    [-14.5, 0.24, -28, 1.25, 12, true],
    [15.2, 0.24, -26, 1.14, 13, false],
    [-21.5, 0, -54, 1.32, 14, false],
    [14.5, 0.24, -52, 1.18, 15, true],

    // North Boulevard approaching Meridian Skyscraper (B8) & Substation (B7)
    [-14.0, 0.24, -66, 1.1, 16, false],
    [14.4, 0.24, -84, 1.24, 17, false],
    [-15.5, 0.24, -88, 1.28, 18, true],

    // Elevated Northern Sanctuary Terrace flanking the Level 1 Exit Gate
    [-17.5, 3.2, -112, 1.38, 19, true],
    [17.5, 3.2, -112, 1.38, 20, true],
    [-23.0, 3.2, -124, 1.48, 21, false],
    [23.0, 3.2, -124, 1.48, 22, false]
  ];

  treePlacements.forEach(([x, y, z, scale, seed, isAutumn]) => {
    createOrganicTree(x, y, z, scale, seed, isAutumn);
  });

  // Ground fern/overgrowth tufts bursting through cracked asphalt & sidewalk joints
  const createOvergrowthClump = (x: number, y: number, z: number, scale: number, seed: number) => {
    const clump = new THREE.Group();
    clump.position.set(x, y, z);
    foliageRoot.add(clump);

    for (let i = 0; i < 4; i++) {
      const card = new THREE.Mesh(
        new THREE.PlaneGeometry(1.35 * scale, 0.95 * scale),
        i % 2 === 0 ? mats.foliageCanopy : mats.foliageSunlit
      );
      card.position.y = 0.38 * scale;
      card.rotation.y = (i / 4) * Math.PI + seed * 0.3;
      card.rotation.x = 0.22;
      card.castShadow = true;
      clump.add(card);
    }

    swayingNodes.push({
      object: clump,
      baseRotZ: 0,
      baseRotX: 0,
      phase: seed * 1.1,
      amplitude: 0.06
    });
  };

  const overgrowthCoords: Array<[number, number, number, number]> = [
    [-6.5, 0, 78, 0.9],
    [7.2, 0, 62, 1.0],
    [-11.8, 0.24, 51, 1.1],
    [11.9, 0.24, 46, 0.95],
    [-18.5, 0, 25, 1.25],
    [-12.0, 0.24, 12, 1.0],
    [8.4, 0, -5, 1.1],
    [-9.2, 0, -21, 1.15],
    [-22.0, 0, -35, 1.3],
    [12.2, 0.24, -44, 1.0],
    [-11.5, 0.24, -59, 1.05],
    [9.5, 0, -76, 1.1],
    [-12.5, 0.24, -93, 1.15],
    [12.5, 0.24, -95, 1.15],
    [-11.0, 3.2, -110, 1.2],
    [11.0, 3.2, -110, 1.2]
  ];

  overgrowthCoords.forEach(([x, y, z, sc], idx) => {
    createOvergrowthClump(x, y, z, sc, idx + 100);
  });

  // Hanging ivy drapes cascading down collapsed concrete walls & overpass edges
  const createIvyDrape = (x: number, y: number, z: number, rotY: number, width: number, height: number) => {
    const drapeGroup = new THREE.Group();
    drapeGroup.position.set(x, y, z);
    drapeGroup.rotation.y = rotY;
    foliageRoot.add(drapeGroup);

    const strips = Math.max(2, Math.floor(width / 1.2));
    for (let s = 0; s < strips; s++) {
      const sx = (s - (strips - 1) * 0.5) * 1.15;
      const sh = height * (0.75 + (s % 3) * 0.15);
      const plane = new THREE.Mesh(
        new THREE.PlaneGeometry(1.35, sh),
        s % 2 === 0 ? mats.foliageCanopy : mats.foliageSunlit
      );
      plane.position.set(sx, -sh * 0.45, 0.08);
      drapeGroup.add(plane);
    }
  };

  // Drape ivy on the Entrance Arch, Helion Annex, Overpass deck edge, Hab-Block, Skybridge & Civic Archives
  createIvyDrape(-11.5, 11.5, 83.2, 0, 4.2, 5.5);
  createIvyDrape(11.5, 12.0, 88.8, Math.PI, 4.0, 5.0);
  createIvyDrape(17.5, 8.0, 55.2, -Math.PI * 0.5, 4.8, 3.8);
  createIvyDrape(-18.2, 6.8, 18.0, Math.PI * 0.5, 5.5, 4.2);
  createIvyDrape(15.2, 8.2, 18.5, -Math.PI * 0.5, 3.6, 3.4);
  createIvyDrape(-6.0, 5.4, -11.2, 0, 5.0, 3.8);
  createIvyDrape(-20.2, 7.2, -42.0, Math.PI * 0.5, 6.0, 4.8);
  createIvyDrape(-21.5, 11.0, -76.0, Math.PI * 0.5, 5.2, 4.5);

  return swayingNodes;
}
