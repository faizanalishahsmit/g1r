import * as THREE from 'three';
import { MaterialLibrary } from './TextureFactory';
import { PhysicsWorld } from './PhysicsWorld';

export interface FireSiteConfig {
  id: string;
  position: THREE.Vector3;
  intensity: number;
  radius: number;
}

export interface SwayingCableNode {
  mesh: THREE.Mesh;
  baseY: number;
  phase: number;
}

export function buildVehiclesAndInfrastructureProps(
  scene: THREE.Scene,
  mats: MaterialLibrary,
  physics: PhysicsWorld
): { fireSites: FireSiteConfig[]; swayingCables: SwayingCableNode[] } {
  const propsGroup = new THREE.Group();
  propsGroup.name = 'VehiclesAndStreetInfrastructure';
  scene.add(propsGroup);

  const fireSites: FireSiteConfig[] = [];
  const swayingCables: SwayingCableNode[] = [];

  // Helper: Detailed Wheel with Tire & Alloy Rim
  const createWheel = (radius: number, width: number): THREE.Group => {
    const wg = new THREE.Group();
    const tire = new THREE.Mesh(
      new THREE.CylinderGeometry(radius, radius, width, 14),
      mats.charredVehicle
    );
    tire.rotation.z = Math.PI * 0.5;
    tire.castShadow = true;
    wg.add(tire);

    const rim = new THREE.Mesh(
      new THREE.CylinderGeometry(radius * 0.58, radius * 0.58, width + 0.02, 10),
      mats.rustedSteel
    );
    rim.rotation.z = Math.PI * 0.5;
    wg.add(rim);
    return wg;
  };

  // 1. Detailed Ruined City Transit Bus (Multi-part chassis, window pillars, roof HVAC pods, bumpers, wheels, interior seats)
  const createRuinedTransitBus = (
    id: string,
    x: number,
    y: number,
    z: number,
    rotY: number,
    tiltZ: number,
    isBurning: boolean
  ) => {
    const bus = new THREE.Group();
    bus.position.set(x, y, z);
    bus.rotation.set(0, rotY, tiltZ);
    propsGroup.add(bus);

    const bodyMat = isBurning ? mats.charredVehicle : mats.transitBusPaint;

    // Lower chassis skirt
    const lowerHull = new THREE.Mesh(new THREE.BoxGeometry(2.75, 1.15, 9.6), bodyMat);
    lowerHull.position.y = 0.95;
    lowerHull.castShadow = true;
    lowerHull.receiveShadow = true;
    bus.add(lowerHull);

    // Front & Rear bumpers
    const frontBumper = new THREE.Mesh(new THREE.BoxGeometry(2.85, 0.36, 0.35), mats.darkSteel);
    frontBumper.position.set(0, 0.58, 4.88);
    frontBumper.rotation.z = 0.06;
    bus.add(frontBumper);

    const rearBumper = new THREE.Mesh(new THREE.BoxGeometry(2.85, 0.38, 0.32), mats.darkSteel);
    rearBumper.position.set(0, 0.58, -4.85);
    bus.add(rearBumper);

    // Roof deck & 2 rooftop HVAC cooling units
    const roof = new THREE.Mesh(new THREE.BoxGeometry(2.68, 0.24, 9.4), bodyMat);
    roof.position.y = 2.86;
    roof.castShadow = true;
    bus.add(roof);

    const hvac1 = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.32, 2.1), mats.rustedSteel);
    hvac1.position.set(0, 3.12, 1.6);
    hvac1.castShadow = true;
    bus.add(hvac1);

    const hvac2 = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.28, 1.8), mats.rustedSteel);
    hvac2.position.set(0, 3.1, -2.0);
    hvac2.castShadow = true;
    bus.add(hvac2);

    // Window Mullion Pillars along both sides (open cabin interior visible!)
    for (let pz = -4.4; pz <= 4.4; pz += 1.45) {
      const pL = new THREE.Mesh(new THREE.BoxGeometry(0.14, 1.25, 0.22), bodyMat);
      pL.position.set(1.3, 2.15, pz);
      pL.castShadow = true;
      bus.add(pL);

      const pR = new THREE.Mesh(new THREE.BoxGeometry(0.14, 1.25, 0.22), bodyMat);
      pR.position.set(-1.3, 2.15, pz);
      pR.castShadow = true;
      bus.add(pR);
    }

    // Broken jagged glass panes in some bus windows
    for (let wz = -3.6; wz <= 3.6; wz += 2.9) {
      const glassPane = new THREE.Mesh(new THREE.PlaneGeometry(1.15, 0.95), mats.windowShard);
      glassPane.position.set(1.31, 2.1, wz);
      glassPane.rotation.y = Math.PI * 0.5;
      bus.add(glassPane);
    }

    // Interior passenger seat rows visible through open shattered windows
    for (let sz = -3.4; sz <= 2.8; sz += 1.25) {
      const seatL = new THREE.Mesh(new THREE.BoxGeometry(0.65, 0.58, 0.45), mats.rustedSteel);
      seatL.position.set(0.82, 1.65, sz);
      bus.add(seatL);

      const seatR = new THREE.Mesh(new THREE.BoxGeometry(0.65, 0.58, 0.45), mats.rustedSteel);
      seatR.position.set(-0.82, 1.65, sz);
      bus.add(seatR);
    }

    // 6 Articulated Bus Wheels
    const wheelZ = [-3.1, -1.7, 3.0];
    wheelZ.forEach((wz) => {
      const wL = createWheel(0.52, 0.34);
      wL.position.set(1.36, 0.52, wz);
      bus.add(wL);

      const wR = createWheel(0.52, 0.34);
      wR.position.set(-1.36, 0.52, wz);
      bus.add(wR);
    });

    // Register AABB collision
    const isEastWest = Math.abs(Math.sin(rotY)) > 0.65;
    physics.addBox(
      id,
      x,
      y + 1.6,
      z,
      isEastWest ? 9.2 : 3.2,
      3.2,
      isEastWest ? 3.2 : 9.2,
      false
    );

    if (isBurning) {
      fireSites.push({
        id: `${id}_fire_main`,
        position: new THREE.Vector3(x, y + 1.45, z + 0.5),
        intensity: 1.35,
        radius: 1.45
      });
      fireSites.push({
        id: `${id}_fire_engine`,
        position: new THREE.Vector3(x + 0.6, y + 0.9, z - 2.2),
        intensity: 0.95,
        radius: 0.95
      });
    }
  };

  // 2. Detailed Abandoned / Destroyed Sedan (Lower body, sloped cabin roof, windshield frame, hood, trunk, 4 wheels)
  const createRuinedSedan = (
    id: string,
    x: number,
    y: number,
    z: number,
    rotY: number,
    pitchX: number,
    paintMat: THREE.Material,
    isBurning: boolean
  ) => {
    const car = new THREE.Group();
    car.position.set(x, y, z);
    car.rotation.set(pitchX, rotY, 0);
    propsGroup.add(car);

    const mat = isBurning ? mats.charredVehicle : paintMat;

    // Lower chassis body
    const chassis = new THREE.Mesh(new THREE.BoxGeometry(1.92, 0.62, 4.35), mat);
    chassis.position.y = 0.64;
    chassis.castShadow = true;
    chassis.receiveShadow = true;
    car.add(chassis);

    // Tapered upper cabin greenhouse
    const cabin = new THREE.Mesh(new THREE.BoxGeometry(1.66, 0.54, 2.15), mat);
    cabin.position.set(0, 1.18, -0.15);
    cabin.castShadow = true;
    car.add(cabin);

    // Sloped front windshield glass & rear window
    const windshield = new THREE.Mesh(new THREE.PlaneGeometry(1.52, 0.68), mats.windowIntact);
    windshield.position.set(0, 1.16, 1.02);
    windshield.rotation.x = -0.68;
    car.add(windshield);

    const rearGlass = new THREE.Mesh(new THREE.PlaneGeometry(1.48, 0.62), mats.windowIntact);
    rearGlass.position.set(0, 1.16, -1.28);
    rearGlass.rotation.x = Math.PI + 0.62;
    car.add(rearGlass);

    // Popped crumpled front hood
    const hood = new THREE.Mesh(new THREE.BoxGeometry(1.78, 0.08, 1.15), mat);
    hood.position.set(0, 1.04, 1.55);
    hood.rotation.x = isBurning ? -0.35 : -0.12;
    hood.castShadow = true;
    car.add(hood);

    // Bumpers & Headlight housings
    const fBumper = new THREE.Mesh(new THREE.BoxGeometry(1.98, 0.26, 0.22), mats.darkSteel);
    fBumper.position.set(0, 0.45, 2.2);
    car.add(fBumper);

    const rBumper = new THREE.Mesh(new THREE.BoxGeometry(1.98, 0.26, 0.22), mats.darkSteel);
    rBumper.position.set(0, 0.45, -2.2);
    car.add(rBumper);

    // 4 Wheels
    const wheelOffsets: Array<[number, number]> = [
      [0.94, 1.32],
      [-0.94, 1.32],
      [0.94, -1.32],
      [-0.94, -1.32]
    ];
    wheelOffsets.forEach(([wx, wz]) => {
      const w = createWheel(0.36, 0.24);
      w.position.set(wx, 0.36, wz);
      car.add(w);
    });

    physics.addBox(id, x, y + 0.9, z, 2.8, 1.8, 4.4, false);

    if (isBurning) {
      fireSites.push({
        id: `${id}_fire`,
        position: new THREE.Vector3(x, y + 0.95, z + 0.7),
        intensity: 1.05,
        radius: 1.0
      });
    }
  };

  // 3. Abandoned Heavy Evacuation Logistics Truck (Cab + Flatbed Frame + Container Shell)
  const createEvacuationTruck = (
    id: string,
    x: number,
    y: number,
    z: number,
    rotY: number
  ) => {
    const truck = new THREE.Group();
    truck.position.set(x, y, z);
    truck.rotation.y = rotY;
    propsGroup.add(truck);

    // Forward armored cab
    const cab = new THREE.Mesh(new THREE.BoxGeometry(2.5, 2.1, 2.3), mats.rustedSteel);
    cab.position.set(0, 1.55, 2.6);
    cab.castShadow = true;
    cab.receiveShadow = true;
    truck.add(cab);

    const cabGlass = new THREE.Mesh(new THREE.PlaneGeometry(2.1, 0.82), mats.windowIntact);
    cabGlass.position.set(0, 1.95, 3.76);
    truck.add(cabGlass);

    // Rear cargo container with weathered ribs
    const cargo = new THREE.Mesh(new THREE.BoxGeometry(2.65, 2.45, 5.2), mats.concreteDark);
    cargo.position.set(0, 1.85, -1.35);
    cargo.castShadow = true;
    cargo.receiveShadow = true;
    truck.add(cargo);

    // 6 Heavy Truck Wheels
    [-2.8, -1.2, 2.5].forEach((wz) => {
      const wL = createWheel(0.54, 0.36);
      wL.position.set(1.32, 0.54, wz);
      truck.add(wL);
      const wR = createWheel(0.54, 0.36);
      wR.position.set(-1.32, 0.54, wz);
      truck.add(wR);
    });

    physics.addBox(id, x, y + 1.8, z, 3.2, 3.2, 7.8, false);
  };

  // Place our 6 vehicles across Level 1:
  // 1) Localized Burning Overturned Transit Bus near the Collapsed Highway Overpass (Center-West)
  createRuinedTransitBus('veh_bus_burning', -5.4, 0, -4.5, 0.42, 0.14, true);

  // 2) Localized Burning Crushed Sedan near the South-East Hab-Block Curb
  createRuinedSedan('veh_sedan_burning', 6.8, 0, 48.0, -0.52, 0.08, mats.sedanPaintCrimson, true);

  // 3) Abandoned Transit Bus parked obliquely outside Aegis Transit Terminal (B1)
  createRuinedTransitBus('veh_bus_terminal', -7.2, 0, 62.0, -0.22, -0.05, false);

  // 4) Abandoned Evacuation Cargo Truck near Tachibana Power Depot (B7)
  createEvacuationTruck('veh_truck_depot', 7.4, 0, -64.0, 0.18);

  // 5) Tilted Teal Sedan half-buried beside fractured asphalt slab (South Plaza)
  createRuinedSedan('veh_sedan_south', -5.2, 0, 74.5, 0.36, -0.1, mats.sedanPaintTeal, false);

  // 6) Abandoned Crimson Sedan near Sunken Civic Archives (B6)
  createRuinedSedan('veh_sedan_north', -6.8, 0, -48.5, -0.45, 0.05, mats.sedanPaintCrimson, false);

  // 4. Broken Streetlights, Stepped Concrete Utility Poles & Catenary Sagging Overhead Power Cables
  const poleTopAnchorsLeft: THREE.Vector3[] = [];
  const poleTopAnchorsRight: THREE.Vector3[] = [];

  const createUtilityPoleAndStreetlight = (
    x: number,
    y: number,
    z: number,
    side: 1 | -1,
    leanAngleZ: number,
    leanAngleX: number,
    isBrokenLamp: boolean,
    idx: number
  ) => {
    const poleGroup = new THREE.Group();
    poleGroup.position.set(x, y, z);
    poleGroup.rotation.set(leanAngleX, 0, leanAngleZ);
    propsGroup.add(poleGroup);

    physics.addCylinder(`pole_${idx}`, x, z, 0.25, y, y + 8);

    // Stepped concrete foundation plinth
    const basePlinth = new THREE.Mesh(
      new THREE.CylinderGeometry(0.24, 0.32, 0.9, 8),
      mats.concreteDark
    );
    basePlinth.position.y = 0.45;
    basePlinth.castShadow = true;
    poleGroup.add(basePlinth);

    // Main tapered utility mast
    const mast = new THREE.Mesh(
      new THREE.CylinderGeometry(0.11, 0.2, 9.2, 8),
      mats.rustedSteel
    );
    mast.position.y = 4.6;
    mast.castShadow = true;
    poleGroup.add(mast);

    // Transformer drum mounted mid-pole on alternate poles
    if (idx % 2 === 0) {
      const drum = new THREE.Mesh(
        new THREE.CylinderGeometry(0.32, 0.32, 0.88, 10),
        mats.darkSteel
      );
      drum.position.set(side * -0.34, 5.8, 0);
      drum.castShadow = true;
      poleGroup.add(drum);
    }

    // Upper high-voltage cross-arm with ceramic insulators
    const crossArm = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.12, 0.14), mats.darkSteel);
    crossArm.position.set(0, 8.6, 0);
    crossArm.castShadow = true;
    poleGroup.add(crossArm);

    [-0.85, 0, 0.85].forEach((ix) => {
      const insulator = new THREE.Mesh(
        new THREE.CylinderGeometry(0.06, 0.08, 0.26, 8),
        mats.concreteWarm
      );
      insulator.position.set(ix, 8.78, 0);
      poleGroup.add(insulator);
    });

    // Cantilevered curved streetlight arm reaching over the road
    const lampArm = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.1, 0.1), mats.rustedSteel);
    lampArm.position.set(side * -1.2, 7.4, 0);
    lampArm.rotation.z = side * (isBrokenLamp ? 0.42 : -0.18);
    lampArm.castShadow = true;
    poleGroup.add(lampArm);

    const lampHead = new THREE.Mesh(
      new THREE.BoxGeometry(0.65, 0.14, 0.32),
      idx % 3 === 0 ? mats.amberBeacon : mats.darkSteel
    );
    lampHead.position.set(
      side * -2.35,
      isBrokenLamp ? 6.85 : 7.62,
      0
    );
    lampHead.rotation.z = isBrokenLamp ? side * 0.65 : 0;
    poleGroup.add(lampHead);

    // Record world-space cable anchor point at top of pole
    const topLocal = new THREE.Vector3(0, 8.75, 0);
    poleGroup.updateMatrixWorld(true);
    const topWorld = topLocal.applyMatrix4(poleGroup.matrixWorld);

    if (side === -1) {
      poleTopAnchorsLeft.push(topWorld);
    } else {
      poleTopAnchorsRight.push(topWorld);
    }
  };

  // Place 8 pairs (16 total) of utility poles & streetlights lining the boulevard from Z = +82 to Z = -94
  const poleZPositions = [78, 54, 30, 6, -24, -48, -72, -94];
  poleZPositions.forEach((pz, i) => {
    const leanL = ((i % 3) - 1) * 0.07;
    const leanR = (((i + 1) % 3) - 1) * 0.08;
    createUtilityPoleAndStreetlight(-11.2, 0.24, pz, -1, leanL, 0.03, i % 2 === 1, i * 2);
    createUtilityPoleAndStreetlight(11.2, 0.24, pz, 1, leanR, -0.03, i % 3 === 0, i * 2 + 1);
  });

  // Helper to string a catenary sagging cable between two 3D points (Scarlet Nexus signature detail)
  const createSaggingCable = (
    p1: THREE.Vector3,
    p2: THREE.Vector3,
    sag: number,
    thickness = 0.032,
    phase = 0
  ) => {
    const mid = new THREE.Vector3().addVectors(p1, p2).multiplyScalar(0.5);
    mid.y -= sag;

    const q1 = new THREE.Vector3().lerpVectors(p1, mid, 0.55);
    q1.y -= sag * 0.22;
    const q2 = new THREE.Vector3().lerpVectors(mid, p2, 0.45);
    q2.y -= sag * 0.22;

    const curve = new THREE.CatmullRomCurve3([p1, q1, mid, q2, p2]);
    const tubeGeo = new THREE.TubeGeometry(curve, 18, thickness, 5, false);
    const cableMesh = new THREE.Mesh(tubeGeo, mats.darkSteel);
    cableMesh.castShadow = true;
    propsGroup.add(cableMesh);

    swayingCables.push({
      mesh: cableMesh,
      baseY: cableMesh.position.y,
      phase
    });
  };

  // String longitudinal double power lines along West and East utility poles
  for (let i = 0; i < poleTopAnchorsLeft.length - 1; i++) {
    const a1 = poleTopAnchorsLeft[i];
    const a2 = poleTopAnchorsLeft[i + 1];
    createSaggingCable(
      a1.clone().add(new THREE.Vector3(-0.6, 0, 0)),
      a2.clone().add(new THREE.Vector3(-0.6, 0, 0)),
      1.35 + (i % 3) * 0.35,
      0.032,
      i * 0.7
    );
    createSaggingCable(
      a1.clone().add(new THREE.Vector3(0.6, -0.1, 0)),
      a2.clone().add(new THREE.Vector3(0.6, -0.1, 0)),
      1.65 + (i % 2) * 0.4,
      0.028,
      i * 1.1
    );
  }

  for (let i = 0; i < poleTopAnchorsRight.length - 1; i++) {
    const b1 = poleTopAnchorsRight[i];
    const b2 = poleTopAnchorsRight[i + 1];
    createSaggingCable(
      b1.clone().add(new THREE.Vector3(-0.6, 0, 0)),
      b2.clone().add(new THREE.Vector3(-0.6, 0, 0)),
      1.4 + (i % 2) * 0.35,
      0.032,
      i * 0.9
    );
    createSaggingCable(
      b1.clone().add(new THREE.Vector3(0.6, -0.1, 0)),
      b2.clone().add(new THREE.Vector3(0.6, -0.1, 0)),
      1.75 + (i % 3) * 0.3,
      0.028,
      i * 1.4
    );
  }

  // String dramatic cross-street catenary cables connecting buildings and poles across the urban canyon
  const crossStreetCables: Array<[THREE.Vector3, THREE.Vector3, number]> = [
    [new THREE.Vector3(-11.2, 9.0, 78), new THREE.Vector3(11.2, 9.0, 78), 2.1],
    [new THREE.Vector3(-19.5, 11.5, 56), new THREE.Vector3(11.2, 8.9, 54), 2.4],
    [new THREE.Vector3(-11.2, 8.9, 30), new THREE.Vector3(20.0, 13.5, 16), 2.8],
    [new THREE.Vector3(-18.5, 10.2, 18), new THREE.Vector3(19.5, 11.8, 12), 3.1],
    [new THREE.Vector3(-11.2, 8.9, -24), new THREE.Vector3(24.0, 15.0, -34), 2.6],
    [new THREE.Vector3(-20.0, 9.8, -42), new THREE.Vector3(11.2, 8.9, -48), 2.5],
    [new THREE.Vector3(-21.0, 16.5, -74), new THREE.Vector3(19.0, 9.2, -72), 3.2],
    [new THREE.Vector3(-11.2, 8.9, -94), new THREE.Vector3(16.0, 9.5, -102), 2.2]
  ];

  crossStreetCables.forEach(([p1, p2, sag], idx) => {
    createSaggingCable(p1, p2, sag, 0.036, idx * 1.6);
  });

  // 5. Concrete Debris Clusters with Protruding Twisted Rebar & Highway Jersey Barriers
  const createRebarDebrisCluster = (x: number, y: number, z: number, scale: number, seed: number) => {
    const cluster = new THREE.Group();
    cluster.position.set(x, y, z);
    cluster.rotation.y = seed * 1.1;
    propsGroup.add(cluster);

    // Fractured concrete slab chunks
    for (let i = 0; i < 3; i++) {
      const slab = new THREE.Mesh(
        new THREE.BoxGeometry((1.5 - i * 0.3) * scale, (0.38 + i * 0.1) * scale, (1.2 - i * 0.2) * scale),
        i % 2 === 0 ? mats.concreteDamaged : mats.concreteMain
      );
      slab.position.set((i - 1) * 0.45 * scale, (0.2 + i * 0.16) * scale, ((i * 7) % 3 - 1) * 0.3 * scale);
      slab.rotation.set(0.22 * (i + 1), i * 0.7, -0.18 * i);
      slab.castShadow = true;
      slab.receiveShadow = true;
      cluster.add(slab);
    }

    // Protruding twisted steel rebar rods
    for (let r = 0; r < 5; r++) {
      const rod = new THREE.Mesh(
        new THREE.CylinderGeometry(0.022 * scale, 0.022 * scale, 1.35 * scale, 5),
        mats.rebarMetal
      );
      rod.position.set((r - 2) * 0.24 * scale, 0.55 * scale, ((r % 2) - 0.5) * 0.35 * scale);
      rod.rotation.set(0.65 + (r % 3) * 0.2, r * 0.4, 0.35);
      cluster.add(rod);
    }

    physics.addCylinder(`debris_${seed}`, x, z, 0.95 * scale, y, y + 1.2 * scale);
  };

  // Contextually placed structural collapse debris directly beneath actual building/viaduct fractures
  const contextualDebrisCoords: Array<[number, number, number, number]> = [
    // Beneath Gate-00 sheared central lintel
    [-3.6, 0, 84.5, 1.15],
    [3.8, 0, 85.2, 1.05],
    // Outside B3 Helion Research Annex sheared East facade
    [-14.2, 0.24, 13.5, 1.2],
    [-14.8, 0.24, 22.4, 1.1],
    // Beneath Collapsed Cross-Sector Highway Viaduct central break
    [6.2, 0, -11.5, 1.3],
    [-7.8, 0, -18.2, 1.2],
    // Outside B6 Sunken Civic Archives breached North-East pier
    [-17.8, 0.24, -44.2, 1.15],
    // At base of cleaved B8 Meridian Skyscraper
    [-16.8, 0.24, -71.5, 1.25]
  ];

  contextualDebrisCoords.forEach(([x, y, z, sc], idx) => {
    createRebarDebrisCluster(x, y, z, sc, idx + 1);
  });

  // Concrete Highway Jersey Barriers blocking ruptured fault edges & quarantine checkpoints
  const createJerseyBarrier = (x: number, y: number, z: number, rotY: number, idx: number) => {
    const barrier = new THREE.Group();
    barrier.position.set(x, y, z);
    barrier.rotation.y = rotY;
    propsGroup.add(barrier);

    const base = new THREE.Mesh(new THREE.BoxGeometry(2.8, 0.35, 0.65), mats.concreteDark);
    base.position.y = 0.175;
    base.castShadow = true;
    base.receiveShadow = true;
    barrier.add(base);

    const upper = new THREE.Mesh(new THREE.BoxGeometry(2.76, 0.62, 0.32), mats.concreteMain);
    upper.position.y = 0.62;
    upper.castShadow = true;
    barrier.add(upper);

    // Hazard stripe plate
    const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.22, 0.35), mats.astralGoldTrim);
    stripe.position.set(0, 0.72, 0);
    barrier.add(stripe);

    physics.addBox(`barrier_${idx}`, x, y + 0.5, z, 2.6, 1.1, 0.9, false);
  };

  const barrierCoords: Array<[number, number, number, number]> = [
    [-4.8, 0, 88.2, 0.18],
    [4.9, 0, 87.8, -0.22],
    [-4.2, 0, 22.0, -0.32],
    [5.4, 0, -2.5, 0.26],
    [-4.4, 0, -26.0, 0.14],
    [4.8, 0, -56.0, -0.22],
    [-5.2, 0, -86.0, 0.18]
  ];

  barrierCoords.forEach(([x, y, z, ry], idx) => {
    createJerseyBarrier(x, y, z, ry, idx);
  });

  // 6. Anime Urban Intersection Traffic Signal Gantries & Pedestrian Crossing Lights
  const createTrafficSignalGantry = (
    x: number,
    y: number,
    z: number,
    side: -1 | 1,
    tiltZ: number,
    idx: number
  ) => {
    const sigGroup = new THREE.Group();
    sigGroup.position.set(x, y, z);
    sigGroup.rotation.z = tiltZ;
    propsGroup.add(sigGroup);

    physics.addCylinder(`traffic_sig_${idx}`, x, z, 0.22, y, y + 6.5);

    const post = new THREE.Mesh(
      new THREE.CylinderGeometry(0.14, 0.18, 6.2, 8),
      mats.darkSteel
    );
    post.position.y = 3.1;
    post.castShadow = true;
    sigGroup.add(post);

    // Cantilevered horizontal signal arm extending over the crosswalk
    const arm = new THREE.Mesh(new THREE.BoxGeometry(4.2, 0.12, 0.12), mats.darkSteel);
    arm.position.set(-side * 2.0, 5.65, 0);
    arm.castShadow = true;
    sigGroup.add(arm);

    // 3-Lens Horizontal Anime Traffic Signal Head
    const headVisor = new THREE.Mesh(
      new THREE.BoxGeometry(1.35, 0.42, 0.48),
      mats.charredVehicle
    );
    headVisor.position.set(-side * 3.1, 5.48, 0);
    headVisor.castShadow = true;
    sigGroup.add(headVisor);

    // Glowing amber & cyan signal lenses on both North and South faces
    [-0.38, 0, 0.38].forEach((lx, lIdx) => {
      const lensMat =
        lIdx === 0 ? mats.amberBeacon : lIdx === 1 ? mats.astralGoldTrim : mats.windowCyanLit;
      const lensS = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.11, 0.5, 8), lensMat);
      lensS.rotation.x = Math.PI * 0.5;
      lensS.position.set(-side * 3.1 + lx, 5.48, 0);
      sigGroup.add(lensS);
    });

    // Pedestrian crosswalk light box mounted at 2.6m height
    const pedBox = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.55, 0.32), mats.darkSteel);
    pedBox.position.set(-side * 0.22, 2.65, 0);
    sigGroup.add(pedBox);
  };

  createTrafficSignalGantry(-10.2, 0.24, 65.5, -1, -0.02, 1);
  createTrafficSignalGantry(10.2, 0.24, 21.5, 1, 0.04, 2);
  createTrafficSignalGantry(-10.2, 0.24, -35.5, -1, 0.03, 3);
  createTrafficSignalGantry(10.2, 0.24, -87.5, 1, -0.02, 4);

  // 7. Sidewalk Storytelling Furniture (Benches, Dual Recycling Bins, Fire Hydrants & Floodlight Generator)
  const createSidewalkBenchAndBins = (x: number, y: number, z: number, side: -1 | 1) => {
    const fg = new THREE.Group();
    fg.position.set(x, y, z);
    fg.rotation.y = side === -1 ? Math.PI * 0.5 : -Math.PI * 0.5;
    propsGroup.add(fg);

    // Slatted urban bench
    const seat = new THREE.Mesh(new THREE.BoxGeometry(2.1, 0.08, 0.55), mats.concreteWarm);
    seat.position.y = 0.46;
    seat.castShadow = true;
    fg.add(seat);

    const backrest = new THREE.Mesh(new THREE.BoxGeometry(2.1, 0.45, 0.08), mats.concreteWarm);
    backrest.position.set(0, 0.72, -0.24);
    backrest.rotation.x = -0.15;
    backrest.castShadow = true;
    fg.add(backrest);

    [-0.85, 0.85].forEach((lx) => {
      const leg = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.46, 0.52), mats.darkSteel);
      leg.position.set(lx, 0.23, 0);
      fg.add(leg);
    });

    // Dual anime municipal sorting bin beside bench
    const binBody = new THREE.Mesh(new THREE.BoxGeometry(0.75, 0.92, 0.45), mats.darkSteel);
    binBody.position.set(1.55, 0.46, 0);
    binBody.castShadow = true;
    fg.add(binBody);

    const binTop = new THREE.Mesh(new THREE.BoxGeometry(0.78, 0.14, 0.48), mats.windowCyanLit);
    binTop.position.set(1.55, 0.95, 0);
    fg.add(binTop);
  };

  createSidewalkBenchAndBins(12.2, 0.24, 52.0, 1);
  createSidewalkBenchAndBins(-12.2, 0.24, 29.0, -1);
  createSidewalkBenchAndBins(12.2, 0.24, 8.5, 1);
  createSidewalkBenchAndBins(-12.2, 0.24, -49.0, -1);
  createSidewalkBenchAndBins(12.2, 0.24, -78.0, 1);

  // Quarantine Mobile Floodlight & Bio-Scanner Generator Cart at South Entrance Checkpoint
  const genCart = new THREE.Group();
  genCart.position.set(6.8, 0, 89.5);
  genCart.rotation.y = -0.35;
  propsGroup.add(genCart);

  const genBody = new THREE.Mesh(new THREE.BoxGeometry(1.45, 1.15, 2.1), mats.rustedSteel);
  genBody.position.y = 0.78;
  genBody.castShadow = true;
  genCart.add(genBody);

  const genMast = new THREE.Mesh(
    new THREE.CylinderGeometry(0.06, 0.08, 3.6, 8),
    mats.darkSteel
  );
  genMast.position.set(0, 2.6, 0.6);
  genCart.add(genMast);

  const floodLamp = new THREE.Mesh(
    new THREE.BoxGeometry(0.95, 0.38, 0.25),
    mats.amberBeacon
  );
  floodLamp.position.set(0, 4.4, 0.6);
  floodLamp.rotation.x = 0.28;
  genCart.add(floodLamp);
  physics.addBox('quarantine_gen_cart', 6.8, 1.2, 89.5, 1.8, 2.4, 2.3, false);

  return { fireSites, swayingCables };
}
