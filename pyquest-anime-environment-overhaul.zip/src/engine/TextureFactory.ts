import * as THREE from 'three';

export interface MaterialLibrary {
  toonGradient: THREE.DataTexture;
  concreteMain: THREE.MeshStandardMaterial;
  concreteDark: THREE.MeshStandardMaterial;
  concreteWarm: THREE.MeshStandardMaterial;
  concreteDamaged: THREE.MeshStandardMaterial;
  ceramicTileFacade: THREE.MeshStandardMaterial;
  darkBrickFacade: THREE.MeshStandardMaterial;
  asphaltRoad: THREE.MeshStandardMaterial;
  crosswalkMarking: THREE.MeshStandardMaterial;
  sidewalkPaving: THREE.MeshStandardMaterial;
  windowIntact: THREE.MeshStandardMaterial;
  windowWarmLit: THREE.MeshStandardMaterial;
  windowCyanLit: THREE.MeshStandardMaterial;
  windowShard: THREE.MeshStandardMaterial;
  shopShutter: THREE.MeshStandardMaterial;
  awningFabricVermilion: THREE.MeshStandardMaterial;
  awningFabricTeal: THREE.MeshStandardMaterial;
  vendingMachineFront: THREE.MeshStandardMaterial;
  rustedSteel: THREE.MeshStandardMaterial;
  darkSteel: THREE.MeshStandardMaterial;
  rebarMetal: THREE.MeshStandardMaterial;
  interiorFloor: THREE.MeshStandardMaterial;
  interiorWall: THREE.MeshStandardMaterial;
  treeBark: THREE.MeshStandardMaterial;
  foliageCanopy: THREE.MeshStandardMaterial;
  foliageSunlit: THREE.MeshStandardMaterial;
  foliageAutumn: THREE.MeshStandardMaterial;
  astralMonolith: THREE.MeshStandardMaterial;
  astralGoldTrim: THREE.MeshStandardMaterial;
  astralEnergyCore: THREE.MeshStandardMaterial;
  amberBeacon: THREE.MeshStandardMaterial;
  charredVehicle: THREE.MeshStandardMaterial;
  transitBusPaint: THREE.MeshStandardMaterial;
  sedanPaintTeal: THREE.MeshStandardMaterial;
  sedanPaintCrimson: THREE.MeshStandardMaterial;
  createSignMaterial: (title: string, subtitle: string, accentHex: string) => THREE.MeshStandardMaterial;
}

function makeCanvasTexture(
  width: number,
  height: number,
  draw: (ctx: CanvasRenderingContext2D, w: number, h: number) => void,
  repeatX = 1,
  repeatY = 1
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;
  draw(ctx, width, height);

  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeatX, repeatY);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}

export function createMaterialLibrary(): MaterialLibrary {
  // 4-step anime cel-shading gradient ramp for character & stylized elements
  const toonData = new Uint8Array([
    68, 72, 92, 255,
    132, 136, 155, 255,
    210, 212, 222, 255,
    255, 252, 245, 255
  ]);
  const toonGradient = new THREE.DataTexture(toonData, 4, 1, THREE.RGBAFormat);
  toonGradient.minFilter = THREE.NearestFilter;
  toonGradient.magFilter = THREE.NearestFilter;
  toonGradient.needsUpdate = true;

  // 1. Weathered Brutalist Board-Formed Concrete
  const concreteTex = makeCanvasTexture(
    512,
    512,
    (ctx, w, h) => {
      ctx.fillStyle = '#73767d';
      ctx.fillRect(0, 0, w, h);

      // Subtle tonal mottled blocks
      for (let i = 0; i < 900; i++) {
        const x = (i * 73) % w;
        const y = (i * 137) % h;
        const sz = 10 + (i % 28);
        ctx.fillStyle = i % 2 === 0 ? 'rgba(52, 56, 66, 0.14)' : 'rgba(158, 160, 166, 0.12)';
        ctx.fillRect(x, y, sz, sz * 0.7);
      }

      // Formwork horizontal seams & vertical panel joints
      ctx.strokeStyle = 'rgba(36, 39, 46, 0.45)';
      ctx.lineWidth = 2;
      for (let y = 64; y < h; y += 64) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }
      for (let x = 128; x < w; x += 128) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }

      // Formwork tie-rod holes
      ctx.fillStyle = 'rgba(28, 30, 36, 0.65)';
      for (let y = 32; y < h; y += 64) {
        for (let x = 32; x < w; x += 64) {
          ctx.beginPath();
          ctx.arc(x, y, 3.2, 0, Math.PI * 2);
          ctx.fill();
          // Vertical water/rust drip below tie hole
          ctx.fillStyle = 'rgba(42, 46, 52, 0.18)';
          ctx.fillRect(x - 2, y + 3, 4, 24);
          ctx.fillStyle = 'rgba(28, 30, 36, 0.65)';
        }
      }

      // Hairline structural cracks
      ctx.strokeStyle = 'rgba(25, 27, 33, 0.55)';
      ctx.lineWidth = 1.5;
      for (let c = 0; c < 6; c++) {
        let cx = (c * 97) % w;
        let cy = (c * 83) % h;
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        for (let s = 0; s < 7; s++) {
          cx += ((s * 19 + c * 7) % 34) - 16;
          cy += 14 + (s % 12);
          ctx.lineTo(cx, cy);
        }
        ctx.stroke();
      }
    },
    2,
    2
  );

  // 2. Fractured / Damaged Concrete Cross-Section
  const damagedConcreteTex = makeCanvasTexture(
    256,
    256,
    (ctx, w, h) => {
      ctx.fillStyle = '#555860';
      ctx.fillRect(0, 0, w, h);
      for (let i = 0; i < 500; i++) {
        const x = (i * 43) % w;
        const y = (i * 89) % h;
        const r = 3 + (i % 9);
        ctx.fillStyle = i % 3 === 0 ? '#3a3d45' : i % 3 === 1 ? '#6e7077' : '#857c73';
        ctx.fillRect(x, y, r, r);
      }
    },
    2,
    2
  );

  // 3. Cracked Highway Asphalt Texture
  const asphaltTex = makeCanvasTexture(
    512,
    512,
    (ctx, w, h) => {
      ctx.fillStyle = '#23262e';
      ctx.fillRect(0, 0, w, h);

      // Asphalt mineral grain
      for (let i = 0; i < 2200; i++) {
        const x = (i * 53) % w;
        const y = (i * 97) % h;
        ctx.fillStyle = i % 2 === 0 ? 'rgba(54, 58, 70, 0.35)' : 'rgba(16, 18, 24, 0.35)';
        ctx.fillRect(x, y, 3, 3);
      }

      // Faded dual center amber highway lines
      ctx.fillStyle = 'rgba(218, 152, 68, 0.58)';
      ctx.fillRect(w * 0.485, 0, 5, h);
      ctx.fillRect(w * 0.505, 0, 5, h);

      // Faded white lane dashes
      ctx.fillStyle = 'rgba(215, 220, 228, 0.42)';
      for (let y = 20; y < h; y += 84) {
        ctx.fillRect(w * 0.24, y, 5, 44);
        ctx.fillRect(w * 0.75, y, 5, 44);
      }

      // Tectonic asphalt fissures
      ctx.strokeStyle = '#111318';
      ctx.lineWidth = 3;
      for (let k = 0; k < 5; k++) {
        let px = 60 + k * 90;
        ctx.beginPath();
        ctx.moveTo(px, 0);
        for (let y = 0; y <= h; y += 32) {
          px += Math.sin(y * 0.05 + k) * 10;
          ctx.lineTo(px, y);
        }
        ctx.stroke();
      }
    },
    1,
    8
  );

  // 4. Sidewalk Paving Slab Texture
  const sidewalkTex = makeCanvasTexture(
    256,
    256,
    (ctx, w, h) => {
      ctx.fillStyle = '#6c7078';
      ctx.fillRect(0, 0, w, h);

      ctx.strokeStyle = '#3f434c';
      ctx.lineWidth = 3;
      const step = 64;
      for (let x = 0; x <= w; x += step) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }
      for (let y = 0; y <= h; y += step) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }

      // Subtle tactile yellow curb strip along one edge
      ctx.fillStyle = 'rgba(214, 160, 58, 0.65)';
      ctx.fillRect(6, 0, 12, h);
    },
    2,
    14
  );

  // 5. Anime Reflective Shattered Curtain-Wall Window Texture
  const windowTex = makeCanvasTexture(
    256,
    256,
    (ctx, w, h) => {
      const grad = ctx.createLinearGradient(0, 0, w, h);
      grad.addColorStop(0, '#182838');
      grad.addColorStop(0.55, '#29485c');
      grad.addColorStop(1, '#5c4d42');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);

      // Diagonal anime sky reflection band
      ctx.fillStyle = 'rgba(255, 224, 182, 0.18)';
      ctx.beginPath();
      ctx.moveTo(0, h * 0.65);
      ctx.lineTo(w * 0.65, 0);
      ctx.lineTo(w * 0.85, 0);
      ctx.lineTo(0, h * 0.85);
      ctx.closePath();
      ctx.fill();

      // Mullion frame border
      ctx.strokeStyle = '#1b2028';
      ctx.lineWidth = 10;
      ctx.strokeRect(0, 0, w, h);

      // Shatter lines
      ctx.strokeStyle = 'rgba(220, 238, 255, 0.35)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(w * 0.2, h * 0.2);
      ctx.lineTo(w * 0.85, h * 0.65);
      ctx.moveTo(w * 0.2, h * 0.2);
      ctx.lineTo(w * 0.45, h * 0.9);
      ctx.stroke();
    },
    1,
    1
  );

  // 6. Rusted Oxidized Structural Steel
  const rustedSteelTex = makeCanvasTexture(
    256,
    256,
    (ctx, w, h) => {
      ctx.fillStyle = '#363233';
      ctx.fillRect(0, 0, w, h);
      for (let i = 0; i < 420; i++) {
        const x = (i * 61) % w;
        const y = (i * 103) % h;
        ctx.fillStyle = i % 2 === 0 ? 'rgba(138, 68, 42, 0.32)' : 'rgba(42, 46, 54, 0.35)';
        ctx.fillRect(x, y, 16, 8);
      }
      // Rivet strip
      ctx.fillStyle = '#221f20';
      for (let y = 16; y < h; y += 32) {
        ctx.beginPath();
        ctx.arc(16, y, 3, 0, Math.PI * 2);
        ctx.arc(w - 16, y, 3, 0, Math.PI * 2);
        ctx.fill();
      }
    },
    2,
    2
  );

  // 7. Exposed Interior Terrazzo Tile
  const interiorTileTex = makeCanvasTexture(
    256,
    256,
    (ctx, w, h) => {
      ctx.fillStyle = '#7d7a72';
      ctx.fillRect(0, 0, w, h);
      ctx.strokeStyle = '#4e4c46';
      ctx.lineWidth = 2;
      for (let i = 0; i <= w; i += 32) {
        ctx.beginPath();
        ctx.moveTo(i, 0);
        ctx.lineTo(i, h);
        ctx.moveTo(0, i);
        ctx.lineTo(w, i);
        ctx.stroke();
      }
    },
    4,
    4
  );

  // 8. Organic Gnarled Tree Bark
  const barkTex = makeCanvasTexture(
    256,
    256,
    (ctx, w, h) => {
      ctx.fillStyle = '#44362c';
      ctx.fillRect(0, 0, w, h);
      for (let i = 0; i < 300; i++) {
        const x = (i * 37) % w;
        const y = (i * 71) % h;
        ctx.fillStyle = i % 3 === 0 ? '#2f241d' : i % 3 === 1 ? '#57463a' : '#3d4a35';
        ctx.fillRect(x, y, 5, 28);
      }
    },
    1,
    2
  );

  // 9. Stylized Anime Layered Foliage Leaf Texture (Granblue / Genshin inspired)
  const createLeafClumpTex = (baseHex: string, highlightHex: string, shadowHex: string) =>
    makeCanvasTexture(256, 256, (ctx, w, h) => {
      ctx.clearRect(0, 0, w, h);
      const cx = w / 2;
      const cy = h / 2;

      // Paint 55 overlapping cel-styled pointed anime leaves in a natural irregular cluster
      for (let i = 0; i < 58; i++) {
        const angle = (i * 2.39996) % (Math.PI * 2);
        const dist = Math.sqrt(i / 58) * (w * 0.37);
        const lx = cx + Math.cos(angle) * dist;
        const ly = cy + Math.sin(angle) * dist;
        const leafLen = 26 + (i % 14);
        const leafWid = 12 + (i % 6);

        ctx.save();
        ctx.translate(lx, ly);
        ctx.rotate(angle + ((i % 5) - 2) * 0.18);

        ctx.fillStyle = i < 20 ? shadowHex : i < 42 ? baseHex : highlightHex;
        ctx.beginPath();
        ctx.moveTo(-leafLen * 0.3, 0);
        ctx.quadraticCurveTo(leafLen * 0.2, -leafWid, leafLen * 0.85, 0);
        ctx.quadraticCurveTo(leafLen * 0.2, leafWid, -leafLen * 0.3, 0);
        ctx.closePath();
        ctx.fill();

        ctx.strokeStyle = 'rgba(20, 28, 18, 0.28)';
        ctx.lineWidth = 1.2;
        ctx.stroke();
        ctx.restore();
      }
    });

  const canopyLeafTex = createLeafClumpTex('#48683c', '#74964b', '#2c4428');
  const sunlitLeafTex = createLeafClumpTex('#608040', '#96b454', '#39522d');
  const autumnLeafTex = createLeafClumpTex('#9e6236', '#d48d46', '#5e3822');

  // 10. Astral Monolith Circuit Stone Texture (Exit Gate)
  const astralStoneTex = makeCanvasTexture(
    512,
    512,
    (ctx, w, h) => {
      ctx.fillStyle = '#1e222d';
      ctx.fillRect(0, 0, w, h);

      // Subtle carved basalt geometric panels
      ctx.strokeStyle = '#11141c';
      ctx.lineWidth = 4;
      ctx.strokeRect(18, 18, w - 36, h - 36);
      ctx.strokeRect(42, 42, w - 84, h - 84);

      // Luminous golden-cyan resonance circuit inlays
      ctx.strokeStyle = '#f5b651';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(w * 0.5, 0);
      ctx.lineTo(w * 0.5, h);
      ctx.moveTo(w * 0.28, 60);
      ctx.lineTo(w * 0.72, 60);
      ctx.moveTo(w * 0.28, h - 60);
      ctx.lineTo(w * 0.72, h - 60);
      ctx.stroke();

      ctx.strokeStyle = '#4deeea';
      ctx.lineWidth = 2;
      ctx.strokeRect(w * 0.34, h * 0.34, w * 0.32, h * 0.32);
    },
    1,
    2
  );

  // 11. Modern East-Asian Ceramic Tile Building Facade (Zenless Zone Zero / Wuthering Waves urban blocks)
  const ceramicTileTex = makeCanvasTexture(
    256,
    256,
    (ctx, w, h) => {
      ctx.fillStyle = '#999288';
      ctx.fillRect(0, 0, w, h);

      // Subtle warm/cool architectural tile variation
      const tileW = 32;
      const tileH = 16;
      for (let y = 0; y < h; y += tileH) {
        for (let x = 0; x < w; x += tileW) {
          const hash = ((x * 13 + y * 29) >> 4) % 5;
          ctx.fillStyle =
            hash === 0
              ? '#8c847a'
              : hash === 1
              ? '#a69e94'
              : hash === 2
              ? '#938b82'
              : '#9d958b';
          ctx.fillRect(x + 1, y + 1, tileW - 2, tileH - 2);
        }
      }

      // Mortar joints
      ctx.strokeStyle = 'rgba(44, 42, 40, 0.55)';
      ctx.lineWidth = 1.5;
      for (let y = 0; y <= h; y += tileH) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }
      for (let x = 0; x <= w; x += tileW) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }

      // Vertical rainwater weathering stain from upper cornice
      const stainGrad = ctx.createLinearGradient(0, 0, 0, h);
      stainGrad.addColorStop(0, 'rgba(30, 32, 38, 0.36)');
      stainGrad.addColorStop(0.35, 'rgba(30, 32, 38, 0.08)');
      stainGrad.addColorStop(1, 'rgba(24, 26, 30, 0.22)');
      ctx.fillStyle = stainGrad;
      ctx.fillRect(0, 0, w, h);
    },
    3,
    3
  );

  // 12. Dark Architectural Brick / Podium Masonry
  const darkBrickTex = makeCanvasTexture(
    256,
    256,
    (ctx, w, h) => {
      ctx.fillStyle = '#38343a';
      ctx.fillRect(0, 0, w, h);
      const bw = 32;
      const bh = 16;
      for (let row = 0; row < h / bh; row++) {
        const y = row * bh;
        const offset = (row % 2) * (bw * 0.5);
        for (let col = -1; col < w / bw + 1; col++) {
          const x = col * bw + offset;
          const tone = (row * 17 + col * 31) % 4;
          ctx.fillStyle =
            tone === 0 ? '#4a3b39' : tone === 1 ? '#3c363b' : tone === 2 ? '#54423e' : '#332f35';
          ctx.fillRect(x + 1.5, y + 1.5, bw - 3, bh - 3);
        }
      }
    },
    3,
    3
  );

  // 13. Illuminated Anime Interior Window (Warm Golden-Amber & Cool Cyan Lab/Office Variants)
  const makeLitWindowTex = (topColor: string, botColor: string, blindColor: string) =>
    makeCanvasTexture(256, 256, (ctx, w, h) => {
      const grad = ctx.createLinearGradient(0, 0, 0, h);
      grad.addColorStop(0, topColor);
      grad.addColorStop(0.65, botColor);
      grad.addColorStop(1, '#1e222c');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);

      // Venetian blind / ceiling light baffle horizontal slats
      ctx.fillStyle = blindColor;
      for (let y = 18; y < h * 0.52; y += 16) {
        ctx.fillRect(12, y, w - 24, 6);
      }

      // Interior silhouette desk/partition cue
      ctx.fillStyle = 'rgba(20, 22, 30, 0.55)';
      ctx.fillRect(24, h * 0.68, w * 0.55, h * 0.32);

      // Diagonal glass specular reflection band
      ctx.fillStyle = 'rgba(255, 245, 225, 0.22)';
      ctx.beginPath();
      ctx.moveTo(0, h * 0.72);
      ctx.lineTo(w * 0.72, 0);
      ctx.lineTo(w * 0.9, 0);
      ctx.lineTo(0, h * 0.9);
      ctx.closePath();
      ctx.fill();

      // Anodized mullion frame
      ctx.strokeStyle = '#181c24';
      ctx.lineWidth = 12;
      ctx.strokeRect(0, 0, w, h);
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.moveTo(w * 0.5, 0);
      ctx.lineTo(w * 0.5, h);
      ctx.stroke();
    });

  const windowWarmTex = makeLitWindowTex('#ffcf78', '#e8883c', 'rgba(42, 28, 22, 0.32)');
  const windowCyanTex = makeLitWindowTex('#84f5ff', '#359eb8', 'rgba(18, 36, 48, 0.32)');

  // 14. Commercial Corrugated Rollup Shutter with Anime District Stencil
  const shopShutterTex = makeCanvasTexture(256, 256, (ctx, w, h) => {
    ctx.fillStyle = '#2d333d';
    ctx.fillRect(0, 0, w, h);

    // Horizontal corrugated shutter slats
    for (let y = 0; y < h; y += 12) {
      ctx.fillStyle = 'rgba(255, 255, 255, 0.06)';
      ctx.fillRect(0, y, w, 4);
      ctx.fillStyle = 'rgba(10, 12, 16, 0.48)';
      ctx.fillRect(0, y + 8, w, 4);
    }

    // Caution hazard band at bottom of shutter
    ctx.fillStyle = '#d98a2b';
    ctx.fillRect(0, h - 28, w, 28);
    ctx.fillStyle = '#1b1e24';
    for (let sx = -20; sx < w + 20; sx += 32) {
      ctx.beginPath();
      ctx.moveTo(sx, h - 28);
      ctx.lineTo(sx + 16, h - 28);
      ctx.lineTo(sx + 4, h);
      ctx.lineTo(sx - 12, h);
      ctx.closePath();
      ctx.fill();
    }

    // Faded stencil graphic in center
    ctx.strokeStyle = 'rgba(240, 182, 84, 0.45)';
    ctx.lineWidth = 4;
    ctx.strokeRect(36, 48, w - 72, 96);
    ctx.fillStyle = 'rgba(244, 241, 234, 0.45)';
    ctx.font = 'bold 26px Consolas, monospace';
    ctx.fillText('CLOSED // SEC-01', 48, 105);
  });

  // 15. Striped Shopfront Awning Textures
  const makeAwningTex = (primaryHex: string, stripeHex: string) =>
    makeCanvasTexture(256, 256, (ctx, w, h) => {
      ctx.fillStyle = primaryHex;
      ctx.fillRect(0, 0, w, h);
      ctx.fillStyle = stripeHex;
      for (let x = 0; x < w; x += 64) {
        ctx.fillRect(x, 0, 28, h);
      }
      // Weathering shadow at top & bottom trim
      ctx.fillStyle = 'rgba(15, 16, 22, 0.35)';
      ctx.fillRect(0, 0, w, 18);
      ctx.fillRect(0, h - 14, w, 14);
    });

  const awningVermilionTex = makeAwningTex('#b83b2b', '#e6ded3');
  const awningTealTex = makeAwningTex('#2b5c6b', '#d9e2e6');

  // 16. Illuminated Anime Street Vending Machine Display Texture
  const vendingTex = makeCanvasTexture(256, 384, (ctx, w, h) => {
    ctx.fillStyle = '#1d2432';
    ctx.fillRect(0, 0, w, h);

    // Glowing upper beverage display window
    ctx.fillStyle = '#e8f6ff';
    ctx.fillRect(20, 24, w - 40, 185);

    // 3 shelves of colorful anime drink cans/bottles
    const shelfColors = ['#ff5238', '#38d6ff', '#f5b642', '#52e078', '#c85aff'];
    for (let row = 0; row < 3; row++) {
      const sy = 38 + row * 56;
      ctx.fillStyle = '#2d3748';
      ctx.fillRect(24, sy + 38, w - 48, 8);
      for (let col = 0; col < 6; col++) {
        ctx.fillStyle = shelfColors[(row * 3 + col) % shelfColors.length];
        ctx.fillRect(32 + col * 32, sy + 6, 20, 30);
      }
    }

    // Dispense slot & illuminated neon brand strip
    ctx.fillStyle = '#ff6b2b';
    ctx.fillRect(20, 222, w - 40, 28);
    ctx.fillStyle = '#0f131c';
    ctx.fillRect(28, 272, w - 56, 68);
  });

  // 17. Pedestrian Zebra Crosswalk & Intersection Stop-Line Texture
  const crosswalkTex = makeCanvasTexture(512, 256, (ctx, w, h) => {
    ctx.fillStyle = '#23262e';
    ctx.fillRect(0, 0, w, h);

    // Crisp weathered white zebra stripes
    ctx.fillStyle = 'rgba(232, 236, 242, 0.78)';
    for (let x = 24; x < w - 24; x += 64) {
      ctx.fillRect(x, 28, 36, h - 56);
    }

    // Asphalt wear scuffs across stripes
    ctx.fillStyle = 'rgba(35, 38, 46, 0.38)';
    ctx.fillRect(0, h * 0.42, w, 24);
  });

  const concreteMain = new THREE.MeshStandardMaterial({
    map: concreteTex,
    bumpMap: concreteTex,
    bumpScale: 0.035,
    roughness: 0.84,
    metalness: 0.08
  });

  const concreteDark = new THREE.MeshStandardMaterial({
    map: concreteTex,
    bumpMap: concreteTex,
    bumpScale: 0.04,
    color: new THREE.Color('#686e7a'),
    roughness: 0.86,
    metalness: 0.12
  });

  const concreteWarm = new THREE.MeshStandardMaterial({
    map: concreteTex,
    bumpMap: concreteTex,
    bumpScale: 0.03,
    color: new THREE.Color('#bfb3a4'),
    roughness: 0.82,
    metalness: 0.06
  });

  const concreteDamaged = new THREE.MeshStandardMaterial({
    map: damagedConcreteTex,
    bumpMap: damagedConcreteTex,
    bumpScale: 0.06,
    roughness: 0.94,
    metalness: 0.05
  });

  const ceramicTileFacade = new THREE.MeshStandardMaterial({
    map: ceramicTileTex,
    bumpMap: ceramicTileTex,
    bumpScale: 0.025,
    roughness: 0.68,
    metalness: 0.14
  });

  const darkBrickFacade = new THREE.MeshStandardMaterial({
    map: darkBrickTex,
    bumpMap: darkBrickTex,
    bumpScale: 0.045,
    roughness: 0.85,
    metalness: 0.08
  });

  const asphaltRoad = new THREE.MeshStandardMaterial({
    map: asphaltTex,
    bumpMap: asphaltTex,
    bumpScale: 0.04,
    roughness: 0.88,
    metalness: 0.06
  });

  const crosswalkMarking = new THREE.MeshStandardMaterial({
    map: crosswalkTex,
    bumpMap: crosswalkTex,
    bumpScale: 0.02,
    roughness: 0.85,
    metalness: 0.05
  });

  const sidewalkPaving = new THREE.MeshStandardMaterial({
    map: sidewalkTex,
    bumpMap: sidewalkTex,
    bumpScale: 0.03,
    roughness: 0.82,
    metalness: 0.06
  });

  const windowIntact = new THREE.MeshStandardMaterial({
    map: windowTex,
    roughness: 0.18,
    metalness: 0.68
  });

  const windowWarmLit = new THREE.MeshStandardMaterial({
    map: windowWarmTex,
    emissive: new THREE.Color('#ff9d42'),
    emissiveMap: windowWarmTex,
    emissiveIntensity: 0.52,
    roughness: 0.22,
    metalness: 0.45
  });

  const windowCyanLit = new THREE.MeshStandardMaterial({
    map: windowCyanTex,
    emissive: new THREE.Color('#38d6ff'),
    emissiveMap: windowCyanTex,
    emissiveIntensity: 0.48,
    roughness: 0.22,
    metalness: 0.45
  });

  const shopShutter = new THREE.MeshStandardMaterial({
    map: shopShutterTex,
    bumpMap: shopShutterTex,
    bumpScale: 0.04,
    roughness: 0.62,
    metalness: 0.58
  });

  const awningFabricVermilion = new THREE.MeshStandardMaterial({
    map: awningVermilionTex,
    roughness: 0.78,
    metalness: 0.05
  });

  const awningFabricTeal = new THREE.MeshStandardMaterial({
    map: awningTealTex,
    roughness: 0.78,
    metalness: 0.05
  });

  const vendingMachineFront = new THREE.MeshStandardMaterial({
    map: vendingTex,
    emissive: new THREE.Color('#9be4ff'),
    emissiveMap: vendingTex,
    emissiveIntensity: 0.55,
    roughness: 0.3,
    metalness: 0.4
  });

  const windowShard = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#78b4c8'),
    roughness: 0.15,
    metalness: 0.75,
    transparent: true,
    opacity: 0.72,
    side: THREE.DoubleSide
  });

  const rustedSteel = new THREE.MeshStandardMaterial({
    map: rustedSteelTex,
    roughness: 0.68,
    metalness: 0.62
  });

  const darkSteel = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#272b34'),
    roughness: 0.52,
    metalness: 0.72
  });

  const rebarMetal = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#6b4432'),
    roughness: 0.75,
    metalness: 0.55
  });

  const interiorFloor = new THREE.MeshStandardMaterial({
    map: interiorTileTex,
    roughness: 0.8,
    metalness: 0.1
  });

  const interiorWall = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#8c887f'),
    roughness: 0.88,
    metalness: 0.05
  });

  const treeBark = new THREE.MeshStandardMaterial({
    map: barkTex,
    roughness: 0.92,
    metalness: 0.03
  });

  const foliageCanopy = new THREE.MeshStandardMaterial({
    map: canopyLeafTex,
    alphaTest: 0.35,
    transparent: true,
    roughness: 0.75,
    metalness: 0.02,
    side: THREE.DoubleSide
  });

  const foliageSunlit = new THREE.MeshStandardMaterial({
    map: sunlitLeafTex,
    alphaTest: 0.35,
    transparent: true,
    roughness: 0.72,
    metalness: 0.02,
    side: THREE.DoubleSide
  });

  const foliageAutumn = new THREE.MeshStandardMaterial({
    map: autumnLeafTex,
    alphaTest: 0.35,
    transparent: true,
    roughness: 0.72,
    metalness: 0.02,
    side: THREE.DoubleSide
  });

  const astralMonolith = new THREE.MeshStandardMaterial({
    map: astralStoneTex,
    roughness: 0.48,
    metalness: 0.42
  });

  const astralGoldTrim = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#f0b654'),
    emissive: new THREE.Color('#d97b24'),
    emissiveIntensity: 0.45,
    roughness: 0.3,
    metalness: 0.82
  });

  const astralEnergyCore = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#6cf6ff'),
    emissive: new THREE.Color('#32d2eb'),
    emissiveIntensity: 1.35,
    roughness: 0.15,
    metalness: 0.2,
    transparent: true,
    opacity: 0.88,
    side: THREE.DoubleSide
  });

  const amberBeacon = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#ff8a3d'),
    emissive: new THREE.Color('#ff621f'),
    emissiveIntensity: 1.6,
    roughness: 0.25
  });

  const charredVehicle = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#232022'),
    roughness: 0.88,
    metalness: 0.35
  });

  const transitBusPaint = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#476273'),
    roughness: 0.65,
    metalness: 0.42
  });

  const sedanPaintTeal = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#3b5661'),
    roughness: 0.58,
    metalness: 0.48
  });

  const sedanPaintCrimson = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#6e3638'),
    roughness: 0.62,
    metalness: 0.45
  });

  const createSignMaterial = (title: string, subtitle: string, accentHex: string) => {
    const tex = makeCanvasTexture(512, 192, (ctx, w, h) => {
      ctx.fillStyle = '#121621';
      ctx.fillRect(0, 0, w, h);

      // Diagonal hazard/tech stripe border
      ctx.strokeStyle = accentHex;
      ctx.lineWidth = 6;
      ctx.strokeRect(8, 8, w - 16, h - 16);

      ctx.fillStyle = accentHex;
      ctx.fillRect(20, 24, 12, h - 48);

      ctx.fillStyle = '#f4f1ea';
      ctx.font = 'bold 42px "Segoe UI", Arial, sans-serif';
      ctx.fillText(title, 48, 86);

      ctx.fillStyle = accentHex;
      ctx.font = 'bold 24px Consolas, monospace';
      ctx.fillText(subtitle, 48, 134);

      // Weathering diagonal grime smudge
      ctx.fillStyle = 'rgba(18, 20, 26, 0.34)';
      ctx.beginPath();
      ctx.moveTo(w * 0.68, 0);
      ctx.lineTo(w, 0);
      ctx.lineTo(w, h);
      ctx.lineTo(w * 0.52, h);
      ctx.closePath();
      ctx.fill();
    });

    return new THREE.MeshStandardMaterial({
      map: tex,
      emissive: new THREE.Color(accentHex),
      emissiveMap: tex,
      emissiveIntensity: 0.28,
      roughness: 0.4,
      metalness: 0.5
    });
  };

  return {
    toonGradient,
    concreteMain,
    concreteDark,
    concreteWarm,
    concreteDamaged,
    ceramicTileFacade,
    darkBrickFacade,
    asphaltRoad,
    crosswalkMarking,
    sidewalkPaving,
    windowIntact,
    windowWarmLit,
    windowCyanLit,
    windowShard,
    shopShutter,
    awningFabricVermilion,
    awningFabricTeal,
    vendingMachineFront,
    rustedSteel,
    darkSteel,
    rebarMetal,
    interiorFloor,
    interiorWall,
    treeBark,
    foliageCanopy,
    foliageSunlit,
    foliageAutumn,
    astralMonolith,
    astralGoldTrim,
    astralEnergyCore,
    amberBeacon,
    charredVehicle,
    transitBusPaint,
    sedanPaintTeal,
    sedanPaintCrimson,
    createSignMaterial
  };
}
