import * as THREE from 'three';
import { AnimationState } from '../types/world';

export interface RiggedAnimeCharacter {
  root: THREE.Group;
  pelvis: THREE.Group;
  spine: THREE.Group;
  chest: THREE.Group;
  neck: THREE.Group;
  head: THREE.Group;
  hairBack: THREE.Group;
  leftShoulder: THREE.Group;
  leftForearm: THREE.Group;
  rightShoulder: THREE.Group;
  rightForearm: THREE.Group;
  leftHip: THREE.Group;
  leftShin: THREE.Group;
  leftFoot: THREE.Group;
  rightHip: THREE.Group;
  rightShin: THREE.Group;
  rightFoot: THREE.Group;
  coatLeft: THREE.Group;
  coatRight: THREE.Group;
  scarfSegmentsLeft: THREE.Group[];
  scarfSegmentsRight: THREE.Group[];
  updateAnimation: (
    dt: number,
    elapsedTime: number,
    state: AnimationState,
    moveSpeed: number,
    turnDelta: number,
    verticalVelocity: number,
    groundSlopePitch: number
  ) => void;
}

export function createRiggedAnimeCharacter(toonGradient: THREE.DataTexture): RiggedAnimeCharacter {
  const root = new THREE.Group();
  root.name = 'Kaelen_VanguardSurveyor';

  const makeToonMat = (hex: string, emissiveHex?: string, emissiveIntensity = 0) =>
    new THREE.MeshToonMaterial({
      color: new THREE.Color(hex),
      gradientMap: toonGradient,
      emissive: emissiveHex ? new THREE.Color(emissiveHex) : new THREE.Color('#000000'),
      emissiveIntensity
    });

  const skinMat = makeToonMat('#fbe5d4');
  const hairMat = makeToonMat('#dce2ee');
  const hairShadowMat = makeToonMat('#8c97b2');
  const jacketDarkMat = makeToonMat('#1a1f2c');
  const jacketLightMat = makeToonMat('#e8e4dc');
  const vermilionMat = makeToonMat('#d64232', '#9e2319', 0.18);
  const goldTrimMat = makeToonMat('#f2b64b', '#d98a26', 0.35);
  const cyanCoreMat = makeToonMat('#5ef2ff', '#28c7e8', 0.9);
  const trousersMat = makeToonMat('#232938');
  const bootMat = makeToonMat('#151821');
  const eyeDarkMat = makeToonMat('#1b1924');
  const eyeIrisMat = makeToonMat('#e85d3c', '#c93b1e', 0.35);

  const enableShadows = (mesh: THREE.Mesh) => {
    mesh.castShadow = true;
    mesh.receiveShadow = true;
  };

  // Hierarchy root joints
  const pelvis = new THREE.Group();
  pelvis.position.set(0, 0.94, 0);
  root.add(pelvis);

  // Pelvis / Belt block
  const hipMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.15, 0.16, 12), trousersMat);
  enableShadows(hipMesh);
  pelvis.add(hipMesh);

  const beltMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.168, 0.168, 0.05, 12), bootMat);
  beltMesh.position.y = 0.05;
  enableShadows(beltMesh);
  pelvis.add(beltMesh);

  const buckleMesh = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.055, 0.04), goldTrimMat);
  buckleMesh.position.set(0, 0.05, 0.16);
  enableShadows(buckleMesh);
  pelvis.add(buckleMesh);

  // Spine & Chest
  const spine = new THREE.Group();
  spine.position.set(0, 0.08, 0);
  pelvis.add(spine);

  const abdomenMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.155, 0.14, 0.22, 12), jacketDarkMat);
  abdomenMesh.position.y = 0.11;
  enableShadows(abdomenMesh);
  spine.add(abdomenMesh);

  const chest = new THREE.Group();
  chest.position.set(0, 0.22, 0);
  spine.add(chest);

  const upperTorsoMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.19, 0.155, 0.28, 12), jacketDarkMat);
  upperTorsoMesh.position.y = 0.14;
  enableShadows(upperTorsoMesh);
  chest.add(upperTorsoMesh);

  // Vanguard Alabaster Chest Vest Panels
  const vestLeft = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.25, 0.12), jacketLightMat);
  vestLeft.position.set(0.08, 0.15, 0.09);
  vestLeft.rotation.z = -0.08;
  enableShadows(vestLeft);
  chest.add(vestLeft);

  const vestRight = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.25, 0.12), jacketLightMat);
  vestRight.position.set(-0.08, 0.15, 0.09);
  vestRight.rotation.z = 0.08;
  enableShadows(vestRight);
  chest.add(vestRight);

  // Resonance Core Emblem on Chest & Back Surveyor Pack Node
  const chestCore = new THREE.Mesh(new THREE.OctahedronGeometry(0.045, 0), cyanCoreMat);
  chestCore.position.set(0, 0.18, 0.165);
  chest.add(chestCore);

  const backNodeFrame = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.2, 0.07), jacketLightMat);
  backNodeFrame.position.set(0, 0.15, -0.15);
  enableShadows(backNodeFrame);
  chest.add(backNodeFrame);

  const backCoreRing = new THREE.Mesh(new THREE.TorusGeometry(0.05, 0.012, 8, 16), cyanCoreMat);
  backCoreRing.position.set(0, 0.15, -0.19);
  chest.add(backCoreRing);

  // High Anime Tactical Collar
  const collarMesh = new THREE.Mesh(
    new THREE.CylinderGeometry(0.155, 0.14, 0.11, 12, 1, true, Math.PI * 0.25, Math.PI * 1.5),
    vermilionMat
  );
  collarMesh.position.set(0, 0.31, 0);
  collarMesh.rotation.y = Math.PI * 0.25;
  enableShadows(collarMesh);
  chest.add(collarMesh);

  // Flowing Split Long Coat Tails attached to Pelvis/Spine waist
  const coatLeft = new THREE.Group();
  coatLeft.position.set(0.11, 0.04, -0.08);
  pelvis.add(coatLeft);

  const coatLeftPanel = new THREE.Mesh(new THREE.BoxGeometry(0.17, 0.48, 0.03), jacketDarkMat);
  coatLeftPanel.position.set(0.02, -0.24, 0);
  coatLeftPanel.rotation.z = 0.12;
  enableShadows(coatLeftPanel);
  coatLeft.add(coatLeftPanel);

  const coatLeftTrim = new THREE.Mesh(new THREE.BoxGeometry(0.175, 0.04, 0.034), goldTrimMat);
  coatLeftTrim.position.set(0.04, -0.45, 0);
  coatLeftTrim.rotation.z = 0.12;
  coatLeft.add(coatLeftTrim);

  const coatRight = new THREE.Group();
  coatRight.position.set(-0.11, 0.04, -0.08);
  pelvis.add(coatRight);

  const coatRightPanel = new THREE.Mesh(new THREE.BoxGeometry(0.17, 0.48, 0.03), jacketDarkMat);
  coatRightPanel.position.set(-0.02, -0.24, 0);
  coatRightPanel.rotation.z = -0.12;
  enableShadows(coatRightPanel);
  coatRight.add(coatRightPanel);

  const coatRightTrim = new THREE.Mesh(new THREE.BoxGeometry(0.175, 0.04, 0.034), goldTrimMat);
  coatRightTrim.position.set(-0.04, -0.45, 0);
  coatRightTrim.rotation.z = -0.12;
  coatRight.add(coatRightTrim);

  // Multi-segment Flowing Vermilion Anime Scarf Chains
  const scarfSegmentsLeft: THREE.Group[] = [];
  const scarfSegmentsRight: THREE.Group[] = [];

  const buildScarfChain = (startX: number, targetArr: THREE.Group[]) => {
    let parent: THREE.Object3D = chest;
    for (let i = 0; i < 4; i++) {
      const seg = new THREE.Group();
      if (i === 0) {
        seg.position.set(startX, 0.27, -0.12);
      } else {
        seg.position.set(0, -0.15, -0.02);
      }
      const ribbon = new THREE.Mesh(
        new THREE.BoxGeometry(0.085 - i * 0.01, 0.17, 0.02),
        i === 3 ? goldTrimMat : vermilionMat
      );
      ribbon.position.y = -0.08;
      enableShadows(ribbon);
      seg.add(ribbon);
      parent.add(seg);
      targetArr.push(seg);
      parent = seg;
    }
  };

  buildScarfChain(0.07, scarfSegmentsLeft);
  buildScarfChain(-0.07, scarfSegmentsRight);

  // Neck & Stylized Anime Head
  const neck = new THREE.Group();
  neck.position.set(0, 0.3, 0);
  chest.add(neck);

  const neckMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.065, 0.1, 10), skinMat);
  neckMesh.position.y = 0.04;
  enableShadows(neckMesh);
  neck.add(neckMesh);

  const head = new THREE.Group();
  head.position.set(0, 0.09, 0);
  neck.add(head);

  // Stylized Anime Cranium & Tapered Chin
  const cranium = new THREE.Mesh(new THREE.SphereGeometry(0.145, 16, 14), skinMat);
  cranium.position.set(0, 0.11, 0);
  cranium.scale.set(0.95, 1.04, 0.98);
  enableShadows(cranium);
  head.add(cranium);

  // Anime Eyes (visible when camera orbits around front)
  const makeEye = (side: number) => {
    const eyeGroup = new THREE.Group();
    eyeGroup.position.set(side * 0.052, 0.105, 0.128);
    const lash = new THREE.Mesh(new THREE.BoxGeometry(0.042, 0.012, 0.015), eyeDarkMat);
    lash.position.y = 0.014;
    lash.rotation.z = side * -0.08;
    eyeGroup.add(lash);

    const iris = new THREE.Mesh(new THREE.BoxGeometry(0.028, 0.028, 0.014), eyeIrisMat);
    eyeGroup.add(iris);
    head.add(eyeGroup);
  };
  makeEye(1);
  makeEye(-1);

  // Layered Spiky Silver-White Anime Hair Cap & Sculpted Tufts
  const hairCap = new THREE.Mesh(new THREE.SphereGeometry(0.154, 14, 12), hairMat);
  hairCap.position.set(0, 0.13, -0.01);
  hairCap.scale.set(1.02, 1.02, 1.05);
  enableShadows(hairCap);
  head.add(hairCap);

  const hairBack = new THREE.Group();
  hairBack.position.set(0, 0.14, -0.05);
  head.add(hairBack);

  // Sculpted tapered anime hair spikes
  const spikeConfigs: Array<[number, number, number, number, number, number, number]> = [
    [0, 0.06, -0.1, -0.7, 0, 0, 1.1],
    [0.08, 0.04, -0.09, -0.6, 0.35, -0.2, 1.0],
    [-0.08, 0.04, -0.09, -0.6, -0.35, 0.2, 1.0],
    [0.12, 0.0, -0.05, -0.35, 0.6, -0.35, 0.9],
    [-0.12, 0.0, -0.05, -0.35, -0.6, 0.35, 0.9],
    [0, -0.04, -0.11, -0.95, 0, 0, 1.15],
    [0.06, -0.05, -0.1, -0.9, 0.25, -0.1, 1.0],
    [-0.06, -0.05, -0.1, -0.9, -0.25, 0.1, 1.0]
  ];

  spikeConfigs.forEach(([x, y, z, rx, ry, rz, s], idx) => {
    const cone = new THREE.Mesh(
      new THREE.ConeGeometry(0.052 * s, 0.22 * s, 5),
      idx % 2 === 0 ? hairMat : hairShadowMat
    );
    cone.position.set(x, y, z);
    cone.rotation.set(rx, ry, rz);
    enableShadows(cone);
    hairBack.add(cone);
  });

  // Front/side anime bangs framing the face
  const bangConfigs: Array<[number, number, number, number, number]> = [
    [0.03, 0.16, 0.13, 2.65, -0.15],
    [-0.04, 0.16, 0.13, 2.65, 0.18],
    [0.11, 0.12, 0.09, 2.75, -0.38],
    [-0.11, 0.12, 0.09, 2.75, 0.38]
  ];
  bangConfigs.forEach(([x, y, z, rx, rz]) => {
    const bang = new THREE.Mesh(new THREE.ConeGeometry(0.036, 0.16, 4), hairMat);
    bang.position.set(x, y, z);
    bang.rotation.set(rx, 0, rz);
    enableShadows(bang);
    head.add(bang);
  });

  // Vanguard Tech Headband / Ear Visor Fin
  const visorFinLeft = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.09, 0.045), goldTrimMat);
  visorFinLeft.position.set(0.15, 0.13, 0.02);
  visorFinLeft.rotation.x = -0.3;
  head.add(visorFinLeft);

  const visorFinRight = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.09, 0.045), goldTrimMat);
  visorFinRight.position.set(-0.15, 0.13, 0.02);
  visorFinRight.rotation.x = -0.3;
  head.add(visorFinRight);

  // Arms Builder
  const buildArm = (side: 1 | -1) => {
    const shoulder = new THREE.Group();
    shoulder.position.set(side * 0.22, 0.24, 0);
    chest.add(shoulder);

    // Pauldron armor plate
    const pauldron = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.07, 0.12), jacketLightMat);
    pauldron.position.set(side * 0.02, 0.02, 0);
    pauldron.rotation.z = side * -0.25;
    enableShadows(pauldron);
    shoulder.add(pauldron);

    const upperArm = new THREE.Mesh(new THREE.CylinderGeometry(0.052, 0.044, 0.25, 10), jacketDarkMat);
    upperArm.position.y = -0.12;
    enableShadows(upperArm);
    shoulder.add(upperArm);

    const forearm = new THREE.Group();
    forearm.position.set(0, -0.25, 0);
    shoulder.add(forearm);

    const forearmMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.044, 0.036, 0.24, 10), jacketLightMat);
    forearmMesh.position.y = -0.11;
    enableShadows(forearmMesh);
    forearm.add(forearmMesh);

    const cuffMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.044, 0.042, 0.05, 10), goldTrimMat);
    cuffMesh.position.y = -0.2;
    forearm.add(cuffMesh);

    const handMesh = new THREE.Mesh(new THREE.SphereGeometry(0.042, 10, 10), bootMat);
    handMesh.position.y = -0.24;
    handMesh.scale.set(0.85, 1.15, 0.7);
    enableShadows(handMesh);
    forearm.add(handMesh);

    return { shoulder, forearm };
  };

  const leftArm = buildArm(1);
  const rightArm = buildArm(-1);

  // Legs Builder
  const buildLeg = (side: 1 | -1) => {
    const hip = new THREE.Group();
    hip.position.set(side * 0.095, -0.04, 0);
    pelvis.add(hip);

    const thighMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.072, 0.056, 0.42, 10), trousersMat);
    thighMesh.position.y = -0.21;
    enableShadows(thighMesh);
    hip.add(thighMesh);

    const shin = new THREE.Group();
    shin.position.set(0, -0.42, 0);
    hip.add(shin);

    // Knee guard
    const kneePad = new THREE.Mesh(new THREE.BoxGeometry(0.075, 0.085, 0.04), goldTrimMat);
    kneePad.position.set(0, 0, 0.055);
    enableShadows(kneePad);
    shin.add(kneePad);

    const shinMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.056, 0.046, 0.42, 10), bootMat);
    shinMesh.position.y = -0.21;
    enableShadows(shinMesh);
    shin.add(shinMesh);

    const foot = new THREE.Group();
    foot.position.set(0, -0.42, 0);
    shin.add(foot);

    const bootBody = new THREE.Mesh(new THREE.BoxGeometry(0.095, 0.08, 0.21), bootMat);
    bootBody.position.set(0, -0.02, 0.045);
    enableShadows(bootBody);
    foot.add(bootBody);

    const bootSole = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.022, 0.22), jacketLightMat);
    bootSole.position.set(0, -0.055, 0.045);
    foot.add(bootSole);

    return { hip, shin, foot };
  };

  const leftLeg = buildLeg(1);
  const rightLeg = buildLeg(-1);

  let stridePhase = 0;
  let currentBank = 0;

  const updateAnimation = (
    dt: number,
    elapsedTime: number,
    state: AnimationState,
    moveSpeed: number,
    turnDelta: number,
    verticalVelocity: number,
    groundSlopePitch: number
  ) => {
    const smooth = Math.min(1, dt * 12);

    // Banking lean when turning
    const targetBank = THREE.MathUtils.clamp(-turnDelta * 0.28 * (moveSpeed / 8), -0.22, 0.22);
    currentBank = THREE.MathUtils.lerp(currentBank, targetBank, Math.min(1, dt * 8));
    pelvis.rotation.z = currentBank;

    if (state === 'JUMP') {
      // Mid-air anime jump pose
      const upFactor = THREE.MathUtils.clamp(verticalVelocity * 0.08, -0.4, 0.5);
      pelvis.position.y = THREE.MathUtils.lerp(pelvis.position.y, 0.96, smooth);
      spine.rotation.x = THREE.MathUtils.lerp(spine.rotation.x, 0.16 - upFactor * 0.25, smooth);
      chest.rotation.y = THREE.MathUtils.lerp(chest.rotation.y, 0, smooth);

      leftLeg.hip.rotation.x = THREE.MathUtils.lerp(leftLeg.hip.rotation.x, -0.58, smooth);
      leftLeg.shin.rotation.x = THREE.MathUtils.lerp(leftLeg.shin.rotation.x, 0.95, smooth);
      rightLeg.hip.rotation.x = THREE.MathUtils.lerp(rightLeg.hip.rotation.x, 0.22, smooth);
      rightLeg.shin.rotation.x = THREE.MathUtils.lerp(rightLeg.shin.rotation.x, 0.52, smooth);

      leftArm.shoulder.rotation.x = THREE.MathUtils.lerp(leftArm.shoulder.rotation.x, -0.45, smooth);
      leftArm.shoulder.rotation.z = THREE.MathUtils.lerp(leftArm.shoulder.rotation.z, 0.32, smooth);
      leftArm.forearm.rotation.x = THREE.MathUtils.lerp(leftArm.forearm.rotation.x, -0.65, smooth);

      rightArm.shoulder.rotation.x = THREE.MathUtils.lerp(rightArm.shoulder.rotation.x, 0.35, smooth);
      rightArm.shoulder.rotation.z = THREE.MathUtils.lerp(rightArm.shoulder.rotation.z, -0.32, smooth);
      rightArm.forearm.rotation.x = THREE.MathUtils.lerp(rightArm.forearm.rotation.x, -0.55, smooth);
    } else if (state === 'WALK' || state === 'RUN') {
      const isRun = state === 'RUN';
      const freq = isRun ? 11.2 : 7.4;
      stridePhase += dt * freq;

      const legSwing = isRun ? 0.78 : 0.46;
      const armSwing = isRun ? 0.72 : 0.38;
      const bobAmp = isRun ? 0.055 : 0.028;

      const s = Math.sin(stridePhase);
      const c = Math.cos(stridePhase);

      // Vertical pelvis bob (two peaks per full stride cycle)
      pelvis.position.y = 0.94 + Math.abs(s) * bobAmp - (isRun ? 0.03 : 0);

      // Forward posture lean + counter-twist
      const targetLean = (isRun ? 0.22 : 0.07) + groundSlopePitch * 0.5;
      spine.rotation.x = THREE.MathUtils.lerp(spine.rotation.x, targetLean, smooth);
      chest.rotation.y = -s * (isRun ? 0.16 : 0.09);
      head.rotation.y = s * (isRun ? 0.08 : 0.04);
      head.rotation.x = THREE.MathUtils.lerp(head.rotation.x, isRun ? -0.12 : -0.03, smooth);

      // Legs
      leftLeg.hip.rotation.x = s * legSwing;
      rightLeg.hip.rotation.x = -s * legSwing;

      leftLeg.shin.rotation.x = Math.max(0.06, -c * (isRun ? 1.05 : 0.62) + (isRun ? 0.38 : 0.2));
      rightLeg.shin.rotation.x = Math.max(0.06, c * (isRun ? 1.05 : 0.62) + (isRun ? 0.38 : 0.2));

      // Ground-aligned foot pitch
      leftLeg.foot.rotation.x = -leftLeg.hip.rotation.x * 0.35 + groundSlopePitch;
      rightLeg.foot.rotation.x = -rightLeg.hip.rotation.x * 0.35 + groundSlopePitch;

      // Opposite arm swing
      leftArm.shoulder.rotation.x = -s * armSwing;
      rightArm.shoulder.rotation.x = s * armSwing;
      leftArm.shoulder.rotation.z = isRun ? 0.14 : 0.08;
      rightArm.shoulder.rotation.z = isRun ? -0.14 : -0.08;

      leftArm.forearm.rotation.x = isRun ? -0.82 - Math.max(0, s) * 0.3 : -0.28 - Math.max(0, s) * 0.2;
      rightArm.forearm.rotation.x = isRun ? -0.82 - Math.max(0, -s) * 0.3 : -0.28 - Math.max(0, -s) * 0.2;
    } else {
      // Natural Anime IDLE breathing & subtle poise
      const breath = Math.sin(elapsedTime * 2.3);
      pelvis.position.y = THREE.MathUtils.lerp(pelvis.position.y, 0.94 + breath * 0.008, smooth);
      spine.rotation.x = THREE.MathUtils.lerp(spine.rotation.x, breath * 0.018 + groundSlopePitch * 0.3, smooth);
      chest.rotation.y = THREE.MathUtils.lerp(chest.rotation.y, Math.sin(elapsedTime * 0.9) * 0.05, smooth);
      head.rotation.y = THREE.MathUtils.lerp(head.rotation.y, Math.sin(elapsedTime * 0.65) * 0.09, smooth);
      head.rotation.x = THREE.MathUtils.lerp(head.rotation.x, breath * 0.02, smooth);

      leftLeg.hip.rotation.x = THREE.MathUtils.lerp(leftLeg.hip.rotation.x, -0.04, smooth);
      rightLeg.hip.rotation.x = THREE.MathUtils.lerp(rightLeg.hip.rotation.x, 0.04, smooth);
      leftLeg.shin.rotation.x = THREE.MathUtils.lerp(leftLeg.shin.rotation.x, 0.06, smooth);
      rightLeg.shin.rotation.x = THREE.MathUtils.lerp(rightLeg.shin.rotation.x, 0.06, smooth);
      leftLeg.foot.rotation.x = THREE.MathUtils.lerp(leftLeg.foot.rotation.x, groundSlopePitch, smooth);
      rightLeg.foot.rotation.x = THREE.MathUtils.lerp(rightLeg.foot.rotation.x, groundSlopePitch, smooth);

      leftArm.shoulder.rotation.x = THREE.MathUtils.lerp(leftArm.shoulder.rotation.x, 0.04, smooth);
      rightArm.shoulder.rotation.x = THREE.MathUtils.lerp(rightArm.shoulder.rotation.x, -0.03, smooth);
      leftArm.shoulder.rotation.z = THREE.MathUtils.lerp(leftArm.shoulder.rotation.z, 0.09 + breath * 0.015, smooth);
      rightArm.shoulder.rotation.z = THREE.MathUtils.lerp(rightArm.shoulder.rotation.z, -0.09 - breath * 0.015, smooth);
      leftArm.forearm.rotation.x = THREE.MathUtils.lerp(leftArm.forearm.rotation.x, -0.18, smooth);
      rightArm.forearm.rotation.x = THREE.MathUtils.lerp(rightArm.forearm.rotation.x, -0.18, smooth);
    }

    // Dynamic Wind + Velocity physics on Coat Tails, Hair, and Twin Scarf Ribbons
    const speedFactor = THREE.MathUtils.clamp(moveSpeed / 9.5, 0, 1.2);
    const windWave = Math.sin(elapsedTime * 3.8);

    coatLeft.rotation.x = 0.14 + speedFactor * 0.52 + Math.sin(elapsedTime * 4.5) * 0.06;
    coatRight.rotation.x = 0.14 + speedFactor * 0.52 + Math.cos(elapsedTime * 4.5) * 0.06;
    hairBack.rotation.x = speedFactor * 0.16 + windWave * 0.03;

    for (let i = 0; i < scarfSegmentsLeft.length; i++) {
      const segL = scarfSegmentsLeft[i];
      const segR = scarfSegmentsRight[i];
      const waveL = Math.sin(elapsedTime * 5.2 - i * 0.85) * (0.09 + speedFactor * 0.14);
      const waveR = Math.cos(elapsedTime * 5.0 - i * 0.85) * (0.09 + speedFactor * 0.14);

      if (i === 0) {
        segL.rotation.x = 0.28 + speedFactor * 0.72 + waveL * 0.5;
        segR.rotation.x = 0.28 + speedFactor * 0.72 + waveR * 0.5;
      } else {
        segL.rotation.x = waveL;
        segR.rotation.x = waveR;
      }
      segL.rotation.z = 0.06 + waveL * 0.35;
      segR.rotation.z = -0.06 - waveR * 0.35;
    }
  };

  return {
    root,
    pelvis,
    spine,
    chest,
    neck,
    head,
    hairBack,
    leftShoulder: leftArm.shoulder,
    leftForearm: leftArm.forearm,
    rightShoulder: rightArm.shoulder,
    rightForearm: rightArm.forearm,
    leftHip: leftLeg.hip,
    leftShin: leftLeg.shin,
    leftFoot: leftLeg.foot,
    rightHip: rightLeg.hip,
    rightShin: rightLeg.shin,
    rightFoot: rightLeg.foot,
    coatLeft,
    coatRight,
    scarfSegmentsLeft,
    scarfSegmentsRight,
    updateAnimation
  };
}
