import * as THREE from 'three';
import { ColliderBox, ColliderCylinder, WalkableSurface } from '../types/world';

export class PhysicsWorld {
  public boxes: ColliderBox[] = [];
  public cylinders: ColliderCylinder[] = [];
  public surfaces: WalkableSurface[] = [];

  public worldBounds = {
    minX: -54,
    maxX: 54,
    minZ: -136,
    maxZ: 108
  };

  public addBox(
    id: string,
    centerX: number,
    centerY: number,
    centerZ: number,
    sizeX: number,
    sizeY: number,
    sizeZ: number,
    blocksCamera = true
  ): void {
    this.boxes.push({
      id,
      minX: centerX - sizeX * 0.5,
      maxX: centerX + sizeX * 0.5,
      minY: centerY - sizeY * 0.5,
      maxY: centerY + sizeY * 0.5,
      minZ: centerZ - sizeZ * 0.5,
      maxZ: centerZ + sizeZ * 0.5,
      blocksCamera
    });
  }

  public addCylinder(
    id: string,
    x: number,
    z: number,
    radius: number,
    minY = 0,
    maxY = 12
  ): void {
    this.cylinders.push({ id, x, z, radius, minY, maxY });
  }

  public addFlatSurface(
    id: string,
    minX: number,
    maxX: number,
    minZ: number,
    maxZ: number,
    height: number
  ): void {
    this.surfaces.push({
      id,
      minX,
      maxX,
      minZ,
      maxZ,
      getHeight: () => height
    });
  }

  public addRampSurface(
    id: string,
    minX: number,
    maxX: number,
    minZ: number,
    maxZ: number,
    getHeight: (x: number, z: number) => number
  ): void {
    this.surfaces.push({
      id,
      minX,
      maxX,
      minZ,
      maxZ,
      getHeight
    });
  }

  public getGroundHeight(x: number, z: number, currentY = 0): number {
    let highestReachable = 0;

    for (let i = 0; i < this.surfaces.length; i++) {
      const s = this.surfaces[i];
      if (x >= s.minX && x <= s.maxX && z >= s.minZ && z <= s.maxZ) {
        const h = s.getHeight(x, z);
        // Allow stepping onto surfaces within 1.35m above current foot height
        if (h <= currentY + 1.35 && h > highestReachable) {
          highestReachable = h;
        }
      }
    }

    return highestReachable;
  }

  public resolveHorizontalMovement(
    nextPos: THREE.Vector3,
    playerRadius = 0.52,
    playerHeight = 1.85
  ): void {
    const footY = nextPos.y + 0.38; // allow stepping up low curbs and plinth transitions
    const headY = nextPos.y + playerHeight;
    const radSq = playerRadius * playerRadius;

    // 3 iterative solver passes prevent corner snagging and multi-wall tunneling
    for (let iter = 0; iter < 3; iter++) {
      // Clamp within outer ruined city perimeter
      nextPos.x = Math.max(this.worldBounds.minX, Math.min(this.worldBounds.maxX, nextPos.x));
      nextPos.z = Math.max(this.worldBounds.minZ, Math.min(this.worldBounds.maxZ, nextPos.z));

      // Resolve against AABB boxes
      for (let i = 0; i < this.boxes.length; i++) {
        const b = this.boxes[i];
        if (headY <= b.minY || footY >= b.maxY) continue;

        const closestX = Math.max(b.minX, Math.min(nextPos.x, b.maxX));
        const closestZ = Math.max(b.minZ, Math.min(nextPos.z, b.maxZ));

        const dx = nextPos.x - closestX;
        const dz = nextPos.z - closestZ;
        const distSq = dx * dx + dz * dz;

        if (distSq < radSq) {
          if (distSq > 0.00001) {
            const dist = Math.sqrt(distSq);
            const overlap = playerRadius - dist + 0.001;
            nextPos.x += (dx / dist) * overlap;
            nextPos.z += (dz / dist) * overlap;
          } else {
            // Inside box center fallback: push out along shallowest axis
            const penLeft = Math.abs(nextPos.x - b.minX);
            const penRight = Math.abs(b.maxX - nextPos.x);
            const penBack = Math.abs(nextPos.z - b.minZ);
            const penFront = Math.abs(b.maxZ - nextPos.z);
            const minPen = Math.min(penLeft, penRight, penBack, penFront);
            if (minPen === penLeft) nextPos.x = b.minX - playerRadius - 0.002;
            else if (minPen === penRight) nextPos.x = b.maxX + playerRadius + 0.002;
            else if (minPen === penBack) nextPos.z = b.minZ - playerRadius - 0.002;
            else nextPos.z = b.maxZ + playerRadius + 0.002;
          }
        }
      }

      // Resolve against cylindrical colliders (trees, poles, piers)
      for (let i = 0; i < this.cylinders.length; i++) {
        const c = this.cylinders[i];
        if (headY <= c.minY || footY >= c.maxY) continue;

        const dx = nextPos.x - c.x;
        const dz = nextPos.z - c.z;
        const minDist = playerRadius + c.radius;
        const distSq = dx * dx + dz * dz;

        if (distSq < minDist * minDist) {
          if (distSq > 0.00001) {
            const dist = Math.sqrt(distSq);
            const overlap = minDist - dist + 0.001;
            nextPos.x += (dx / dist) * overlap;
            nextPos.z += (dz / dist) * overlap;
          } else {
            nextPos.x += minDist;
          }
        }
      }
    }

    // Final boundary clamp
    nextPos.x = Math.max(this.worldBounds.minX, Math.min(this.worldBounds.maxX, nextPos.x));
    nextPos.z = Math.max(this.worldBounds.minZ, Math.min(this.worldBounds.maxZ, nextPos.z));
  }

  /**
   * Ray-vs-AABB slab intersection so the third-person camera never clips through buildings
   */
  public resolveCameraCollision(
    pivot: THREE.Vector3,
    desiredCamPos: THREE.Vector3,
    minClearance = 0.42
  ): THREE.Vector3 {
    const dir = new THREE.Vector3().subVectors(desiredCamPos, pivot);
    const maxDist = dir.length();
    if (maxDist < 0.001) return desiredCamPos.clone();
    dir.normalize();

    let closestHit = maxDist;

    for (let i = 0; i < this.boxes.length; i++) {
      const b = this.boxes[i];
      if (b.blocksCamera === false) continue;

      // Expand box slightly for camera padding
      const pad = 0.28;
      const minX = b.minX - pad;
      const maxX = b.maxX + pad;
      const minY = b.minY - pad;
      const maxY = b.maxY + pad;
      const minZ = b.minZ - pad;
      const maxZ = b.maxZ + pad;

      let tmin = 0;
      let tmax = closestHit;

      // X slab
      if (Math.abs(dir.x) < 1e-6) {
        if (pivot.x < minX || pivot.x > maxX) continue;
      } else {
        const invD = 1 / dir.x;
        let t1 = (minX - pivot.x) * invD;
        let t2 = (maxX - pivot.x) * invD;
        if (t1 > t2) {
          const tmp = t1;
          t1 = t2;
          t2 = tmp;
        }
        tmin = Math.max(tmin, t1);
        tmax = Math.min(tmax, t2);
        if (tmin > tmax) continue;
      }

      // Y slab
      if (Math.abs(dir.y) < 1e-6) {
        if (pivot.y < minY || pivot.y > maxY) continue;
      } else {
        const invD = 1 / dir.y;
        let t1 = (minY - pivot.y) * invD;
        let t2 = (maxY - pivot.y) * invD;
        if (t1 > t2) {
          const tmp = t1;
          t1 = t2;
          t2 = tmp;
        }
        tmin = Math.max(tmin, t1);
        tmax = Math.min(tmax, t2);
        if (tmin > tmax) continue;
      }

      // Z slab
      if (Math.abs(dir.z) < 1e-6) {
        if (pivot.z < minZ || pivot.z > maxZ) continue;
      } else {
        const invD = 1 / dir.z;
        let t1 = (minZ - pivot.z) * invD;
        let t2 = (maxZ - pivot.z) * invD;
        if (t1 > t2) {
          const tmp = t1;
          t1 = t2;
          t2 = tmp;
        }
        tmin = Math.max(tmin, t1);
        tmax = Math.min(tmax, t2);
        if (tmin > tmax) continue;
      }

      if (tmin > 0 && tmin < closestHit) {
        closestHit = Math.max(0.95, tmin - minClearance);
      }
    }

    // Also test camera ray against large cylindrical piers (radius >= 0.75m)
    const dirXZSq = dir.x * dir.x + dir.z * dir.z;
    if (dirXZSq > 1e-5) {
      for (let i = 0; i < this.cylinders.length; i++) {
        const c = this.cylinders[i];
        if (c.radius < 0.75) continue;
        const r = c.radius + 0.25;
        const ox = pivot.x - c.x;
        const oz = pivot.z - c.z;
        const bCoef = 2 * (ox * dir.x + oz * dir.z);
        const cCoef = ox * ox + oz * oz - r * r;
        const disc = bCoef * bCoef - 4 * dirXZSq * cCoef;
        if (disc >= 0) {
          const tHit = (-bCoef - Math.sqrt(disc)) / (2 * dirXZSq);
          if (tHit > 0 && tHit < closestHit) {
            const hitY = pivot.y + dir.y * tHit;
            if (hitY >= c.minY && hitY <= c.maxY) {
              closestHit = Math.max(0.95, tHit - minClearance);
            }
          }
        }
      }
    }

    const finalPos = pivot.clone().addScaledVector(dir, closestHit);
    // Keep camera above local ground elevation + 0.62m so it never dips under tilted slabs or stairs
    const groundAtCam = this.getGroundHeight(finalPos.x, finalPos.z, pivot.y + 1.0);
    if (finalPos.y < groundAtCam + 0.62) {
      finalPos.y = groundAtCam + 0.62;
    }

    return finalPos;
  }
}
