import * as THREE from 'three';
import { MaterialLibrary } from './TextureFactory';
import { PhysicsWorld } from './PhysicsWorld';

export interface ExitGateAnimatedRefs {
  outerRing: THREE.Group;
  innerRing: THREE.Group;
  coreCrystal: THREE.Mesh;
  portalField: THREE.Mesh;
  beaconLight: THREE.PointLight;
}

export function buildLevel1Architecture(
  scene: THREE.Scene,
  mats: MaterialLibrary,
  physics: PhysicsWorld
): ExitGateAnimatedRefs {
  const archGroup = new THREE.Group();
  archGroup.name = 'Level1ArchitectureGroup';
  scene.add(archGroup);

  const shadowMesh = (geo: THREE.BufferGeometry, mat: THREE.Material) => {
    const m = new THREE.Mesh(geo, mat);
    m.castShadow = true;
    m.receiveShadow = true;
    return m;
  };

  // ============================================================================
  // 1. TERRAIN, DESTROYED BOULEVARD ROADS, DETAILED PAVEMENTS & GRAND STAIRCASE
  // ============================================================================
  const buildRoadsAndPavements = () => {
    const roadGroup = new THREE.Group();
    archGroup.add(roadGroup);

    // Base sub-earth ground plane
    const baseGround = new THREE.Mesh(
      new THREE.PlaneGeometry(340, 380),
      mats.concreteDamaged
    );
    baseGround.rotation.x = -Math.PI * 0.5;
    baseGround.position.set(0, -0.08, -15);
    baseGround.receiveShadow = true;
    roadGroup.add(baseGround);

    // Main Multi-Lane Asphalt Boulevard (Z = +112 to Z = -100, width 19m)
    const mainRoad = new THREE.Mesh(
      new THREE.BoxGeometry(19.2, 0.16, 214),
      mats.asphaltRoad
    );
    mainRoad.position.set(0, -0.04, 6);
    mainRoad.receiveShadow = true;
    roadGroup.add(mainRoad);

    // Raised Detailed Sidewalk Pavements (West & East flanks, height = 0.24m)
    const westSidewalk = shadowMesh(new THREE.BoxGeometry(11.5, 0.32, 212), mats.sidewalkPaving);
    westSidewalk.position.set(-15.35, 0.08, 6);
    roadGroup.add(westSidewalk);
    physics.addFlatSurface('sidewalk_west', -21.1, -9.6, -100, 112, 0.24);

    const eastSidewalk = shadowMesh(new THREE.BoxGeometry(11.5, 0.32, 212), mats.sidewalkPaving);
    eastSidewalk.position.set(15.35, 0.08, 6);
    roadGroup.add(eastSidewalk);
    physics.addFlatSurface('sidewalk_east', 9.6, 21.1, -100, 112, 0.24);

    // Outer Building Lot Terraces (West & East)
    const westLot = shadowMesh(new THREE.BoxGeometry(36, 0.24, 230), mats.concreteDark);
    westLot.position.set(-38, -0.04, 0);
    roadGroup.add(westLot);

    const eastLot = shadowMesh(new THREE.BoxGeometry(36, 0.24, 230), mats.concreteDark);
    eastLot.position.set(38, -0.04, 0);
    roadGroup.add(eastLot);

    // Beveled Concrete Curbstones & Storm Drain Grates along the boulevard
    for (let z = -96; z <= 104; z += 10) {
      const curbW = shadowMesh(new THREE.BoxGeometry(0.38, 0.34, 8.8), mats.concreteMain);
      curbW.position.set(-9.55, 0.09, z);
      roadGroup.add(curbW);

      const curbE = shadowMesh(new THREE.BoxGeometry(0.38, 0.34, 8.8), mats.concreteMain);
      curbE.position.set(9.55, 0.09, z);
      roadGroup.add(curbE);

      // Cast-iron storm drain grate recessed at curb edge
      const grate = new THREE.Mesh(new THREE.BoxGeometry(0.65, 0.06, 1.2), mats.darkSteel);
      grate.position.set(z % 20 === 0 ? -9.0 : 9.0, 0.03, z + 4.4);
      roadGroup.add(grate);
    }

    // Tectonic Upheaved / Tilted Broken Asphalt Road Slabs with Walkable Elevation
    const tiltedRoadSlabs: Array<[number, number, number, number, number, number, number]> = [
      [-3.2, 0.18, 70, 5.4, 6.2, -0.08, 0.05],
      [3.8, 0.22, 34, 5.8, 7.0, 0.09, -0.06],
      [-2.5, 0.25, -34, 6.0, 6.5, -0.09, -0.04],
      [3.1, 0.2, -78, 5.5, 6.0, 0.07, 0.05]
    ];

    tiltedRoadSlabs.forEach(([sx, sy, sz, sw, sd, rx, rz], idx) => {
      const slab = shadowMesh(new THREE.BoxGeometry(sw, 0.36, sd), mats.asphaltRoad);
      slab.position.set(sx, sy, sz);
      slab.rotation.set(rx, 0, rz);
      roadGroup.add(slab);

      // Sub-base ruptured concrete & exposed utility pipe underneath tilted slab
      const pipe = shadowMesh(
        new THREE.CylinderGeometry(0.24, 0.24, sw * 0.9, 10),
        mats.rustedSteel
      );
      pipe.position.set(sx, 0.14, sz + sd * 0.35);
      pipe.rotation.z = Math.PI * 0.48;
      roadGroup.add(pipe);

      physics.addFlatSurface(
        `tilted_slab_${idx}`,
        sx - sw * 0.45,
        sx + sw * 0.45,
        sz - sd * 0.45,
        sz + sd * 0.45,
        sy + 0.15
      );
    });

    // Pedestrian Zebra Crosswalks at 4 Major Boulevard Intersections
    const crosswalkZPositions = [68, 24, -38, -90];
    crosswalkZPositions.forEach((cwz) => {
      const cwMesh = new THREE.Mesh(
        new THREE.BoxGeometry(18.4, 0.05, 4.2),
        mats.crosswalkMarking
      );
      cwMesh.position.set(0, 0.03, cwz);
      cwMesh.receiveShadow = true;
      roadGroup.add(cwMesh);
    });

    // Central Boulevard Median Planters (Beveled concrete curb, dark earth bed, low greenery & hazard bollards)
    const medianZPositions = [80, 42, 4, -56, -86];
    medianZPositions.forEach((mz, idx) => {
      const medianGroup = new THREE.Group();
      medianGroup.position.set(0, 0, mz);
      roadGroup.add(medianGroup);

      const curbBox = shadowMesh(new THREE.BoxGeometry(1.65, 0.42, 7.6), mats.concreteMain);
      curbBox.position.y = 0.21;
      medianGroup.add(curbBox);

      const soilBed = new THREE.Mesh(new THREE.BoxGeometry(1.15, 0.45, 6.8), mats.treeBark);
      soilBed.position.y = 0.22;
      soilBed.receiveShadow = true;
      medianGroup.add(soilBed);

      // Low median shrub clusters
      [-2.1, 0, 2.1].forEach((sz, sIdx) => {
        const bush = shadowMesh(
          new THREE.DodecahedronGeometry(0.48, 1),
          (idx + sIdx) % 2 === 0 ? mats.foliageCanopy : mats.foliageSunlit
        );
        bush.position.set(0, 0.58, sz);
        bush.scale.set(1.0, 0.72, 1.15);
        medianGroup.add(bush);
      });

      // Illuminated amber keep-right traffic bollards at South & North ends of each median
      [-3.45, 3.45].forEach((bz) => {
        const bollardPost = shadowMesh(
          new THREE.CylinderGeometry(0.12, 0.15, 0.82, 8),
          mats.darkSteel
        );
        bollardPost.position.set(0, 0.78, bz);
        medianGroup.add(bollardPost);

        const bollardLight = new THREE.Mesh(
          new THREE.CylinderGeometry(0.125, 0.125, 0.18, 8),
          mats.amberBeacon
        );
        bollardLight.position.set(0, 1.08, bz);
        medianGroup.add(bollardLight);
      });

      physics.addBox(`median_${idx}`, 0, 0.45, mz, 1.65, 0.9, 7.6, false);
    });

    // Northern Elevated Sanctuary Terrace (Z = -106 to Z = -140, Height = 3.2m)
    const northTerrace = shadowMesh(new THREE.BoxGeometry(78, 3.4, 34), mats.sidewalkPaving);
    northTerrace.position.set(0, 1.5, -123);
    roadGroup.add(northTerrace);
    physics.addFlatSurface('north_sanctuary_terrace', -38, 38, -138, -106, 3.2);

    // Retaining Wall & Upper Safety Balustrade flanking the Northern Sanctuary Terrace
    const retainWest = shadowMesh(new THREE.BoxGeometry(28, 4.4, 2.2), mats.concreteDark);
    retainWest.position.set(-23.5, 2.2, -105.5);
    roadGroup.add(retainWest);
    physics.addBox('retain_west', -23.5, 2.3, -105.5, 28, 4.6, 2.4, true);

    const retainEast = shadowMesh(new THREE.BoxGeometry(28, 4.4, 2.2), mats.concreteDark);
    retainEast.position.set(23.5, 2.2, -105.5);
    roadGroup.add(retainEast);
    physics.addBox('retain_east', 23.5, 2.3, -105.5, 28, 4.6, 2.4, true);

    // Grand Ceremonial Approach Staircase (Z = -96 to Z = -106, Width = 18m, Rising Y = 0 to Y = 3.2m)
    const stepCount = 14;
    for (let s = 0; s < stepCount; s++) {
      const t = (s + 1) / stepCount;
      const stepH = t * 3.2;
      const stepZ = -96 - t * 10;
      const stepMesh = shadowMesh(new THREE.BoxGeometry(18, 0.32, 0.85), mats.concreteWarm);
      stepMesh.position.set(0, stepH - 0.14, stepZ);
      roadGroup.add(stepMesh);

      // Center ceremonial golden trim inlay on alternate steps
      if (s % 2 === 0) {
        const inlay = new THREE.Mesh(new THREE.BoxGeometry(3.6, 0.33, 0.42), mats.astralGoldTrim);
        inlay.position.set(0, stepH - 0.13, stepZ);
        roadGroup.add(inlay);
      }
    }

    // Staircase stepped balustrades
    const balWest = shadowMesh(new THREE.BoxGeometry(1.1, 1.2, 11.2), mats.concreteMain);
    balWest.position.set(-9.4, 2.0, -101);
    balWest.rotation.x = 0.31;
    roadGroup.add(balWest);
    physics.addBox('stair_bal_west', -9.4, 2.0, -101, 1.2, 3.8, 11.0, false);

    const balEast = shadowMesh(new THREE.BoxGeometry(1.1, 1.2, 11.2), mats.concreteMain);
    balEast.position.set(9.4, 2.0, -101);
    balEast.rotation.x = 0.31;
    roadGroup.add(balEast);
    physics.addBox('stair_bal_east', 9.4, 2.0, -101, 1.2, 3.8, 11.0, false);

    // Register smooth walkable ramp surface for the Grand Staircase
    physics.addRampSurface('north_grand_stairs', -8.8, 8.8, -106.5, -95.5, (_x, z) => {
      const progress = THREE.MathUtils.clamp((-95.8 - z) / 10.2, 0, 1);
      return progress * 3.2;
    });
  };

  buildRoadsAndPavements();

  // ============================================================================
  // 2. MONUMENTAL DAMAGED CITY ENTRANCE ARCH (GATE-00 at Z = +86)
  // ============================================================================
  const buildMonumentalCityEntrance = () => {
    const gate = new THREE.Group();
    gate.position.set(0, 0, 86);
    archGroup.add(gate);

    // West & East Monumental 22m Fortified Concrete Pylons
    [-13.5, 13.5].forEach((px, idx) => {
      const side = px < 0 ? -1 : 1;
      const pylonGroup = new THREE.Group();
      pylonGroup.position.set(px, 0, 0);
      gate.add(pylonGroup);

      // Stepped armored foundation base
      const base = shadowMesh(new THREE.BoxGeometry(7.2, 4.5, 8.4), mats.concreteDark);
      base.position.y = 2.25;
      pylonGroup.add(base);

      // Sloped structural buttress ribs
      const buttress = shadowMesh(new THREE.BoxGeometry(2.2, 14.0, 6.2), mats.concreteWarm);
      buttress.position.set(side * 2.8, 7.0, 0);
      buttress.rotation.z = side * 0.14;
      pylonGroup.add(buttress);

      // Main 21m Brutalist concrete shaft with recessed architectural grooves
      const shaft = shadowMesh(new THREE.BoxGeometry(5.6, 21.0, 6.4), mats.concreteMain);
      shaft.position.y = 10.5;
      pylonGroup.add(shaft);

      for (let h = 5; h <= 17; h += 4) {
        const rib = shadowMesh(new THREE.BoxGeometry(6.0, 0.55, 6.8), mats.concreteDark);
        rib.position.y = h;
        pylonGroup.add(rib);
      }

      // Upper cantilevered gantry crown
      const crown = shadowMesh(new THREE.BoxGeometry(6.8, 2.4, 7.4), mats.concreteDark);
      crown.position.set(side * -0.8, 20.8, 0);
      pylonGroup.add(crown);

      // Amber aircraft warning beacon on top
      const beacon = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.28, 0.65, 8), mats.amberBeacon);
      beacon.position.set(0, 22.3, 0);
      pylonGroup.add(beacon);

      // Ruined Quarantine Checkpoint Booth at inner base of each pylon
      const booth = shadowMesh(new THREE.BoxGeometry(2.8, 3.1, 3.6), mats.rustedSteel);
      booth.position.set(side * -4.2, 1.55, 1.5);
      pylonGroup.add(booth);

      const boothWindow = new THREE.Mesh(new THREE.PlaneGeometry(2.2, 1.1), mats.windowIntact);
      boothWindow.position.set(side * -5.62, 2.0, 1.5);
      boothWindow.rotation.y = side * -Math.PI * 0.5;
      pylonGroup.add(boothWindow);

      // Register Pylon & Booth Colliders
      physics.addBox(`entrance_pylon_${idx}`, px, 11, 86, 7.2, 22, 8.4, true);
      physics.addBox(`entrance_booth_${idx}`, px + side * -4.2, 1.6, 87.5, 2.8, 3.2, 3.6, true);
    });

    // Fractured Overhead Lintel Skybridge (Sheared in the center from the Calamity!)
    const westSpan = new THREE.Group();
    westSpan.position.set(-6.8, 17.6, 0);
    westSpan.rotation.z = -0.11; // sagging toward center breach
    gate.add(westSpan);

    const westBeam = shadowMesh(new THREE.BoxGeometry(11.5, 3.2, 4.8), mats.concreteMain);
    westSpan.add(westBeam);

    // Protruding sheared steel I-beams at the central fracture
    for (let b = -1.6; b <= 1.6; b += 1.6) {
      const girder = shadowMesh(new THREE.BoxGeometry(4.2, 0.42, 0.38), mats.rustedSteel);
      girder.position.set(6.2, -0.4, b);
      girder.rotation.z = -0.22;
      westSpan.add(girder);
    }

    const eastSpan = new THREE.Group();
    eastSpan.position.set(7.2, 18.0, 0);
    eastSpan.rotation.z = 0.08;
    gate.add(eastSpan);

    const eastBeam = shadowMesh(new THREE.BoxGeometry(10.8, 3.2, 4.8), mats.concreteMain);
    eastSpan.add(eastBeam);

    // Monumental District Signage Plaque mounted on Entrance Arch
    const signMat = mats.createSignMaterial(
      'KYORAKU // SECTOR 01',
      'OUTER QUARANTINE GATE — RESTRICTED ZONE',
      '#ff8a3d'
    );
    const signBoard = new THREE.Mesh(new THREE.BoxGeometry(9.2, 2.2, 0.25), signMat);
    signBoard.position.set(0, 0.2, 2.5);
    westSpan.add(signBoard);
  };

  buildMonumentalCityEntrance();

  // ============================================================================
  // Helper: Architectural Window Bay, Pilasters & Illuminated Interior Generator
  // ============================================================================
  const addWindowGrid = (
    parent: THREE.Group,
    width: number,
    height: number,
    cols: number,
    rows: number,
    zOffset: number,
    rotY = 0,
    seed = 1
  ) => {
    const gridGroup = new THREE.Group();
    gridGroup.rotation.y = rotY;
    parent.add(gridGroup);

    const cellW = width / cols;
    const cellH = height / rows;

    // Vertical architectural concrete pilasters framing window columns
    for (let c = 0; c <= cols; c++) {
      const px = -width * 0.5 + c * cellW;
      const pilaster = shadowMesh(
        new THREE.BoxGeometry(0.22, height, 0.28),
        mats.concreteDark
      );
      pilaster.position.set(px, height * 0.5, zOffset);
      gridGroup.add(pilaster);
    }

    // Shared geometries per window grid to minimize GPU buffer allocations & draw overhead
    const sharedPaneGeo = new THREE.PlaneGeometry(cellW * 0.76, cellH * 0.68);
    const sharedShardGeo = new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(-cellW * 0.36, -cellH * 0.32, 0),
      new THREE.Vector3(cellW * 0.25, -cellH * 0.32, 0),
      new THREE.Vector3(-cellW * 0.36, cellH * 0.28, 0)
    ]);
    sharedShardGeo.computeVertexNormals();
    const sharedAcGeo = new THREE.BoxGeometry(0.78, 0.52, 0.42);
    const sharedBandGeo = new THREE.BoxGeometry(width + 0.16, 0.2, 0.34);

    for (let r = 0; r < rows; r++) {
      const wy = (r + 0.5) * cellH;

      // Continuous horizontal architectural sill/spandrel band across the entire floor row
      const floorBand = shadowMesh(sharedBandGeo, mats.concreteDark);
      floorBand.position.set(0, wy - cellH * 0.38, zOffset);
      gridGroup.add(floorBand);

      for (let c = 0; c < cols; c++) {
        const wx = -width * 0.5 + (c + 0.5) * cellW;
        const hash = (r * 17 + c * 31 + seed * 13) % 12;

        if (hash < 4) {
          // Intact sky-reflective anime window pane
          const pane = new THREE.Mesh(sharedPaneGeo, mats.windowIntact);
          pane.position.set(wx, wy, zOffset + 0.04);
          gridGroup.add(pane);
        } else if (hash === 4 || hash === 5) {
          // Warm golden-amber illuminated interior window (lived-in anime city depth)
          const pane = new THREE.Mesh(sharedPaneGeo, mats.windowWarmLit);
          pane.position.set(wx, wy, zOffset + 0.04);
          gridGroup.add(pane);
        } else if (hash === 6) {
          // Cool cyan emergency/lab illuminated interior window
          const pane = new THREE.Mesh(sharedPaneGeo, mats.windowCyanLit);
          pane.position.set(wx, wy, zOffset + 0.04);
          gridGroup.add(pane);
        } else {
          // Dark breached interior cavity + jagged triangular broken glass shard
          const cavity = new THREE.Mesh(sharedPaneGeo, mats.charredVehicle);
          cavity.position.set(wx, wy, zOffset + 0.02);
          gridGroup.add(cavity);

          const shard = new THREE.Mesh(sharedShardGeo, mats.windowShard);
          shard.position.set(wx, wy, zOffset + 0.06);
          gridGroup.add(shard);
        }

        // Exterior AC condenser box mounted below selected windows
        if (hash === 2 || hash === 8) {
          const acBox = shadowMesh(sharedAcGeo, mats.rustedSteel);
          acBox.position.set(wx + cellW * 0.16, wy - cellH * 0.44, zOffset + 0.22);
          gridGroup.add(acBox);
        }
      }
    }
  };

  // ============================================================================
  // 3. NINE VISUALLY DISTINCT RUINED BUILDINGS (B1 through B9)
  // ============================================================================

  // ----------------------------------------------------------------------------
  // BUILDING 1: Aegis Transit Authority Terminal (West Entrance Flank, Z = +58)
  // Curved cantilevered boarding canopy, open concourse pillars, ticket hall
  // ----------------------------------------------------------------------------
  const buildB1TransitTerminal = () => {
    const b1 = new THREE.Group();
    b1.position.set(-26, 0, 58);
    archGroup.add(b1);

    // Raised station concourse platform + walkable front step ramp from sidewalk
    const platform = shadowMesh(new THREE.BoxGeometry(13.5, 0.6, 22), mats.sidewalkPaving);
    platform.position.set(0, 0.3, 0);
    b1.add(platform);
    physics.addFlatSurface('b1_concourse_platform', -32.7, -19.2, 47.0, 69.0, 0.6);

    const frontStep = shadowMesh(new THREE.BoxGeometry(1.1, 0.42, 21.6), mats.concreteWarm);
    frontStep.position.set(7.2, 0.21, 0);
    b1.add(frontStep);
    physics.addRampSurface('b1_entry_steps', -19.4, -18.0, 47.2, 68.8, (x) => {
      const t = THREE.MathUtils.clamp((-18.0 - x) / 1.4, 0, 1);
      return 0.24 + t * 0.36;
    });

    // Rear concrete structural spine wall with ceramic tile station wainscoting
    const rearWall = shadowMesh(new THREE.BoxGeometry(4.2, 11.5, 21.2), mats.ceramicTileFacade);
    rearWall.position.set(-4.4, 5.75, 0);
    b1.add(rearWall);
    physics.addBox('b1_rear_wall', -30.4, 5.8, 58, 4.4, 11.6, 21.4, true);

    // North & South terminal wing walls with side glazing
    const wingN = shadowMesh(new THREE.BoxGeometry(12.2, 10.5, 2.4), mats.concreteDark);
    wingN.position.set(0, 5.25, -9.6);
    b1.add(wingN);
    physics.addBox('b1_wing_n', -26, 5.25, 48.4, 12.2, 10.5, 2.4, true);

    const wingS = shadowMesh(new THREE.BoxGeometry(12.2, 10.5, 2.4), mats.concreteDark);
    wingS.position.set(0, 5.25, 9.6);
    b1.add(wingS);
    physics.addBox('b1_wing_s', -26, 5.25, 67.6, 12.2, 10.5, 2.4, true);

    // Exposed Ticket Hall Interior: 5 Fluted Steel Concourse Columns + Ticket Kiosks + Fallen Departure Board
    for (let cz = -6.4; cz <= 6.4; cz += 3.2) {
      const col = shadowMesh(new THREE.CylinderGeometry(0.38, 0.44, 10.2, 10), mats.rustedSteel);
      col.position.set(4.8, 5.1, cz);
      b1.add(col);
      physics.addCylinder(`b1_col_${cz}`, -21.2, 58 + cz, 0.48, 0, 10);
    }

    // Interior Automated Ticket Turnstiles & Glowing Fare Gates
    for (let tz = -4.5; tz <= 4.5; tz += 2.25) {
      const gateKiosk = shadowMesh(new THREE.BoxGeometry(1.4, 1.1, 0.36), mats.darkSteel);
      gateKiosk.position.set(1.2, 1.15, tz);
      b1.add(gateKiosk);

      const scannerGlow = new THREE.Mesh(
        new THREE.BoxGeometry(0.22, 0.08, 0.28),
        mats.windowCyanLit
      );
      scannerGlow.position.set(1.75, 1.72, tz);
      b1.add(scannerGlow);
    }

    // Fallen Electronic Departure Schedule Board inside concourse
    const fallenBoard = shadowMesh(new THREE.BoxGeometry(0.35, 1.4, 5.8), mats.darkSteel);
    fallenBoard.position.set(-1.5, 6.2, 1.5);
    fallenBoard.rotation.x = 0.28;
    b1.add(fallenBoard);

    // Curved Cantilevered Steel-and-Glass Station Canopy with overhead arch ribs
    const canopyDeck = shadowMesh(new THREE.BoxGeometry(14.8, 0.85, 22.4), mats.concreteDark);
    canopyDeck.position.set(1.2, 10.4, 0);
    canopyDeck.rotation.z = 0.06;
    b1.add(canopyDeck);

    for (let rz = -9; rz <= 9; rz += 4.5) {
      const archRib = shadowMesh(new THREE.BoxGeometry(15.2, 0.48, 0.45), mats.rustedSteel);
      archRib.position.set(1.2, 11.0, rz);
      archRib.rotation.z = 0.06;
      b1.add(archRib);
    }

    // Upper clerestory glass band
    addWindowGrid(b1, 16.5, 4.2, 5, 2, 6.22, Math.PI * 0.5, 11);

    // Illuminated Station Fascia Sign
    const signMat = mats.createSignMaterial(
      'AEGIS TRANSIT // LINE 04',
      'CENTRAL CONCOURSE — ALL TRAINS SUSPENDED',
      '#4deeea'
    );
    const fasciaSign = new THREE.Mesh(new THREE.BoxGeometry(0.24, 1.65, 11.5), signMat);
    fasciaSign.position.set(8.65, 10.4, 0);
    b1.add(fasciaSign);

    // Street-Side Covered Bus Stop Shelter on Sidewalk outside B1 (X = -12.2, Z = 62)
    const busShelter = new THREE.Group();
    busShelter.position.set(13.8, 0.24, 4.0);
    b1.add(busShelter);

    const shelterRoof = shadowMesh(new THREE.BoxGeometry(2.1, 0.16, 4.6), mats.darkSteel);
    shelterRoof.position.set(0, 2.55, 0);
    shelterRoof.rotation.z = -0.06;
    busShelter.add(shelterRoof);

    const shelterBack = new THREE.Mesh(new THREE.BoxGeometry(0.08, 2.3, 4.2), mats.windowShard);
    shelterBack.position.set(-0.85, 1.25, 0);
    busShelter.add(shelterBack);

    const shelterBench = shadowMesh(new THREE.BoxGeometry(0.55, 0.48, 2.6), mats.rustedSteel);
    shelterBench.position.set(-0.45, 0.35, -0.4);
    busShelter.add(shelterBench);

    const routeLightbox = new THREE.Mesh(
      new THREE.BoxGeometry(0.95, 2.2, 0.18),
      mats.windowCyanLit
    );
    routeLightbox.position.set(-0.35, 1.25, 2.15);
    busShelter.add(routeLightbox);
  };

  buildB1TransitTerminal();

  // ----------------------------------------------------------------------------
  // BUILDING 2: Kurokawa Brutalist Hab-Block Tower (East South Boulevard, Z = +54)
  // 5-story modular residential complex with ground-floor shopfront & wrap-around balconies
  // ----------------------------------------------------------------------------
  const buildB2KurokawaHab = () => {
    const b2 = new THREE.Group();
    b2.position.set(27, 0, 54);
    archGroup.add(b2);

    // Main 5-story ceramic-tile & brutalist residential core
    const core = shadowMesh(new THREE.BoxGeometry(14.5, 18.5, 19.0), mats.ceramicTileFacade);
    core.position.set(0, 9.25, 0);
    b2.add(core);
    physics.addBox('b2_core', 27, 9.25, 54, 14.8, 18.5, 19.2, true);

    // Heavy Brutalist Corner Columns & Roof Cornice
    [
      [-7.1, -9.3],
      [-7.1, 9.3],
      [7.1, -9.3],
      [7.1, 9.3]
    ].forEach(([cx, cz]) => {
      const col = shadowMesh(new THREE.BoxGeometry(1.1, 18.8, 1.1), mats.concreteDark);
      col.position.set(cx, 9.4, cz);
      b2.add(col);
    });

    const cornice = shadowMesh(new THREE.BoxGeometry(15.3, 0.75, 19.8), mats.concreteDark);
    cornice.position.set(0, 18.6, 0);
    b2.add(cornice);

    // Recessed window bays on West (street-facing), South, and North facades
    addWindowGrid(b2, 16.4, 14.2, 5, 4, -7.28, -Math.PI * 0.5, 22);
    addWindowGrid(b2, 11.8, 14.2, 3, 4, 9.54, 0, 25);
    addWindowGrid(b2, 11.8, 14.2, 3, 4, 9.54, Math.PI, 29);

    // Ground-Floor Convenience Store Shopfront Podium with Rollup Shutter, Striped Awning & Vending Machines
    const shopShutterPanel = shadowMesh(
      new THREE.BoxGeometry(0.18, 2.9, 6.8),
      mats.shopShutter
    );
    shopShutterPanel.position.set(-7.32, 1.65, 3.2);
    b2.add(shopShutterPanel);

    const shopAwning = shadowMesh(
      new THREE.BoxGeometry(2.1, 0.22, 7.6),
      mats.awningFabricVermilion
    );
    shopAwning.position.set(-8.15, 3.25, 3.2);
    shopAwning.rotation.z = 0.24;
    b2.add(shopAwning);

    // Pair of Illuminated Anime Beverage Vending Machines beside the shopfront
    [-2.4, -3.7].forEach((vz) => {
      const vmBody = shadowMesh(new THREE.BoxGeometry(0.88, 2.05, 1.05), mats.darkSteel);
      vmBody.position.set(-7.75, 1.25, vz);
      b2.add(vmBody);

      const vmFace = new THREE.Mesh(
        new THREE.PlaneGeometry(0.96, 1.88),
        mats.vendingMachineFront
      );
      vmFace.position.set(-8.2, 1.25, vz);
      vmFace.rotation.y = -Math.PI * 0.5;
      b2.add(vmFace);
    });

    // Staggered Wrap-Around Concrete Balconies with Iron Railings & AC Units on 4 stories
    for (let floor = 1; floor <= 4; floor++) {
      const fy = floor * 3.6 + 0.4;
      const offsetZ = (floor % 2 === 0 ? 1 : -1) * 1.2;

      const balSlab = shadowMesh(new THREE.BoxGeometry(2.6, 0.32, 14.5), mats.concreteMain);
      balSlab.position.set(-8.2, fy, offsetZ);
      b2.add(balSlab);

      const balParapet = shadowMesh(new THREE.BoxGeometry(0.22, 1.05, 14.5), mats.concreteDark);
      balParapet.position.set(-9.38, fy + 0.62, offsetZ);
      b2.add(balParapet);

      // Rusted vertical balcony divider screens
      for (let dz = -5; dz <= 5; dz += 5) {
        const divider = shadowMesh(new THREE.BoxGeometry(2.4, 2.2, 0.16), mats.rustedSteel);
        divider.position.set(-8.2, fy + 1.15, offsetZ + dz);
        b2.add(divider);
      }
    }

    // Sheared Upper-North-West Corner Cross-Section (Believable structural fracture at 5th story)
    const shearedSlab = shadowMesh(
      new THREE.BoxGeometry(5.2, 0.45, 5.8),
      mats.concreteDamaged
    );
    shearedSlab.position.set(-5.8, 17.8, -7.2);
    shearedSlab.rotation.set(-0.22, 0.12, 0.28);
    b2.add(shearedSlab);

    // Rooftop Cylindrical Steel Water Cistern on Truss Legs + Elevator Penthouse
    const penthouse = shadowMesh(new THREE.BoxGeometry(4.6, 3.2, 5.2), mats.concreteDark);
    penthouse.position.set(2.2, 20.1, -3.5);
    b2.add(penthouse);

    const tankLegs = shadowMesh(new THREE.BoxGeometry(2.8, 2.2, 2.8), mats.rustedSteel);
    tankLegs.position.set(-2.5, 19.6, 4.2);
    b2.add(tankLegs);

    const waterTank = shadowMesh(
      new THREE.CylinderGeometry(1.65, 1.65, 3.4, 12),
      mats.rustedSteel
    );
    waterTank.position.set(-2.5, 22.2, 4.2);
    b2.add(waterTank);
  };

  buildB2KurokawaHab();

  // ----------------------------------------------------------------------------
  // BUILDING 3: Helion Bio-Acoustic Research Annex (West Mid-Town, Z = +18)
  // COLLAPSED EAST FACADE WITH WALKABLE RAMP & EXPOSED 2-STORY INTERIOR!
  // ----------------------------------------------------------------------------
  const buildB3HelionResearchAnnex = () => {
    const b3 = new THREE.Group();
    b3.position.set(-28, 0, 18);
    archGroup.add(b3);

    // 1st Floor Interior Terrazzo Deck (Y = 1.1m, walkable!)
    const floor1 = shadowMesh(new THREE.BoxGeometry(15.0, 1.1, 18.4), mats.interiorFloor);
    floor1.position.set(0, 0.55, 0);
    b3.add(floor1);

    // Register Walkable Interior Floor Surface (X = -34.5 to -20.5, Z = 9.5 to 26.5, Height = 1.12m)
    physics.addFlatSurface('b3_interior_floor1', -34.8, -20.4, 9.2, 26.8, 1.12);

    // Sheared Exterior Wall Slab that fell outward to form a Walkable Ramp from the sidewalk into the building!
    const rampSlab = shadowMesh(new THREE.BoxGeometry(5.6, 0.42, 7.6), mats.concreteDamaged);
    rampSlab.position.set(9.4, 0.62, 0);
    rampSlab.rotation.z = -0.18;
    b3.add(rampSlab);

    // Register Walkable Ramp Surface from X = -16.2 (sidewalk height 0.24) to X = -20.8 (interior floor 1.12)
    physics.addRampSurface('b3_collapsed_ramp', -21.2, -16.0, 14.2, 21.8, (x) => {
      const t = THREE.MathUtils.clamp((-16.2 - x) / 4.6, 0, 1);
      return 0.24 + t * 0.88;
    });

    // Intact West (Back), North, and South Walls of B3
    const westWall = shadowMesh(new THREE.BoxGeometry(1.4, 15.2, 18.4), mats.concreteMain);
    westWall.position.set(-6.8, 7.6, 0);
    b3.add(westWall);
    physics.addBox('b3_west_wall', -34.8, 7.6, 18, 1.6, 15.2, 18.4, true);

    const northWall = shadowMesh(new THREE.BoxGeometry(15.0, 15.2, 1.4), mats.concreteDark);
    northWall.position.set(0, 7.6, -8.5);
    b3.add(northWall);
    physics.addBox('b3_north_wall', -28, 7.6, 9.5, 15.0, 15.2, 1.6, true);

    const southWall = shadowMesh(new THREE.BoxGeometry(15.0, 15.2, 1.4), mats.concreteDark);
    southWall.position.set(0, 7.6, 8.5);
    b3.add(southWall);
    physics.addBox('b3_south_wall', -28, 7.6, 26.5, 15.0, 15.2, 1.6, true);

    // Exposed 2nd Floor Mezzanine Deck (Half-collapsed with jagged concrete edge and protruding rebar!)
    const floor2 = shadowMesh(new THREE.BoxGeometry(11.2, 0.48, 17.2), mats.concreteMain);
    floor2.position.set(-1.6, 5.6, 0);
    b3.add(floor2);

    // Exposed 3rd Floor & Roof Slab with hanging steel I-beams
    const floor3 = shadowMesh(new THREE.BoxGeometry(13.4, 0.55, 17.6), mats.concreteDark);
    floor3.position.set(-0.6, 10.2, 0);
    b3.add(floor3);

    const roofSlab = shadowMesh(new THREE.BoxGeometry(14.6, 0.65, 18.2), mats.concreteMain);
    roofSlab.position.set(0, 14.9, 0);
    b3.add(roofSlab);

    // Protruding twisted rebar rods along the sheared 2nd & 3rd floor edges
    for (let rz = -7.0; rz <= 7.0; rz += 1.75) {
      const rebar2 = shadowMesh(new THREE.CylinderGeometry(0.03, 0.03, 1.6, 5), mats.rebarMetal);
      rebar2.position.set(4.5, 5.5, rz);
      rebar2.rotation.z = Math.PI * 0.42;
      b3.add(rebar2);

      const rebar3 = shadowMesh(new THREE.CylinderGeometry(0.03, 0.03, 1.8, 5), mats.rebarMetal);
      rebar3.position.set(6.5, 10.1, rz);
      rebar3.rotation.z = Math.PI * 0.46;
      b3.add(rebar3);
    }

    // Exposed Interior Columns supporting the 2nd & 3rd floors
    const colPositions: Array<[number, number]> = [
      [-3.2, -4.8],
      [-3.2, 4.8],
      [3.8, -5.2],
      [3.8, 5.2]
    ];
    colPositions.forEach(([cx, cz], idx) => {
      const col = shadowMesh(new THREE.BoxGeometry(0.75, 13.8, 0.75), mats.concreteWarm);
      col.position.set(cx, 7.9, cz);
      b3.add(col);
      physics.addBox(`b3_col_${idx}`, -28 + cx, 5.0, 18 + cz, 0.85, 10.0, 0.85, false);
    });

    // Exposed Interior Props: Research Lab Consoles, Bio-Containment Cylinder, Server Racks & Dangling Lights
    const serverRack1 = shadowMesh(new THREE.BoxGeometry(1.2, 2.5, 2.4), mats.darkSteel);
    serverRack1.position.set(-4.8, 2.35, -3.5);
    b3.add(serverRack1);
    physics.addBox('b3_rack1', -32.8, 2.35, 14.5, 1.3, 2.6, 2.5, false);

    const serverLed = new THREE.Mesh(new THREE.PlaneGeometry(0.18, 1.8), mats.amberBeacon);
    serverLed.position.set(-4.18, 2.4, -3.5);
    serverLed.rotation.y = Math.PI * 0.5;
    b3.add(serverLed);

    // Shattered Bio-Resonance Specimen Cylinder in center-back of exposed 1st floor
    const podBase = shadowMesh(new THREE.CylinderGeometry(1.15, 1.25, 0.55, 12), mats.darkSteel);
    podBase.position.set(-2.2, 1.38, 0.2);
    b3.add(podBase);

    const podGlass = new THREE.Mesh(
      new THREE.CylinderGeometry(0.98, 0.98, 2.8, 12, 1, true),
      mats.windowShard
    );
    podGlass.position.set(-2.2, 2.8, 0.2);
    b3.add(podGlass);

    const podCap = shadowMesh(new THREE.CylinderGeometry(1.15, 1.15, 0.45, 12), mats.darkSteel);
    podCap.position.set(-2.2, 4.3, 0.2);
    b3.add(podCap);
    physics.addCylinder('b3_pod', -30.2, 18.2, 1.25, 1.0, 4.6);

    // Interior concrete stairwell flight on the 2nd floor
    const stairFlight = shadowMesh(new THREE.BoxGeometry(2.2, 0.35, 5.4), mats.concreteMain);
    stairFlight.position.set(-4.6, 3.4, 4.2);
    stairFlight.rotation.x = -0.62;
    b3.add(stairFlight);

    // Dangling fluorescent light fixtures under the 1st & 2nd floor ceilings
    for (let lz = -4; lz <= 4; lz += 4) {
      const fixture = shadowMesh(new THREE.BoxGeometry(0.35, 0.12, 2.2), mats.darkSteel);
      fixture.position.set(0.5, 4.95, lz);
      fixture.rotation.z = 0.28;
      fixture.rotation.x = 0.15;
      b3.add(fixture);
    }

    // Exterior Window Grids on North and South walls of B3 + Lab Console Workstation
    addWindowGrid(b3, 12.6, 11.5, 4, 3, 9.25, 0, 33);
    addWindowGrid(b3, 12.6, 11.5, 4, 3, 9.25, Math.PI, 37);

    const labDesk = shadowMesh(new THREE.BoxGeometry(1.4, 1.05, 4.2), mats.darkSteel);
    labDesk.position.set(1.2, 1.62, -4.2);
    b3.add(labDesk);
    physics.addBox('b3_lab_desk', -26.8, 1.65, 13.8, 1.5, 1.2, 4.3, false);

    const holoScreen = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.85, 2.8), mats.windowCyanLit);
    holoScreen.position.set(1.2, 2.48, -4.2);
    b3.add(holoScreen);

    // Helion Lab Exterior Signage
    const signMat = mats.createSignMaterial(
      'HELION BIO-ACOUSTIC LABS',
      'ANNEX 03 — STRUCTURAL BREACH DETECTED',
      '#f5b651'
    );
    const sign = new THREE.Mesh(new THREE.BoxGeometry(0.24, 1.8, 10.5), signMat);
    sign.position.set(7.2, 12.6, 0);
    b3.add(sign);
  };

  buildB3HelionResearchAnnex();

  // ----------------------------------------------------------------------------
  // BUILDING 4: Vermillion Commercial Arcade & Severed Skybridge (East Mid-Town, Z = +14)
  // Shopfront colonnade, exterior steel zigzag fire-escape stairs, severed skybridge, rooftop billboard
  // ----------------------------------------------------------------------------
  const buildB4VermillionArcade = () => {
    const b4 = new THREE.Group();
    b4.position.set(28, 0, 14);
    archGroup.add(b4);

    // Main 5-story stepped commercial structure (Dark brick podium + ceramic/concrete upper tiers)
    const lowerBlock = shadowMesh(new THREE.BoxGeometry(15.2, 8.5, 22.0), mats.darkBrickFacade);
    lowerBlock.position.set(0, 4.25, 0);
    b4.add(lowerBlock);

    const upperBlock = shadowMesh(new THREE.BoxGeometry(13.0, 11.5, 19.6), mats.ceramicTileFacade);
    upperBlock.position.set(1.1, 14.2, 0);
    upperBlock.position.y = 14.2;
    b4.add(upperBlock);

    physics.addBox('b4_main', 28, 10, 14, 15.4, 20, 22.2, true);

    // Street-facing & side window curtain grids
    addWindowGrid(b4, 17.5, 10.2, 5, 3, -5.42, -Math.PI * 0.5, 44);
    addWindowGrid(b4, 11.2, 9.8, 3, 3, 9.84, 0, 46);
    addWindowGrid(b4, 11.2, 9.8, 3, 3, 9.84, Math.PI, 48);

    // Ground-floor Recessed Commercial Arcade Colonnade with 3 Distinct Shopfronts!
    const awning = shadowMesh(new THREE.BoxGeometry(3.2, 0.45, 21.4), mats.rustedSteel);
    awning.position.set(-8.6, 4.2, 0);
    b4.add(awning);

    // Arcade colonnade support pillars along sidewalk edge
    for (let pz = -9.0; pz <= 9.0; pz += 6.0) {
      const col = shadowMesh(new THREE.BoxGeometry(0.65, 4.2, 0.65), mats.concreteDark);
      col.position.set(-9.8, 2.1, pz);
      b4.add(col);
    }

    // Shopfront Bay 1 (South): Ramen / Noodle Bar with Vermilion Awning & Glowing Warm Window
    const shop1Window = new THREE.Mesh(new THREE.BoxGeometry(0.2, 2.6, 5.2), mats.windowWarmLit);
    shop1Window.position.set(-7.62, 1.6, 6.2);
    b4.add(shop1Window);

    const shop1Awning = shadowMesh(
      new THREE.BoxGeometry(1.8, 0.2, 5.6),
      mats.awningFabricVermilion
    );
    shop1Awning.position.set(-8.4, 3.15, 6.2);
    shop1Awning.rotation.z = 0.22;
    b4.add(shop1Awning);

    const shop1SignMat = mats.createSignMaterial(
      'AKIRA NOODLE // BISTRO',
      'OPEN LATE — SECTOR 04',
      '#ff8a3d'
    );
    const shop1Sign = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.85, 4.8), shop1SignMat);
    shop1Sign.position.set(-10.1, 3.65, 6.2);
    b4.add(shop1Sign);

    // Shopfront Bay 2 (Center): Shuttered Commercial Electronics Store
    const shop2Shutter = shadowMesh(new THREE.BoxGeometry(0.2, 2.8, 5.4), mats.shopShutter);
    shop2Shutter.position.set(-7.62, 1.6, 0);
    b4.add(shop2Shutter);

    // Shopfront Bay 3 (North): Cyber-Optics / Record Shop with Teal Awning & Cyan Display
    const shop3Window = new THREE.Mesh(new THREE.BoxGeometry(0.2, 2.6, 5.2), mats.windowCyanLit);
    shop3Window.position.set(-7.62, 1.6, -6.2);
    b4.add(shop3Window);

    const shop3Awning = shadowMesh(new THREE.BoxGeometry(1.8, 0.2, 5.6), mats.awningFabricTeal);
    shop3Awning.position.set(-8.4, 3.15, -6.2);
    shop3Awning.rotation.z = 0.22;
    b4.add(shop3Awning);

    // Projecting Vertical Anime District Sign Banners on Upper Facade
    const vBanner1 = new THREE.Mesh(new THREE.BoxGeometry(1.35, 5.8, 0.24), mats.astralGoldTrim);
    vBanner1.position.set(-6.4, 12.2, 7.8);
    b4.add(vBanner1);

    const vBanner2 = new THREE.Mesh(new THREE.BoxGeometry(1.25, 5.2, 0.24), mats.windowCyanLit);
    vBanner2.position.set(-6.4, 11.6, -7.8);
    b4.add(vBanner2);

    // Exterior Steel Zigzag Fire-Escape Staircase mounted on the North-West facade
    for (let f = 1; f <= 4; f++) {
      const fy = f * 3.8;
      const landing = shadowMesh(new THREE.BoxGeometry(2.2, 0.18, 3.6), mats.rustedSteel);
      landing.position.set(-8.4, fy, -6.5);
      b4.add(landing);

      const flight = shadowMesh(new THREE.BoxGeometry(1.1, 0.14, 4.4), mats.darkSteel);
      flight.position.set(-8.4, fy - 1.9, -3.2);
      flight.rotation.x = (f % 2 === 0 ? 1 : -1) * 0.68;
      b4.add(flight);
    }

    // Severed Elevated Pedestrian Skybridge jutting out at Y = 8.4m toward the central boulevard!
    const skybridge = new THREE.Group();
    skybridge.position.set(-10.8, 8.2, 4.5);
    skybridge.rotation.z = 0.09; // sagging downward at severed end
    b4.add(skybridge);

    const bridgeFloor = shadowMesh(new THREE.BoxGeometry(8.5, 0.65, 4.2), mats.concreteMain);
    skybridge.add(bridgeFloor);

    const bridgeRoof = shadowMesh(new THREE.BoxGeometry(7.8, 0.45, 4.2), mats.rustedSteel);
    bridgeRoof.position.set(0.4, 3.1, 0);
    skybridge.add(bridgeRoof);

    // Steel truss ribs & shattered glass panels framing the severed skybridge
    for (let bx = -3.2; bx <= 3.2; bx += 2.1) {
      const ribN = shadowMesh(new THREE.BoxGeometry(0.22, 3.1, 0.22), mats.darkSteel);
      ribN.position.set(bx, 1.55, -1.95);
      skybridge.add(ribN);

      const ribS = shadowMesh(new THREE.BoxGeometry(0.22, 3.1, 0.22), mats.darkSteel);
      ribS.position.set(bx, 1.55, 1.95);
      skybridge.add(ribS);
    }

    // Rooftop Skeletal Steel Billboard Truss Frame (Scarlet Nexus urban signature)
    const billboardGroup = new THREE.Group();
    billboardGroup.position.set(-3.5, 20.0, 0);
    b4.add(billboardGroup);

    for (let bz = -6; bz <= 6; bz += 4) {
      const strut = shadowMesh(new THREE.BoxGeometry(0.32, 5.2, 0.32), mats.rustedSteel);
      strut.position.set(0, 2.6, bz);
      billboardGroup.add(strut);
    }

    const arcadeSign = mats.createSignMaterial(
      'VERMILLION PLAZA ARCADE',
      'COMMERCIAL SECTOR 04 // SKYBRIDGE CLOSED',
      '#ff621f'
    );
    const billboardPanel = new THREE.Mesh(new THREE.BoxGeometry(0.35, 3.8, 13.2), arcadeSign);
    billboardPanel.position.set(-0.25, 2.8, 0);
    billboardGroup.add(billboardPanel);
  };

  buildB4VermillionArcade();

  // ----------------------------------------------------------------------------
  // INFRASTRUCTURE LANDMARK: Collapsed Cross-Sector Highway Viaduct (Z = -14)
  // Spans the boulevard with a buckled central span, sheared piers, and walkable deck ramp!
  // ----------------------------------------------------------------------------
  const buildCollapsedHighwayViaduct = () => {
    const viaduct = new THREE.Group();
    viaduct.position.set(0, 0, -14);
    archGroup.add(viaduct);

    // West Elevated Intact Span (X = -38 to -9.5, Height = 6.2m)
    const westDeck = shadowMesh(new THREE.BoxGeometry(28.5, 1.35, 8.6), mats.concreteMain);
    westDeck.position.set(-23.5, 6.2, 0);
    viaduct.add(westDeck);

    const westParapetN = shadowMesh(new THREE.BoxGeometry(28.5, 1.1, 0.45), mats.concreteDark);
    westParapetN.position.set(-23.5, 7.2, -4.05);
    viaduct.add(westParapetN);

    const westParapetS = shadowMesh(new THREE.BoxGeometry(28.5, 1.1, 0.45), mats.concreteDark);
    westParapetS.position.set(-23.5, 7.2, 4.05);
    viaduct.add(westParapetS);

    // Overhead Highway Directional Gantry Sign on the West Span
    const gantryPillarN = shadowMesh(new THREE.BoxGeometry(0.38, 4.8, 0.38), mats.rustedSteel);
    gantryPillarN.position.set(-14.5, 9.4, -3.9);
    viaduct.add(gantryPillarN);

    const gantryPillarS = shadowMesh(new THREE.BoxGeometry(0.38, 4.8, 0.38), mats.rustedSteel);
    gantryPillarS.position.set(-14.5, 9.4, 3.9);
    viaduct.add(gantryPillarS);

    const gantryCrossbar = shadowMesh(new THREE.BoxGeometry(0.42, 0.42, 8.4), mats.rustedSteel);
    gantryCrossbar.position.set(-14.5, 11.6, 0);
    viaduct.add(gantryCrossbar);

    const hwySignMat = mats.createSignMaterial(
      'EXPWY ROUTE 01 // GUIXU LOOP',
      'DANGER — CENTRAL VIADUCT COLLAPSED AHEAD',
      '#ff8a3d'
    );
    const hwySignBoard = new THREE.Mesh(new THREE.BoxGeometry(0.28, 1.85, 6.8), hwySignMat);
    hwySignBoard.position.set(-14.2, 10.8, 0);
    hwySignBoard.rotation.y = Math.PI * 0.5;
    viaduct.add(hwySignBoard);

    // Cylindrical Reinforced Concrete Viaduct Piers
    const pierCoords: Array<[number, number]> = [
      [-12.5, 6.0],
      [-26.0, 6.0],
      [13.5, 5.8],
      [27.0, 6.0]
    ];
    pierCoords.forEach(([px, ph], idx) => {
      const pier = shadowMesh(new THREE.CylinderGeometry(1.15, 1.32, ph, 12), mats.concreteDark);
      pier.position.set(px, ph * 0.5, 0);
      viaduct.add(pier);

      const capBeam = shadowMesh(new THREE.BoxGeometry(3.2, 1.1, 7.8), mats.concreteMain);
      capBeam.position.set(px, ph - 0.3, 0);
      viaduct.add(capBeam);

      physics.addCylinder(`viaduct_pier_${idx}`, px, -14, 1.35, 0, ph + 1);
    });

    // East Buckled & Tilted Span (Tilts down toward the east sidewalk, forming a dramatic broken arch)
    const eastSpanGroup = new THREE.Group();
    eastSpanGroup.position.set(18.5, 5.4, 0);
    eastSpanGroup.rotation.z = 0.08;
    viaduct.add(eastSpanGroup);

    const eastDeck = shadowMesh(new THREE.BoxGeometry(23.0, 1.35, 8.6), mats.concreteMain);
    eastSpanGroup.add(eastDeck);

    const eastParapetS = shadowMesh(new THREE.BoxGeometry(23.0, 1.05, 0.42), mats.concreteDark);
    eastParapetS.position.set(0, 1.0, 4.0);
    eastSpanGroup.add(eastParapetS);

    // Central Collapsed Deck Slab resting diagonally from the West Pier down to the Eastern Roadway!
    const fallenSpan = new THREE.Group();
    fallenSpan.position.set(-3.2, 3.1, 0);
    fallenSpan.rotation.z = -0.36;
    viaduct.add(fallenSpan);

    const fallenDeck = shadowMesh(new THREE.BoxGeometry(14.5, 1.25, 7.8), mats.concreteDamaged);
    fallenSpan.add(fallenDeck);

    // Side concrete Jersey guardrails on the fallen viaduct deck
    const fallenRailN = shadowMesh(new THREE.BoxGeometry(14.2, 0.78, 0.38), mats.concreteMain);
    fallenRailN.position.set(0, 0.92, -3.65);
    fallenSpan.add(fallenRailN);

    const fallenRailS = shadowMesh(new THREE.BoxGeometry(14.2, 0.78, 0.38), mats.concreteMain);
    fallenRailS.position.set(0, 0.92, 3.65);
    fallenSpan.add(fallenRailS);

    // Protruding twisted rebar cage along the fractured viaduct break
    for (let rz = -3.2; rz <= 3.2; rz += 1.05) {
      const rebar = shadowMesh(new THREE.CylinderGeometry(0.038, 0.038, 2.6, 5), mats.rebarMetal);
      rebar.position.set(7.8, 0.1, rz);
      rebar.rotation.z = Math.PI * 0.44;
      fallenSpan.add(rebar);
    }

    // Register Walkable Ramp on the lower half of the fallen viaduct deck so the player can climb up onto it!
    physics.addRampSurface('viaduct_fallen_ramp', -7.5, 3.6, -17.6, -10.4, (x) => {
      const t = THREE.MathUtils.clamp((3.4 - x) / 10.8, 0, 1);
      return t * 3.8;
    });

    // Side barrier colliders along the low-clearance north/south edges of the fallen span so player enters from the东/east ramp toe
    physics.addBox('viaduct_ramp_rail_n', -1.8, 1.8, -17.8, 11.2, 3.6, 0.65, false);
    physics.addBox('viaduct_ramp_rail_s', -1.8, 1.8, -10.2, 11.2, 3.6, 0.65, false);
    physics.addBox('viaduct_ramp_upper_stop', -7.8, 3.2, -14.0, 0.9, 5.2, 7.6, false);
  };

  buildCollapsedHighwayViaduct();

  // ----------------------------------------------------------------------------
  // BUILDING 5: Old Sentinel Broadcast & Relay Spire (East North-Mid, Z = -34)
  // Leaning 7° octagonal concrete-and-truss tower with catwalks, pipes & dishes
  // ----------------------------------------------------------------------------
  const buildB5SentinelSpire = () => {
    const b5 = new THREE.Group();
    b5.position.set(31, 0, -34);
    archGroup.add(b5);

    // Heavy Concrete Base Bunker with Armored Blast Entrance & Buttress Fins
    const bunker = shadowMesh(new THREE.BoxGeometry(15.5, 6.2, 15.5), mats.concreteDark);
    bunker.position.y = 3.1;
    b5.add(bunker);
    physics.addBox('b5_bunker', 31, 6, -34, 15.8, 12, 15.8, true);

    [-5.2, 5.2].forEach((bz) => {
      const buttress = shadowMesh(new THREE.BoxGeometry(2.4, 5.8, 1.4), mats.concreteMain);
      buttress.position.set(-8.2, 2.9, bz);
      buttress.rotation.z = 0.18;
      b5.add(buttress);
    });

    const bunkerSignMat = mats.createSignMaterial(
      'SENTINEL RELAY SPIRE 05',
      'AUTONOMOUS EMERGENCY BEACON ACTIVE',
      '#ff8a3d'
    );
    const bunkerSign = new THREE.Mesh(new THREE.BoxGeometry(0.24, 1.35, 7.6), bunkerSignMat);
    bunkerSign.position.set(-7.82, 4.6, 0);
    b5.add(bunkerSign);

    // Leaning 7-Degree Relay Spire Group
    const spire = new THREE.Group();
    spire.position.set(0, 5.8, 0);
    spire.rotation.z = 0.12; // 7-degree lean toward the boulevard
    b5.add(spire);

    // Octagonal stepped concrete core
    const lowerShaft = shadowMesh(new THREE.CylinderGeometry(4.4, 5.2, 12.0, 8), mats.concreteMain);
    lowerShaft.position.y = 6.0;
    spire.add(lowerShaft);

    const upperShaft = shadowMesh(new THREE.CylinderGeometry(2.8, 4.1, 11.0, 8), mats.concreteWarm);
    upperShaft.position.y = 17.0;
    spire.add(upperShaft);

    // Cantilevered Steel Maintenance Catwalk Rings
    [6.5, 12.2, 18.0].forEach((cy, idx) => {
      const ring = shadowMesh(
        new THREE.CylinderGeometry(5.6 - idx * 0.7, 5.6 - idx * 0.7, 0.45, 8),
        mats.rustedSteel
      );
      ring.position.y = cy;
      spire.add(ring);
    });

    // External High-Pressure Conduit Pipes running vertically up the spire
    for (let a = 0; a < 4; a++) {
      const ang = (a / 4) * Math.PI * 2 + 0.4;
      const pipe = shadowMesh(new THREE.CylinderGeometry(0.28, 0.28, 21.0, 8), mats.darkSteel);
      pipe.position.set(Math.cos(ang) * 4.5, 10.5, Math.sin(ang) * 4.5);
      spire.add(pipe);
    }

    // Broken Microwave Relay Dishes & Pulsing Top Mast Beacon
    const dish = shadowMesh(new THREE.CylinderGeometry(2.4, 0.5, 0.9, 12), mats.concreteWarm);
    dish.position.set(-4.2, 15.5, 0);
    dish.rotation.z = Math.PI * 0.42;
    spire.add(dish);

    const dish2 = shadowMesh(new THREE.CylinderGeometry(1.85, 0.4, 0.75, 12), mats.concreteWarm);
    dish2.position.set(-3.4, 9.8, 2.4);
    dish2.rotation.z = Math.PI * 0.36;
    spire.add(dish2);

    const mast = shadowMesh(new THREE.CylinderGeometry(0.18, 0.45, 8.5, 6), mats.rustedSteel);
    mast.position.y = 26.2;
    spire.add(mast);

    const topBeacon = new THREE.Mesh(new THREE.SphereGeometry(0.48, 10, 10), mats.amberBeacon);
    topBeacon.position.y = 30.5;
    spire.add(topBeacon);
  };

  buildB5SentinelSpire();

  // ----------------------------------------------------------------------------
  // BUILDING 6: Sunken Civic Archives & Colonnade Hall (West North-Mid, Z = -42)
  // Fluted rectangular colonnade piers, fractured pediment & exposed archive interior
  // ----------------------------------------------------------------------------
  const buildB6CivicArchives = () => {
    const b6 = new THREE.Group();
    b6.position.set(-29, 0, -42);
    archGroup.add(b6);

    // Stepped Civic Stylobate Plinth + Walkable Ceremonial Front Steps
    const plinth = shadowMesh(new THREE.BoxGeometry(16.0, 0.85, 22.0), mats.concreteWarm);
    plinth.position.y = 0.42;
    b6.add(plinth);
    physics.addFlatSurface('b6_plinth', -37.0, -21.0, -53.0, -31.0, 0.85);

    const entrySteps = shadowMesh(new THREE.BoxGeometry(1.5, 0.52, 20.4), mats.concreteMain);
    entrySteps.position.set(8.6, 0.26, 0);
    b6.add(entrySteps);
    physics.addRampSurface('b6_entry_steps', -21.2, -19.5, -52.4, -31.6, (x) => {
      const t = THREE.MathUtils.clamp((-19.5 - x) / 1.7, 0, 1);
      return 0.24 + t * 0.61;
    });

    // Rear & South Hall Walls (North & East walls breached so the archive interior is exposed!)
    const rearWall = shadowMesh(new THREE.BoxGeometry(1.6, 11.8, 21.4), mats.concreteMain);
    rearWall.position.set(-7.0, 6.2, 0);
    b6.add(rearWall);
    physics.addBox('b6_rear_wall', -36.0, 6.2, -42, 1.8, 12.0, 21.4, true);

    const southWall = shadowMesh(new THREE.BoxGeometry(15.2, 11.8, 1.6), mats.concreteMain);
    southWall.position.set(0, 6.2, 10.0);
    b6.add(southWall);
    physics.addBox('b6_south_wall', -29, 6.2, -32, 15.2, 12.0, 1.8, true);

    // 6 Monumental Fluted Rectangular Colonnade Piers along the East (Boulevard) Facade
    for (let pz = -8.5; pz <= 8.5; pz += 3.4) {
      const isBrokenPier = Math.abs(pz + 1.7) < 0.5;
      const pierH = isBrokenPier ? 5.2 : 11.2;
      const pier = shadowMesh(new THREE.BoxGeometry(1.25, pierH, 1.25), mats.concreteWarm);
      pier.position.set(6.8, 0.85 + pierH * 0.5, pz);
      b6.add(pier);
      physics.addBox(`b6_pier_${pz.toFixed(1)}`, -22.2, pierH * 0.5, -42 + pz, 1.35, pierH, 1.35, true);
    }

    // Fractured Classical-Futuristic Entablature, Pediment & Half-Collapsed Roof Vault
    const entablature = shadowMesh(new THREE.BoxGeometry(3.2, 1.8, 21.8), mats.concreteDark);
    entablature.position.set(6.2, 12.6, 0);
    b6.add(entablature);

    const pedimentS = shadowMesh(new THREE.BoxGeometry(2.6, 2.2, 9.2), mats.concreteWarm);
    pedimentS.position.set(6.4, 14.2, 5.2);
    pedimentS.rotation.x = -0.18;
    b6.add(pedimentS);

    const roofHalf = shadowMesh(new THREE.BoxGeometry(14.5, 0.9, 12.5), mats.concreteMain);
    roofHalf.position.set(-0.5, 12.4, 4.4);
    b6.add(roofHalf);

    // Exposed Interior Archive Monolith Stelae & Data Shelves visible inside the breached hall
    for (let row = -5.5; row <= 5.5; row += 3.6) {
      const archiveShelf = shadowMesh(new THREE.BoxGeometry(4.8, 4.6, 0.95), mats.astralMonolith);
      archiveShelf.position.set(-1.5, 3.15, row);
      archiveShelf.rotation.z = row < 0 ? 0.14 : 0; // Northern shelf tilted from roof collapse
      b6.add(archiveShelf);
      physics.addBox(`b6_shelf_${row.toFixed(1)}`, -30.5, 3.1, -42 + row, 4.8, 4.6, 1.1, false);
    }

    // Central Glowing Archive Index Pedestal inside the Colonnade Hall
    const indexPedestal = shadowMesh(
      new THREE.CylinderGeometry(0.65, 0.85, 1.4, 8),
      mats.astralMonolith
    );
    indexPedestal.position.set(2.4, 1.55, 1.8);
    b6.add(indexPedestal);

    const indexCore = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.42, 0),
      mats.astralEnergyCore
    );
    indexCore.position.set(2.4, 2.65, 1.8);
    b6.add(indexCore);
  };

  buildB6CivicArchives();

  // ----------------------------------------------------------------------------
  // BUILDING 7: Tachibana Power Substation & Logistics Depot (East North, Z = -72)
  // High-voltage ceramic transformer banks, radiator fins, overhead steel gantry crane
  // ----------------------------------------------------------------------------
  const buildB7TachibanaDepot = () => {
    const b7 = new THREE.Group();
    b7.position.set(26, 0, -72);
    archGroup.add(b7);

    // Reinforced Concrete & Steel Turbine Hall
    const hall = shadowMesh(new THREE.BoxGeometry(13.5, 10.5, 17.5), mats.concreteDark);
    hall.position.set(2.2, 5.25, 0);
    b7.add(hall);
    physics.addBox('b7_hall', 28.2, 5.25, -72, 13.8, 10.5, 17.8, true);

    addWindowGrid(b7, 13.8, 4.2, 4, 1, 4.62, -Math.PI * 0.5, 71);

    // Twin Cylindrical Industrial Cooling Silos on Rooftop
    [-3.8, 3.8].forEach((sz) => {
      const silo = shadowMesh(
        new THREE.CylinderGeometry(2.2, 2.2, 4.4, 12),
        mats.rustedSteel
      );
      silo.position.set(3.2, 12.7, sz);
      b7.add(silo);
    });

    // Torn Corrugated Rolling Steel Loading Shutter on West Facade
    const shutterTop = shadowMesh(new THREE.BoxGeometry(0.45, 2.8, 6.8), mats.shopShutter);
    shutterTop.position.set(-4.65, 3.2, -2.5);
    shutterTop.rotation.z = 0.14;
    b7.add(shutterTop);

    // Exterior High-Voltage Transformer Yard (3 Heavy Transformer Cores + Ceramic Insulator Bushings)
    for (let tz = -5.5; tz <= 5.5; tz += 5.5) {
      const txCore = shadowMesh(new THREE.BoxGeometry(3.2, 3.8, 3.4), mats.darkSteel);
      txCore.position.set(-7.2, 1.9, tz);
      b7.add(txCore);
      physics.addBox(`b7_tx_${tz}`, 18.8, 1.9, -72 + tz, 3.4, 3.8, 3.6, false);

      // 3 Tall Ceramic High-Voltage Insulator Stacks on each transformer
      [-0.9, 0, 0.9].forEach((iz) => {
        const bushing = shadowMesh(
          new THREE.CylinderGeometry(0.18, 0.26, 2.1, 8),
          mats.concreteWarm
        );
        bushing.position.set(-7.2, 4.8, tz + iz);
        b7.add(bushing);
      });
    }

    // Overhead Steel Gantry Frame spanning the Transformer Yard
    const gantryPostN = shadowMesh(new THREE.BoxGeometry(0.55, 9.2, 0.55), mats.rustedSteel);
    gantryPostN.position.set(-7.2, 4.6, -8.5);
    b7.add(gantryPostN);

    const gantryPostS = shadowMesh(new THREE.BoxGeometry(0.55, 9.2, 0.55), mats.rustedSteel);
    gantryPostS.position.set(-7.2, 4.6, 8.5);
    b7.add(gantryPostS);

    const gantryBeam = shadowMesh(new THREE.BoxGeometry(0.75, 0.75, 18.2), mats.rustedSteel);
    gantryBeam.position.set(-7.2, 9.1, 0);
    b7.add(gantryBeam);

    const depotSign = mats.createSignMaterial(
      'TACHIBANA GRID SUBSTATION 07',
      'HIGH VOLTAGE // GATE FEEDER CONDUIT',
      '#4deeea'
    );
    const signMesh = new THREE.Mesh(new THREE.BoxGeometry(0.24, 1.5, 9.2), depotSign);
    signMesh.position.set(-4.65, 8.4, 0);
    b7.add(signMesh);
  };

  buildB7TachibanaDepot();

  // ----------------------------------------------------------------------------
  // BUILDING 8: Leaning Twin-Core Meridian Skyscraper Ruin (West North, Z = -76)
  // 8-story cleaved corporate tower with exposed elevator core & cantilevered I-beams
  // ----------------------------------------------------------------------------
  const buildB8MeridianSkyscraper = () => {
    const b8 = new THREE.Group();
    b8.position.set(-30, 0, -76);
    b8.rotation.z = -0.055; // Slight dramatic calamity tilt
    archGroup.add(b8);

    // Lower 5-story Curtain-Wall Podium
    const podium = shadowMesh(new THREE.BoxGeometry(16.0, 17.5, 19.5), mats.concreteMain);
    podium.position.set(0, 8.75, 0);
    b8.add(podium);
    physics.addBox('b8_podium', -30, 9, -76, 16.4, 18, 19.8, true);

    // Multi-face Curtain Wall Window Grids (East, South, and North faces)
    addWindowGrid(b8, 17.2, 15.2, 6, 5, 8.05, Math.PI * 0.5, 88);
    addWindowGrid(b8, 13.6, 15.2, 4, 5, 9.8, 0, 91);
    addWindowGrid(b8, 13.6, 15.2, 4, 5, 9.8, Math.PI, 94);

    // Ground-floor Corporate Lobby Canopy & Illuminated Fascia Sign
    const lobbyCanopy = shadowMesh(new THREE.BoxGeometry(3.4, 0.45, 11.2), mats.darkSteel);
    lobbyCanopy.position.set(9.2, 4.1, 0);
    b8.add(lobbyCanopy);

    const meridianSignMat = mats.createSignMaterial(
      'MERIDIAN CORP // TOWER 08',
      'EXECUTIVE SECTOR — UPPER FLOORS COMPROMISED',
      '#f5b651'
    );
    const meridianSign = new THREE.Mesh(new THREE.BoxGeometry(0.24, 1.5, 9.6), meridianSignMat);
    meridianSign.position.set(8.2, 16.4, 0);
    b8.add(meridianSign);

    // Exposed Reinforced-Concrete Central Elevator Core rising to 29 meters
    const elevatorCore = shadowMesh(new THREE.BoxGeometry(7.2, 29.0, 8.4), mats.concreteDark);
    elevatorCore.position.set(-2.2, 14.5, 0);
    b8.add(elevatorCore);

    // Exposed Upper Floor Slabs (Floors 6, 7, 8 cleaved back revealing steel I-beam grid!)
    [20.2, 23.8, 27.4].forEach((fy, idx) => {
      const slabW = 14.5 - idx * 2.6;
      const slab = shadowMesh(new THREE.BoxGeometry(slabW, 0.55, 17.0 - idx * 2.2), mats.concreteDamaged);
      slab.position.set(-1.2, fy, 0);
      slab.rotation.z = -0.08 * (idx + 1);
      b8.add(slab);

      // Cantilevered Steel I-Beam Columns & Girders sticking out into the sky
      for (let gz = -6; gz <= 6; gz += 4) {
        const iBeam = shadowMesh(new THREE.BoxGeometry(5.5, 0.38, 0.38), mats.rustedSteel);
        iBeam.position.set(slabW * 0.5 + 1.2, fy - 0.2, gz);
        b8.add(iBeam);

        const colStub = shadowMesh(new THREE.BoxGeometry(0.42, 3.6, 0.42), mats.rustedSteel);
        colStub.position.set(slabW * 0.5 - 0.5, fy + 1.6, gz);
        b8.add(colStub);
      }
    });
  };

  buildB8MeridianSkyscraper();

  // ----------------------------------------------------------------------------
  // MID-BLOCK ANIME URBAN STREET-FRONT INFILL (Eliminating Empty Outer Lot Gaps)
  // Art-directed 2-to-4-story modern East-Asian shopfront & apartment structures
  // ----------------------------------------------------------------------------
  const buildUrbanMidBlockInfill = () => {
    const infillGroup = new THREE.Group();
    infillGroup.name = 'UrbanMidBlockInfillGroup';
    archGroup.add(infillGroup);

    const infillConfigs: Array<{
      id: string;
      x: number;
      z: number;
      w: number;
      h: number;
      d: number;
      side: -1 | 1;
      useBrick: boolean;
      hasAwning: boolean;
      seed: number;
    }> = [
      { id: 'infill_w_south', x: -27.5, z: 75.5, w: 12.0, h: 11.5, d: 11.0, side: -1, useBrick: true, hasAwning: true, seed: 101 },
      { id: 'infill_e_south', x: 27.5, z: 73.5, w: 12.0, h: 12.8, d: 12.5, side: 1, useBrick: false, hasAwning: true, seed: 102 },
      { id: 'infill_w_mid1', x: -28.0, z: 38.0, w: 12.5, h: 14.0, d: 13.5, side: -1, useBrick: false, hasAwning: true, seed: 103 },
      { id: 'infill_e_mid1', x: 28.0, z: 35.0, w: 12.5, h: 12.2, d: 13.0, side: 1, useBrick: true, hasAwning: true, seed: 104 },
      { id: 'infill_w_viaduct', x: -28.5, z: -2.5, w: 12.0, h: 10.8, d: 11.5, side: -1, useBrick: true, hasAwning: false, seed: 105 },
      { id: 'infill_e_viaduct', x: 28.5, z: -3.5, w: 12.0, h: 11.4, d: 11.0, side: 1, useBrick: false, hasAwning: true, seed: 106 },
      { id: 'infill_w_north', x: -29.0, z: -58.5, w: 12.5, h: 13.2, d: 10.5, side: -1, useBrick: false, hasAwning: true, seed: 107 },
      { id: 'infill_e_north', x: 28.5, z: -53.5, w: 12.5, h: 12.5, d: 12.0, side: 1, useBrick: true, hasAwning: true, seed: 108 }
    ];

    infillConfigs.forEach((cfg) => {
      const b = new THREE.Group();
      b.position.set(cfg.x, 0, cfg.z);
      infillGroup.add(b);

      const wallMat = cfg.useBrick ? mats.darkBrickFacade : mats.ceramicTileFacade;
      const body = shadowMesh(new THREE.BoxGeometry(cfg.w, cfg.h, cfg.d), wallMat);
      body.position.y = cfg.h * 0.5;
      b.add(body);
      physics.addBox(cfg.id, cfg.x, cfg.h * 0.5, cfg.z, cfg.w + 0.3, cfg.h, cfg.d + 0.3, true);

      // Roof parapet cornice
      const roofRim = shadowMesh(
        new THREE.BoxGeometry(cfg.w + 0.45, 0.55, cfg.d + 0.45),
        mats.concreteDark
      );
      roofRim.position.y = cfg.h + 0.25;
      b.add(roofRim);

      // Rooftop mechanical HVAC unit
      const hvac = shadowMesh(new THREE.BoxGeometry(2.6, 1.5, 3.2), mats.rustedSteel);
      hvac.position.set(0, cfg.h + 0.95, 0);
      b.add(hvac);

      // Street-facing window bays
      const streetFaceOffset = cfg.w * 0.5 + 0.04;
      const streetRotY = cfg.side === -1 ? Math.PI * 0.5 : -Math.PI * 0.5;
      addWindowGrid(b, cfg.d * 0.86, cfg.h - 3.8, 3, 3, streetFaceOffset, streetRotY, cfg.seed);

      // Ground-floor commercial rollup shutter & shop awning facing the sidewalk
      const shutter = shadowMesh(
        new THREE.BoxGeometry(0.18, 2.7, cfg.d * 0.65),
        mats.shopShutter
      );
      shutter.position.set(-cfg.side * (cfg.w * 0.5 + 0.05), 1.55, 0);
      b.add(shutter);

      if (cfg.hasAwning) {
        const awningMat =
          cfg.seed % 2 === 0 ? mats.awningFabricVermilion : mats.awningFabricTeal;
        const awning = shadowMesh(
          new THREE.BoxGeometry(1.75, 0.2, cfg.d * 0.72),
          awningMat
        );
        awning.position.set(-cfg.side * (cfg.w * 0.5 + 0.82), 3.05, 0);
        awning.rotation.z = cfg.side * 0.22;
        b.add(awning);
      }
    });
  };

  buildUrbanMidBlockInfill();

  // ----------------------------------------------------------------------------
  // BUILDING 9: Gatekeeper Bastion & Quarantine Pavilion (North Terrace East, Z = -104)
  // Fortified bunker pavilion integrated into the elevated sanctuary terrace
  // ----------------------------------------------------------------------------
  const buildB9GatekeeperBastion = () => {
    const b9 = new THREE.Group();
    b9.position.set(22, 3.2, -112);
    archGroup.add(b9);

    // Sloped Armored Bastion Lower Hull
    const lowerBastion = shadowMesh(new THREE.BoxGeometry(12.5, 4.8, 12.0), mats.concreteDark);
    lowerBastion.position.y = 2.4;
    b9.add(lowerBastion);

    // Cantilevered Observation Bridge Deck overlooking the Grand Staircase
    const bridgeDeck = shadowMesh(new THREE.BoxGeometry(14.2, 3.2, 9.5), mats.concreteMain);
    bridgeDeck.position.set(-1.4, 6.2, 1.2);
    b9.add(bridgeDeck);

    //Glowing Horizontal Observation Visor Slit
    const visor = new THREE.Mesh(new THREE.BoxGeometry(10.5, 0.55, 9.7), mats.windowIntact);
    visor.position.set(-2.6, 6.2, 1.2);
    b9.add(visor);

    // Rooftop Sensor Array & Containment Cable Anchor Mast
    const radarMast = shadowMesh(new THREE.CylinderGeometry(0.45, 0.7, 5.5, 8), mats.rustedSteel);
    radarMast.position.set(0, 10.2, 0);
    b9.add(radarMast);

    const beacon = new THREE.Mesh(new THREE.SphereGeometry(0.38, 8, 8), mats.amberBeacon);
    beacon.position.set(0, 13.1, 0);
    b9.add(beacon);

    physics.addBox('b9_bastion', 22, 7.2, -112, 13.5, 9.0, 12.5, true);
  };

  buildB9GatekeeperBastion();

  // Mirror Western Sanctuary Retaining Colonnade Pavilion on the West Terrace Flank (`X = -22, Z = -112`)
  const buildWestSanctuaryColonnade = () => {
    const westPav = new THREE.Group();
    westPav.position.set(-22, 3.2, -112);
    archGroup.add(westPav);

    const base = shadowMesh(new THREE.BoxGeometry(11.5, 1.2, 11.5), mats.concreteWarm);
    base.position.y = 0.6;
    westPav.add(base);

    for (let px = -4; px <= 4; px += 4) {
      for (let pz = -4; pz <= 4; pz += 8) {
        const pillar = shadowMesh(new THREE.BoxGeometry(1.1, 7.5, 1.1), mats.astralMonolith);
        pillar.position.set(px, 4.35, pz);
        westPav.add(pillar);
      }
    }

    const lintel = shadowMesh(new THREE.BoxGeometry(12.2, 1.4, 10.2), mats.concreteDark);
    lintel.position.set(0, 8.5, 0);
    lintel.rotation.z = -0.06;
    westPav.add(lintel);

    physics.addBox('west_sanctuary_pav', -22, 7.0, -112, 11.5, 8.5, 11.5, true);
  };

  buildWestSanctuaryColonnade();

  // ============================================================================
  // 4. MONUMENTAL LEVEL 1 EXIT GATE — ASTRAL RESONANCE SANCTUM (Z = -118, Y = 3.2)
  // ============================================================================
  const buildMonumentalExitGate = (): ExitGateAnimatedRefs => {
    const exitGroup = new THREE.Group();
    exitGroup.position.set(0, 3.2, -120);
    archGroup.add(exitGroup);

    // Ceremonial Stepped Octagonal Dais Platform
    const dais1 = shadowMesh(new THREE.CylinderGeometry(11.5, 12.4, 0.55, 8), mats.concreteWarm);
    dais1.position.y = 0.275;
    exitGroup.add(dais1);

    const dais2 = shadowMesh(new THREE.CylinderGeometry(8.8, 9.5, 0.5, 8), mats.astralMonolith);
    dais2.position.y = 0.78;
    exitGroup.add(dais2);

    // Golden Inlaid Resonance Ring in the Dais Floor
    const floorRing = new THREE.Mesh(
      new THREE.RingGeometry(4.8, 5.3, 32),
      mats.astralGoldTrim
    );
    floorRing.rotation.x = -Math.PI * 0.5;
    floorRing.position.y = 1.05;
    exitGroup.add(floorRing);

    // Twin 28-Meter Monumental Carved Basalt-and-Gold Pylons
    [-7.8, 7.8].forEach((px, idx) => {
      const side = px < 0 ? -1 : 1;
      const pylon = new THREE.Group();
      pylon.position.set(px, 0.5, 0);
      exitGroup.add(pylon);

      // Stepped monolith base
      const pBase = shadowMesh(new THREE.BoxGeometry(4.6, 5.2, 5.2), mats.concreteDark);
      pBase.position.y = 2.6;
      pylon.add(pBase);

      // Main 25m Tapered Astral Monolith Blade
      const blade = shadowMesh(new THREE.BoxGeometry(3.4, 24.5, 4.0), mats.astralMonolith);
      blade.position.set(side * -0.4, 14.5, 0);
      blade.rotation.z = side * -0.05; // Majestic inward architectural convergence
      pylon.add(blade);

      // Outer Swept Buttress Wing
      const wing = shadowMesh(new THREE.BoxGeometry(2.4, 18.0, 3.0), mats.concreteMain);
      wing.position.set(side * 2.5, 9.0, 0);
      wing.rotation.z = side * 0.14;
      pylon.add(wing);

      // Luminous Golden Resonance Fin Plates along inner pylon edge
      for (let fy = 5.5; fy <= 23.5; fy += 3.6) {
        const fin = shadowMesh(new THREE.BoxGeometry(0.85, 1.8, 1.4), mats.astralGoldTrim);
        fin.position.set(side * -2.1, fy, 0);
        pylon.add(fin);
      }

      // Crown Spire Tip
      const spireTip = shadowMesh(new THREE.ConeGeometry(1.8, 4.8, 4), mats.astralGoldTrim);
      spireTip.position.set(side * -1.0, 28.8, 0);
      spireTip.rotation.y = Math.PI * 0.25;
      pylon.add(spireTip);

      // Register Pylon Colliders (leaving the 11m central threshold open for the player to walk into!)
      physics.addBox(`exit_gate_pylon_${idx}`, px, 15, -120, 5.2, 28, 5.4, true);
    });

    // Monumental Fractured Arch Crown spanning high between the twin pylons (Y = 23.5m)
    const archCrownL = shadowMesh(new THREE.BoxGeometry(6.8, 2.2, 3.2), mats.astralMonolith);
    archCrownL.position.set(-4.2, 23.8, 0);
    archCrownL.rotation.z = 0.22;
    exitGroup.add(archCrownL);

    const archCrownR = shadowMesh(new THREE.BoxGeometry(6.8, 2.2, 3.2), mats.astralMonolith);
    archCrownR.position.set(4.2, 23.8, 0);
    archCrownR.rotation.z = -0.22;
    exitGroup.add(archCrownR);

    // Suspended Counter-Rotating Astrolabe Rings in the Gate Threshold (Y = 12.2m)
    const outerRing = new THREE.Group();
    outerRing.position.set(0, 12.2, 0);
    exitGroup.add(outerRing);

    const outerTorus = shadowMesh(new THREE.TorusGeometry(4.8, 0.28, 10, 32), mats.astralGoldTrim);
    outerRing.add(outerTorus);

    // Cardinal Rune Blades on the Outer Ring
    for (let i = 0; i < 8; i++) {
      const ang = (i / 8) * Math.PI * 2;
      const blade = shadowMesh(new THREE.BoxGeometry(0.32, 1.45, 0.32), mats.astralMonolith);
      blade.position.set(Math.cos(ang) * 4.8, Math.sin(ang) * 4.8, 0);
      blade.rotation.z = ang;
      outerRing.add(blade);
    }

    const innerRing = new THREE.Group();
    innerRing.position.set(0, 12.2, 0);
    exitGroup.add(innerRing);

    const innerTorus = shadowMesh(new THREE.TorusGeometry(3.2, 0.2, 10, 28), mats.astralEnergyCore);
    innerRing.add(innerTorus);

    // Central Floating Resonance Octahedron Core
    const coreCrystal = new THREE.Mesh(
      new THREE.OctahedronGeometry(1.25, 0),
      mats.astralEnergyCore
    );
    coreCrystal.position.set(0, 12.2, 0);
    exitGroup.add(coreCrystal);

    // Lower Interactive Threshold Portal Shimmer Plane (Player walks up to Y = 3.2, Z = -118 to interact!)
    const portalField = new THREE.Mesh(
      new THREE.CylinderGeometry(3.8, 3.8, 7.5, 24, 1, true),
      new THREE.MeshBasicMaterial({
        color: new THREE.Color('#4deeea'),
        transparent: true,
        opacity: 0.16,
        side: THREE.DoubleSide,
        depthWrite: false
      })
    );
    portalField.position.set(0, 4.6, 0);
    exitGroup.add(portalField);

    const beaconLight = new THREE.PointLight('#4deeea', 3.5, 28, 1.5);
    beaconLight.position.set(0, 8.5, 2.0);
    exitGroup.add(beaconLight);

    return {
      outerRing,
      innerRing,
      coreCrystal,
      portalField,
      beaconLight
    };
  };

  const exitGateRefs = buildMonumentalExitGate();

  // ============================================================================
  // 5. DISTANT SKYLINE & IMPRESSIVE ENVIRONMENTAL HORIZON LANDMARKS
  // ============================================================================
  const buildDistantSkylineAndLandmarks = () => {
    const skyline = new THREE.Group();
    skyline.name = 'DistantMegalopolisSkyline';
    archGroup.add(skyline);

    const silhouetteNearMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#232a3d'),
      roughness: 0.9,
      metalness: 0.18
    });

    const silhouetteFarMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#2d2d44'),
      roughness: 0.94,
      metalness: 0.1
    });

    const accentWindowMat = new THREE.MeshBasicMaterial({
      color: new THREE.Color('#ffad66')
    });

    const cyanBeaconMat = new THREE.MeshBasicMaterial({
      color: new THREE.Color('#5ef2ff')
    });

    // Multi-layered ring of 32 varied anime mega-skyscrapers, twin-core arcologies & cleaved towers
    for (let i = 0; i < 32; i++) {
      const angle = (i / 32) * Math.PI * 2;
      const isFarLayer = i % 2 === 1;
      const dist = (isFarLayer ? 215 : 162) + (i % 4) * 18;
      const sx = Math.cos(angle) * dist;
      const sz = Math.sin(angle) * dist - 15;
      const w = 15 + (i % 5) * 4.5;
      const d = 15 + ((i * 3) % 5) * 4.5;
      const h = 44 + ((i * 7) % 7) * 17;
      const mat = isFarLayer ? silhouetteFarMat : silhouetteNearMat;

      const tower = new THREE.Group();
      tower.position.set(sx, 0, sz);
      tower.rotation.y = angle + Math.PI * 0.5;
      tower.rotation.z = ((i % 5) - 2) * 0.032; // Subtle calamity tilt on distant ruins
      skyline.add(tower);

      const body = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
      body.position.y = h * 0.5;
      tower.add(body);

      // Architectural silhouette variation: Twin-Bridge Tower, Stepped Spire, or Cleaved Diagonal Ruin
      if (i % 3 === 0) {
        const crown = new THREE.Mesh(
          new THREE.BoxGeometry(w * 0.68, h * 0.24, d * 0.68),
          mat
        );
        crown.position.set(0, h + h * 0.11, 0);
        tower.add(crown);

        const antenna = new THREE.Mesh(
          new THREE.CylinderGeometry(0.25, 0.6, 16, 6),
          mat
        );
        antenna.position.set(0, h + h * 0.24 + 7, 0);
        tower.add(antenna);
      } else if (i % 3 === 1) {
        // Sheared diagonal top slab
        const shearedTop = new THREE.Mesh(
          new THREE.BoxGeometry(w * 0.85, h * 0.18, d * 0.85),
          mat
        );
        shearedTop.position.set(w * 0.08, h + h * 0.06, 0);
        shearedTop.rotation.z = 0.28;
        tower.add(shearedTop);
      } else {
        // Stepped side wing & skybridge
        const sideWing = new THREE.Mesh(
          new THREE.BoxGeometry(w * 0.55, h * 0.78, d * 0.75),
          mat
        );
        sideWing.position.set(w * 0.72, h * 0.39, 0);
        tower.add(sideWing);
      }

      // Luminous distant horizontal window bands & rooftop aviation beacons
      for (let wy = h * 0.35; wy < h * 0.88; wy += 14) {
        const winBand = new THREE.Mesh(
          new THREE.BoxGeometry(w * 0.76, 1.1, d + 0.3),
          (i + Math.round(wy)) % 4 === 0 ? cyanBeaconMat : accentWindowMat
        );
        winBand.position.set(0, wy, 0);
        tower.add(winBand);
      }
    }

    // Impressive Horizon Landmark behind the Northern Exit Gate:
    // Fractured Orbital Tether Spire & Broken Megastructure Halo on the distant horizon (`Z = -265`)
    const megaLandmark = new THREE.Group();
    megaLandmark.position.set(0, 0, -265);
    skyline.add(megaLandmark);

    const megaSpire = new THREE.Mesh(
      new THREE.CylinderGeometry(4.5, 18.0, 185, 8),
      silhouetteNearMat
    );
    megaSpire.position.y = 90;
    megaSpire.rotation.z = 0.09;
    megaLandmark.add(megaSpire);

    // Secondary fractured buttress blades flanking the orbital spire
    [-26, 26].forEach((bx) => {
      const sideFin = new THREE.Mesh(
        new THREE.BoxGeometry(6.5, 115, 14),
        silhouetteFarMat
      );
      sideFin.position.set(bx, 52, 8);
      sideFin.rotation.z = bx < 0 ? -0.16 : 0.16;
      megaLandmark.add(sideFin);
    });

    const megaHalo = new THREE.Mesh(
      new THREE.TorusGeometry(54, 2.2, 8, 42, Math.PI * 1.45),
      mats.astralGoldTrim
    );
    megaHalo.position.set(6, 118, 0);
    megaHalo.rotation.set(0.35, 0.2, 0.45);
    megaLandmark.add(megaHalo);
  };

  buildDistantSkylineAndLandmarks();

  return exitGateRefs;
}
